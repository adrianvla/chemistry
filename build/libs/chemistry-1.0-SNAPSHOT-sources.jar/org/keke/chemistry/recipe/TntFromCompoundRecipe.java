package org.keke.chemistry.recipe;

import com.google.gson.JsonObject;
import org.keke.chemistry.item.AbstractContainerItem;
import org.keke.chemistry.item.BeakerItem;
import org.keke.chemistry.utils.ExplosiveCompounds;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1852;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_5455;
import net.minecraft.class_7710;
import net.minecraft.class_8566;

/**
 * Special crafting recipe: any chemistry container holding explosive compound(s)
 *   + string + paper → minecraft:tnt
 *
 * The explosive power of the container contents determines how many TNT blocks
 * are produced (1-4), calculated by ExplosiveCompounds.
 *
 * Layout (shapeless): container + string + paper anywhere in 3x3 grid.
 */
public class TntFromCompoundRecipe extends class_1852 {

    public TntFromCompoundRecipe(class_2960 id, class_7710 category) {
        super(id, category);
    }

    @Override
    public boolean matches(class_8566 inventory, class_1937 world) {
        boolean hasExplosiveContainer = false;
        boolean hasString = false;
        boolean hasPaper = false;
        int nonEmptySlots = 0;

        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (stack.method_7960()) continue;
            nonEmptySlots++;

            if (isExplosiveContainer(stack)) {
                hasExplosiveContainer = true;
            } else if (stack.method_31574(class_1802.field_8276)) {
                hasString = true;
            } else if (stack.method_31574(class_1802.field_8407)) {
                hasPaper = true;
            } else {
                return false; // unexpected item
            }
        }

        return hasExplosiveContainer && hasString && hasPaper && nonEmptySlots == 3;
    }

    @Override
    public class_1799 craft(class_8566 inventory, class_5455 registryManager) {
        for (int i = 0; i < inventory.method_5439(); i++) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960() && isExplosiveContainer(stack)) {
                Map<String, Double> contents = getContentsFromAny(stack);
                double power = ExplosiveCompounds.calculateTotalExplosionPower(contents);
                // 1 TNT per ~4.0 MC explosion power units, min 1, max 4
                int count = Math.max(1, Math.min(4, (int) (power / 4.0)));
                return new class_1799(class_1802.field_8626, count);
            }
        }
        return new class_1799(class_1802.field_8626, 1);
    }

    @Override
    public boolean method_8113(int width, int height) {
        return width * height >= 3;
    }

    @Override
    public class_1865<?> method_8119() {
        return ModRecipeSerializers.TNT_FROM_COMPOUND;
    }

    private boolean isExplosiveContainer(class_1799 stack) {
        Map<String, Double> contents = getContentsFromAny(stack);
        if (contents.isEmpty()) return false;
        double power = ExplosiveCompounds.calculateTotalExplosionPower(contents);
        return power > 0.5;
    }

    private Map<String, Double> getContentsFromAny(class_1799 stack) {
        if (stack.method_7909() instanceof BeakerItem) {
            return BeakerItem.getContents(stack);
        }
        if (stack.method_7909() instanceof AbstractContainerItem) {
            return AbstractContainerItem.getContents(stack);
        }
        // Fallback: raw NBT read
        class_2487 nbt = stack.method_7969();
        if (nbt != null && nbt.method_10573("contents", class_2520.field_33260)) {
            Map<String, Double> map = new LinkedHashMap<>();
            class_2487 contentsNbt = nbt.method_10562("contents");
            for (String key : contentsNbt.method_10541()) {
                double val = contentsNbt.method_10574(key);
                if (val > 0.001) map.put(key, val);
            }
            return map;
        }
        return Map.of();
    }

    public static class Serializer implements class_1865<TntFromCompoundRecipe> {
        @Override
        public TntFromCompoundRecipe method_8121(class_2960 id, JsonObject json) {
            class_7710 category = class_7710.field_40252
                    .method_47920(json.has("category") ? json.get("category").getAsString() : "misc",
                            class_7710.field_40251);
            return new TntFromCompoundRecipe(id, category);
        }

        @Override
        public TntFromCompoundRecipe method_8122(class_2960 id, class_2540 buf) {
            class_7710 category = buf.method_10818(class_7710.class);
            return new TntFromCompoundRecipe(id, category);
        }

        @Override
        public void write(class_2540 buf, TntFromCompoundRecipe recipe) {
            buf.method_10817(recipe.method_45441());
        }
    }
}
