package org.keke.chemistry.recipe;

import net.minecraft.class_1865;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.keke.chemistry.Chemistry;

/**
 * Registers custom recipe serializers for the chemistry mod.
 */
public class ModRecipeSerializers {

    public static final class_1865<TntFromCompoundRecipe> TNT_FROM_COMPOUND =
            class_2378.method_10230(class_7923.field_41189,
                    new class_2960(Chemistry.MOD_ID, "tnt_from_compound"),
                    new TntFromCompoundRecipe.Serializer());

    public static void registerAll() {
        Chemistry.LOGGER.info("Registering recipe serializers for " + Chemistry.MOD_ID);
    }
}
