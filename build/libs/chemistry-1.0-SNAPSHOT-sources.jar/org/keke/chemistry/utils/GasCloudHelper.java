package org.keke.chemistry.utils;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1295;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_3218;

/**
 * Spawns AreaEffectCloud entities when gases escape from chemistry containers.
 * The cloud type and effects depend on the chemical properties of the gas.
 *
 * Gas hazard categories:
 *   - TOXIC: Cl₂, NO₂, SO₂, HCN, H₂S, CO → poison / wither effects
 *   - CORROSIVE: HCl gas, HF gas → instant damage
 *   - ASPHYXIANT: CO₂, N₂, noble gases → mining fatigue / slowness
 *   - IRRITANT: NH₃, SO₃ → nausea / blindness
 *   - FLAMMABLE: H₂, CH₄, C₂H₆ → no direct effect cloud, but marked flammable
 *   - INERT: O₂, He, Ne, Ar → harmless, small visual cloud only
 */
public class GasCloudHelper {

    // ── Gas classification sets ────────────────────────────────────────

    private static final Set<String> TOXIC_GASES = Set.of(
            "Cl2", "NO2", "SO2", "HCN", "H2S", "CO"
    );

    private static final Set<String> CORROSIVE_GASES = Set.of(
            "HCl", "HF", "HBr"
    );

    private static final Set<String> IRRITANT_GASES = Set.of(
            "NH3", "SO3", "NO"
    );

    private static final Set<String> ASPHYXIANT_GASES = Set.of(
            "CO2", "N2", "He", "Ne", "Ar", "Kr", "Xe"
    );

    private static final Set<String> FLAMMABLE_GASES = Set.of(
            "H2", "CH4", "C2H6", "C2H4", "C2H2", "C3H8"
    );

    private static final Set<String> INERT_GASES = Set.of(
            "O2"
    );

    // ── Public API ─────────────────────────────────────────────────────

    /**
     * Spawn gas cloud entities for escaped gases above a container position.
     *
     * @param world  the server world
     * @param pos    the block position of the container
     * @param gases  map of gas formula → moles that escaped
     */
    public static void spawnGasClouds(class_1937 world, class_2338 pos, Map<String, Double> gases) {
        if (world.field_9236 || !(world instanceof class_3218 serverWorld)) return;
        if (gases.isEmpty()) return;

        // Determine the worst gas category and total moles
        GasCategory worst = GasCategory.INERT;
        double totalMoles = 0;
        boolean hasFlammable = false;

        for (var entry : gases.entrySet()) {
            String formula = entry.getKey();
            double moles = entry.getValue();
            totalMoles += moles;

            GasCategory cat = classifyGas(formula);
            if (cat.ordinal() > worst.ordinal()) {
                worst = cat;
            }
            if (FLAMMABLE_GASES.contains(formula)) {
                hasFlammable = true;
            }
        }

        // Scale cloud radius and duration by moles released
        float radius = Math.min(4.0f, 1.0f + (float) (totalMoles * 0.5));
        int durationTicks = Math.min(600, 60 + (int) (totalMoles * 40));

        // Spawn the appropriate cloud
        spawnCloud(serverWorld, pos, worst, radius, durationTicks, hasFlammable);
    }

    // ── Gas classification ─────────────────────────────────────────────

    private enum GasCategory {
        INERT,        // O₂, harmless
        FLAMMABLE,    // H₂, CH₄ — visual only (no lingering effect)
        ASPHYXIANT,   // CO₂, N₂ — mining fatigue
        IRRITANT,     // NH₃ — nausea
        CORROSIVE,    // HCl — damage
        TOXIC         // Cl₂, HCN — poison/wither
    }

    private static GasCategory classifyGas(String formula) {
        if (TOXIC_GASES.contains(formula)) return GasCategory.TOXIC;
        if (CORROSIVE_GASES.contains(formula)) return GasCategory.CORROSIVE;
        if (IRRITANT_GASES.contains(formula)) return GasCategory.IRRITANT;
        if (ASPHYXIANT_GASES.contains(formula)) return GasCategory.ASPHYXIANT;
        if (FLAMMABLE_GASES.contains(formula)) return GasCategory.FLAMMABLE;
        return GasCategory.INERT;
    }

    // ── Cloud spawning ─────────────────────────────────────────────────

    private static void spawnCloud(class_3218 world, class_2338 pos,
                                   GasCategory category, float radius,
                                   int durationTicks, boolean flammable) {

        class_1295 cloud = new class_1295(
                world, pos.method_10263() + 0.5, pos.method_10264() + 0.8, pos.method_10260() + 0.5);

        cloud.method_5603(radius);
        cloud.method_5596(-radius / durationTicks); // shrink over time
        cloud.method_5604(durationTicks);
        cloud.method_5595(10); // short delay before effects start

        switch (category) {
            case TOXIC -> {
                cloud.method_5608(class_2398.field_11226);
                // Poison + wither for severe toxic gases
                cloud.method_5610(new class_1293(
                        class_1294.field_5899, 100, 1));
                cloud.method_5610(new class_1293(
                        class_1294.field_5916, 80, 0));
                if (radius > 2.0f) {
                    cloud.method_5610(new class_1293(
                            class_1294.field_5920, 60, 0));
                }
            }
            case CORROSIVE -> {
                cloud.method_5608(class_2398.field_11226);
                cloud.method_5610(new class_1293(
                        class_1294.field_5921, 1, 0));
                cloud.method_5610(new class_1293(
                        class_1294.field_5916, 60, 0));
            }
            case IRRITANT -> {
                cloud.method_5608(class_2398.field_11226);
                cloud.method_5610(new class_1293(
                        class_1294.field_5916, 120, 1));
                cloud.method_5610(new class_1293(
                        class_1294.field_5919, 60, 0));
            }
            case ASPHYXIANT -> {
                cloud.method_5608(class_2398.field_17430);
                cloud.method_5610(new class_1293(
                        class_1294.field_5901, 80, 1));
                cloud.method_5610(new class_1293(
                        class_1294.field_5909, 60, 0));
            }
            case FLAMMABLE -> {
                // Flammable gas cloud: visual only, no direct effect
                // Future: could ignite if fire/lava is nearby
                cloud.method_5608(class_2398.field_11251);
                cloud.method_5604(Math.min(durationTicks, 200));
            }
            case INERT -> {
                // Harmless cloud, just visual
                cloud.method_5608(class_2398.field_11204);
                cloud.method_5604(Math.min(durationTicks, 100));
            }
        }

        world.method_8649(cloud);
    }
}
