package org.keke.chemistry.utils;

import net.minecraft.class_1282;
import net.minecraft.class_1937;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.class_8110;
import org.keke.chemistry.Chemistry;

/**
 * Custom damage sources for chemistry-related incidents.
 *
 * Damage type "lab_accident" produces the death message:
 *   "<Player> had a lab accident."
 *
 * Registered as a data-driven DamageType via JSON at:
 *   data/chemistry/damage_type/lab_accident.json
 *
 * Death message translation key:
 *   death.attack.lab_accident = "%1$s had a lab accident."
 */
public class ModDamageSources {

    public static final class_5321<class_8110> LAB_ACCIDENT =
            class_5321.method_29179(class_7924.field_42534, new class_2960(Chemistry.MOD_ID, "lab_accident"));

    /**
     * Create a DamageSource for lab accident damage.
     * @param world the world (needed to look up the registry entry)
     * @return a DamageSource that produces "had a lab accident" death messages
     */
    public static class_1282 labAccident(class_1937 world) {
        return new class_1282(
                world.method_30349()
                        .method_30530(class_7924.field_42534)
                        .method_40290(LAB_ACCIDENT)
        );
    }
}
