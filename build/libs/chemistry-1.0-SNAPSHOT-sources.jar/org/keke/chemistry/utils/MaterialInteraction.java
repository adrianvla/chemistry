package org.keke.chemistry.utils;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Determines environmental interactions when chemical compounds contact
 * blocks in the Minecraft world. This handles splash effects from thrown
 * containers and powder placement.
 *
 * Interaction categories:
 *   - CORROSIVE: Strong acids/bases slowly destroy blocks (like stone, wood)
 *   - INCENDIARY: Thermite, phosphorus, alkali metals create fire
 *   - OXIDIZING: Strong oxidizers can ignite flammable blocks
 *   - EXTINGUISHING: Water, CO2 extinguish fire
 *   - FREEZING: Liquid nitrogen, dry ice can freeze water blocks
 *   - REACTIVE_WITH_WATER: Alkali metals, CaO explode/react with water blocks
 */
public class MaterialInteraction {

    private static final Set<String> STRONG_ACIDS = Set.of(
            "HCl", "HBr", "HI", "HNO3", "H2SO4", "HClO3", "HClO4", "HF"
    );

    private static final Set<String> STRONG_BASES = Set.of(
            "NaOH", "KOH", "LiOH", "Ba(OH)2", "Ca(OH)2"
    );

    private static final Set<String> WATER_REACTIVE_METALS = Set.of(
            "Na", "K", "Li", "Rb", "Cs", "Ca", "Ba"
    );

    private static final Set<String> INCENDIARY_COMPOUNDS = Set.of(
            "P"  // white phosphorus ignites in air
    );

    private static final Set<String> FIRE_EXTINGUISHERS = Set.of(
            "H2O", "CO2"
    );

    /**
     * Apply environmental effects when chemicals splash on blocks.
     * Called when a thrown container breaks on impact.
     *
     * @param world    the world
     * @param center   impact position
     * @param contents map of formula → moles
     * @param tempK    temperature of the contents
     * @param radius   splash radius in blocks
     */
    public static void applySplashEffects(class_1937 world, class_2338 center, Map<String, Double> contents,
                                           double tempK, int radius) {
        if (world.field_9236 || !(world instanceof class_3218 serverWorld)) return;
        if (contents.isEmpty()) return;

        for (var entry : contents.entrySet()) {
            String formula = entry.getKey();
            double moles = entry.getValue();

            // Fire extinguishing
            if (FIRE_EXTINGUISHERS.contains(formula)) {
                extinguishNearby(world, center, radius, moles);
            }

            // Corrosive effects on blocks
            if (STRONG_ACIDS.contains(formula) || STRONG_BASES.contains(formula)) {
                corrodeBlocks(world, center, radius, moles);
            }

            // Water-reactive metals
            if (WATER_REACTIVE_METALS.contains(formula)) {
                reactWithWaterBlocks(world, center, radius, formula, moles);
            }

            // Incendiary compounds
            if (INCENDIARY_COMPOUNDS.contains(formula) || isThermiteMixture(contents)) {
                igniteSurroundings(world, center, radius, moles);
            }
        }

        // Temperature-based interactions
        if (tempK > 573.15) { // > 300°C
            igniteSurroundings(world, center, Math.min(radius, 2), 0.5);
        }
        if (tempK < 200.0) { // very cold
            freezeWaterNearby(world, center, radius);
        }
    }

    /**
     * Detect if a mixture constitutes thermite (metal oxide + reactive metal).
     * Classic thermite: Fe2O3 + Al
     * Also: CuO + Al, Cr2O3 + Al, MnO2 + Al
     */
    public static boolean isThermiteMixture(Map<String, Double> contents) {
        boolean hasAluminum = contents.containsKey("Al");
        if (!hasAluminum) return false;

        Set<String> metalOxides = Set.of("Fe2O3", "Fe3O4", "CuO", "Cr2O3", "MnO2", "Co3O4", "NiO");
        for (String oxide : metalOxides) {
            if (contents.containsKey(oxide)) return true;
        }
        return false;
    }

    /**
     * Calculate thermite reaction power based on moles of limiting reagent.
     * Fe2O3 + 2Al → Al2O3 + 2Fe, ΔH = -851.5 kJ/mol
     */
    public static double getThermitePower(Map<String, Double> contents) {
        double alMoles = contents.getOrDefault("Al", 0.0);
        double fe2o3Moles = contents.getOrDefault("Fe2O3", 0.0);

        // Stoichiometry: 2 Al per 1 Fe2O3
        double limitingRatio = Math.min(alMoles / 2.0, fe2o3Moles);
        // ΔH = -851.5 kJ per mol Fe2O3 reacted
        return limitingRatio * 851.5;
    }

    private static void extinguishNearby(class_1937 world, class_2338 center, int radius, double moles) {
        int range = (int) Math.min(radius, 1 + moles * 2);
        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    class_2680 state = world.method_8320(pos);
                    if (state.method_27852(class_2246.field_10036) || state.method_27852(class_2246.field_22089)) {
                        world.method_8650(pos, false);
                        if (world instanceof class_3218 sw) {
                            sw.method_14199(class_2398.field_11251,
                                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                                    3, 0.2, 0.2, 0.2, 0.01);
                        }
                    }
                }
            }
        }
    }

    private static void corrodeBlocks(class_1937 world, class_2338 center, int radius, double moles) {
        // Strong acids/bases can destroy soft blocks (wood, wool, leaves)
        if (moles < 0.5) return;  // need significant amount
        int range = Math.min(radius, 1);
        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    class_2680 state = world.method_8320(pos);
                    float hardness = state.method_26214(world, pos);
                    // Only corrode soft blocks (hardness < 1.0) and not air
                    if (hardness >= 0 && hardness < 1.0 && !state.method_26215()) {
                        if (world.method_8409().method_43057() < Math.min(0.5, moles * 0.2)) {
                            world.method_22352(pos, false);
                            if (world instanceof class_3218 sw) {
                                sw.method_14199(class_2398.field_11251,
                                        pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                                        5, 0.3, 0.3, 0.3, 0.02);
                            }
                        }
                    }
                }
            }
        }
    }

    private static void reactWithWaterBlocks(class_1937 world, class_2338 center, int radius, String metal, double moles) {
        int range = Math.min(radius, 2);
        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    class_2680 state = world.method_8320(pos);
                    if (state.method_27852(class_2246.field_10382)) {
                        // Alkali metals react violently with water
                        // Na/K especially violent → small explosion + fire
                        float power = (float) Math.min(4.0, moles * 2.0);
                        if ("K".equals(metal) || "Rb".equals(metal) || "Cs".equals(metal)) {
                            power *= 1.5f; // more reactive
                        }
                        world.method_8650(pos, false);
                        world.method_8437(null, pos.method_10263() + 0.5, pos.method_10264() + 0.5,
                                pos.method_10260() + 0.5, power, class_1937.class_7867.field_40889);
                        // Spawn NaOH area effect cloud
                        GasCloudHelper.spawnGasClouds(world, pos, Map.of("H2", moles * 0.5));
                        return; // one reaction is enough
                    }
                }
            }
        }
    }

    private static void igniteSurroundings(class_1937 world, class_2338 center, int radius, double moles) {
        int range = Math.min(radius, (int) (1 + moles));
        for (int dx = -range; dx <= range; dx++) {
            for (int dy = -range; dy <= range; dy++) {
                for (int dz = -range; dz <= range; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    class_2338 above = pos.method_10084();
                    if (world.method_8320(above).method_26215() && !world.method_8320(pos).method_26215()) {
                        if (world.method_8409().method_43057() < Math.min(0.4, moles * 0.15)) {
                            world.method_8501(above, class_2246.field_10036.method_9564());
                        }
                    }
                }
            }
        }
        // Spawn flame particles
        if (world instanceof class_3218 sw) {
            sw.method_14199(class_2398.field_11240,
                    center.method_10263() + 0.5, center.method_10264() + 0.5, center.method_10260() + 0.5,
                    20, radius * 0.5, 0.5, radius * 0.5, 0.05);
            sw.method_14199(class_2398.field_11239,
                    center.method_10263() + 0.5, center.method_10264() + 0.5, center.method_10260() + 0.5,
                    8, radius * 0.3, 0.3, radius * 0.3, 0.01);
        }
        world.method_8396(null, center, class_3417.field_15013,
                class_3419.field_15245, 1.5f, 0.8f);
    }

    private static void freezeWaterNearby(class_1937 world, class_2338 center, int radius) {
        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -1; dy <= 1; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    if (world.method_8320(pos).method_27852(class_2246.field_10382)) {
                        world.method_8501(pos, class_2246.field_10295.method_9564());
                    }
                }
            }
        }
    }
}
