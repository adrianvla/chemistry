package org.keke.chemistry.item;

import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.block.AmpuleBlock;
import org.keke.chemistry.block.ModBlocks;
import org.keke.chemistry.entity.AmpuleBlockEntity;
import org.keke.chemistry.utils.ContainerType;

import java.util.List;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Ampule — a small (10 mL) sealed glass container.
 *
 * Sealed ampules:
 *   - Cannot be drunk from
 *   - Can be thrown (explodes/releases contents on impact)
 *   - Must be opened with Pliers (PliersItem) to access contents
 *
 * Once opened (sealed=false), behaves like other containers.
 */
public class AmpuleItem extends AbstractContainerItem {

    public AmpuleItem(class_1793 settings) {
        super(settings, ContainerType.AMPULE);
    }

    public static boolean isSealed(class_1799 stack) {
        class_2487 nbt = stack.method_7969();
        if (nbt == null) return true; // ampules are sealed by default
        return nbt.method_10577("sealed") || !nbt.method_10545("sealed");
    }

    public static void setSealed(class_1799 stack, boolean sealed) {
        stack.method_7948().method_10556("sealed", sealed);
    }

    @Override
    protected boolean canDrinkFrom(class_1799 stack) {
        return !isSealed(stack);
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        class_2561 baseName = super.method_7864(stack);
        if (isSealed(stack)) {
            return class_2561.method_43470("Sealed ").method_10852(baseName);
        }
        return baseName;
    }

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 context) {
        if (isSealed(stack)) {
            tooltip.add(class_2561.method_43470("Sealed — use Pliers to open").method_27692(class_124.field_1061));
        } else {
            tooltip.add(class_2561.method_43470("Opened").method_27692(class_124.field_1060));
        }
        super.method_7851(stack, world, tooltip, context);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037();
        class_1657 player = context.method_8036();
        class_1799 stack = context.method_8041();

        if (player != null && player.method_5715() && hasContents(stack) && !isSealed(stack)) {
            return class_1269.field_5811;
        }

        // Place ampule block
        class_2338 placePos = pos.method_10093(context.method_8038());
        if (world.method_8320(placePos).method_45474()) {
            if (!world.field_9236) {
                class_2680 state = ModBlocks.AMPULE.method_9564()
                        .method_11657(AmpuleBlock.FACING, player != null
                                ? player.method_5735().method_10153()
                                : context.method_8042().method_10153());
                world.method_8501(placePos, state);
                world.method_8396(null, placePos, class_3417.field_14843,
                        class_3419.field_15245, 1.0f, 1.5f);

                class_2586 be = world.method_8321(placePos);
                if (be instanceof AmpuleBlockEntity entity) {
                    entity.setMaxCapacityMl(containerType.getDefaultCapacityMl());
                    entity.setSealed(isSealed(stack));
                    Map<String, Double> contents = getContents(stack);
                    if (!contents.isEmpty()) {
                        entity.setContents(contents);
                    }
                    if (stack.method_7969() != null && stack.method_7969().method_10545("temperatureK")) {
                        entity.setTemperatureK(stack.method_7969().method_10574("temperatureK"));
                    }
                }

                if (player != null && !player.method_7337()) {
                    stack.method_7934(1);
                }
            }
            return class_1269.method_29236(world.field_9236);
        }

        return class_1269.field_5811;
    }
}
