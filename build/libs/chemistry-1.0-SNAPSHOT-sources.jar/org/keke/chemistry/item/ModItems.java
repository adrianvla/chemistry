package org.keke.chemistry.item;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.class_1747;
import net.minecraft.class_1761;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2378;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.keke.chemistry.Chemistry;
import org.keke.chemistry.block.ModBlocks;
import org.keke.chemistry.utils.BeakerSize;
import org.keke.chemistry.utils.BeakerMaterial;

public class ModItems {
    public static final class_1792 BEAKER = registerItem("beaker", new BeakerItem(new FabricItemSettings().method_7889(1)));

    // Internal render-only item, not obtainable by players
    public static final class_1792 BEAKER_LIQUID_ITEM = registerItem("beaker_liquid_item_block", new class_1792(new FabricItemSettings()));

    // Lab equipment block items
    public static final class_1792 REACTION_STATION_ITEM = registerItem("reaction_station",
            new class_1747(ModBlocks.REACTION_STATION, new FabricItemSettings()));
    public static final class_1792 FILTER_ITEM = registerItem("filter",
            new class_1747(ModBlocks.FILTER, new FabricItemSettings()));
    public static final class_1792 DISTILLATION_ITEM = registerItem("distillation",
            new class_1747(ModBlocks.DISTILLATION, new FabricItemSettings()));
    public static final class_1792 EVAPORATION_DISH_ITEM = registerItem("evaporation_dish",
            new class_1747(ModBlocks.EVAPORATION_DISH, new FabricItemSettings()));
    public static final class_1792 BUNSEN_BURNER_ITEM = registerItem("bunsen_burner",
            new class_1747(ModBlocks.BUNSEN_BURNER, new FabricItemSettings()));
    public static final class_1792 COOLING_BLOCK_ITEM = registerItem("cooling_block",
            new class_1747(ModBlocks.COOLING_BLOCK, new FabricItemSettings()));
    public static final class_1792 COMPOSITION_BLOCK_ITEM = registerItem("composition_block",
            new class_1747(ModBlocks.COMPOSITION_BLOCK, new FabricItemSettings()));
    public static final class_1792 PIPETTE_BLOCK_ITEM = registerItem("pipette_block",
            new class_1747(ModBlocks.PIPETTE_BLOCK, new FabricItemSettings()));
    public static final class_1792 PETRI_DISH_ITEM = registerItem("petri_dish",
            new class_1747(ModBlocks.PETRI_DISH, new FabricItemSettings()));
    public static final class_1792 SEDIMENTATION_BLOCK_ITEM = registerItem("sedimentation_block",
            new class_1747(ModBlocks.SEDIMENTATION_BLOCK, new FabricItemSettings()));
    public static final class_1792 VIBRATING_BLOCK_ITEM = registerItem("vibrating_block",
            new class_1747(ModBlocks.VIBRATING_BLOCK, new FabricItemSettings()));

    // New container items
    public static final class_1792 TEST_TUBE = registerItem("test_tube",
            new TestTubeItem(new FabricItemSettings().method_7889(1)));
    public static final class_1792 AMPULE = registerItem("ampule",
            new AmpuleItem(new FabricItemSettings().method_7889(1)));
    public static final class_1792 BOTTLE_ITEM = registerItem("bottle",
            new BottleItem(new FabricItemSettings().method_7889(1)));

    // Lab tools
    public static final class_1792 PLIERS = registerItem("pliers",
            new PliersItem(new FabricItemSettings().method_7889(1).method_7895(64)));
    public static final class_1792 WASH_BOTTLE = registerItem("wash_bottle",
            new WashBottleItem(new FabricItemSettings().method_7889(1)));

    // New lab equipment block items
    public static final class_1792 CRUCIBLE_ITEM = registerItem("crucible",
            new class_1747(ModBlocks.CRUCIBLE, new FabricItemSettings()));
    public static final class_1792 GAS_COLLECTOR_ITEM = registerItem("gas_collector",
            new class_1747(ModBlocks.GAS_COLLECTOR, new FabricItemSettings()));
    public static final class_1792 CONDENSER_ITEM = registerItem("condenser",
            new class_1747(ModBlocks.CONDENSER, new FabricItemSettings()));
    public static final class_1792 MORTAR_PESTLE_ITEM = registerItem("mortar_pestle",
            new class_1747(ModBlocks.MORTAR_PESTLE, new FabricItemSettings()));
    public static final class_1792 FUME_HOOD_ITEM = registerItem("fume_hood",
            new class_1747(ModBlocks.FUME_HOOD, new FabricItemSettings()));

    private static final class_1761 CONTAINERS = FabricItemGroup.builder()
            .method_47320(() -> new class_1799(BEAKER))
            .method_47321(class_2561.method_43471("itemGroup.chemistry.containers"))
            .method_47317((context, entries) -> {
                entries.method_45420(new class_1799(BEAKER));
                // All beaker sizes
                for (BeakerSize size : BeakerSize.values()) {
                    if (size != BeakerSize.MEDIUM) { // MEDIUM is the default "Beaker"
                        class_1799 sizedBeaker = new class_1799(BEAKER);
                        BeakerItem.setBeakerSize(sizedBeaker, size);
                        entries.method_45420(sizedBeaker);
                    }
                }
                // Metal beakers (all sizes)
                for (BeakerSize size : BeakerSize.values()) {
                    class_1799 metalBeaker = new class_1799(BEAKER);
                    BeakerItem.setBeakerSize(metalBeaker, size);
                    BeakerItem.setBeakerMaterial(metalBeaker, BeakerMaterial.METAL);
                    entries.method_45420(metalBeaker);
                }
                // Pre-filled example beakers
                entries.method_45420(createFilledBeaker("H2O", 1.0));
                entries.method_45420(createFilledBeaker("HCl", 1.0));
                entries.method_45420(createFilledBeaker("NaOH", 1.0));
                entries.method_45420(createFilledBeaker("CuSO4", 1.0));
                entries.method_45420(createFilledBeaker("KMnO4", 0.5));
                entries.method_45420(createFilledBeaker("FeCl3", 1.0));
                entries.method_45420(createFilledBeaker("H2SO4", 1.0));
                entries.method_45420(createFilledBeaker("NaCl", 1.0));
                entries.method_45420(createFilledBeaker("AgNO3", 1.0));
                entries.method_45420(createFilledBeaker("Ca(OH)2", 1.0));
                // Lab equipment
                entries.method_45420(new class_1799(REACTION_STATION_ITEM));
                entries.method_45420(new class_1799(FILTER_ITEM));
                entries.method_45420(new class_1799(DISTILLATION_ITEM));
                entries.method_45420(new class_1799(EVAPORATION_DISH_ITEM));
                entries.method_45420(new class_1799(BUNSEN_BURNER_ITEM));
                entries.method_45420(new class_1799(COOLING_BLOCK_ITEM));
                entries.method_45420(new class_1799(COMPOSITION_BLOCK_ITEM));
                entries.method_45420(new class_1799(PIPETTE_BLOCK_ITEM));
                entries.method_45420(new class_1799(PETRI_DISH_ITEM));
                entries.method_45420(new class_1799(SEDIMENTATION_BLOCK_ITEM));
                entries.method_45420(new class_1799(VIBRATING_BLOCK_ITEM));
                // New containers
                entries.method_45420(new class_1799(TEST_TUBE));
                entries.method_45420(new class_1799(AMPULE));
                entries.method_45420(new class_1799(BOTTLE_ITEM));
                // Lab tools
                entries.method_45420(new class_1799(PLIERS));
                entries.method_45420(new class_1799(WASH_BOTTLE));
                // New lab equipment
                entries.method_45420(new class_1799(CRUCIBLE_ITEM));
                entries.method_45420(new class_1799(GAS_COLLECTOR_ITEM));
                entries.method_45420(new class_1799(CONDENSER_ITEM));
                entries.method_45420(new class_1799(MORTAR_PESTLE_ITEM));
                entries.method_45420(new class_1799(FUME_HOOD_ITEM));
                // Pre-filled explosive compound examples
                entries.method_45420(createFilledBeaker("C3H5N3O9", 0.5));
                entries.method_45420(createFilledBeaker("C7H5N3O6", 1.0));
            })
            .method_47324();

    public static class_1799 createFilledBeaker(String formula, double moles) {
        class_1799 stack = new class_1799(BEAKER);
        class_2487 contentsNbt = new class_2487();
        contentsNbt.method_10549(formula, moles);
        stack.method_7948().method_10566("contents", contentsNbt);
        return stack;
    }

    private static class_1792 registerItem(String name, class_1792 item) {
        return class_2378.method_10230(class_7923.field_41178, new class_2960(Chemistry.MOD_ID, name), item);
    }

    private static class_1761 registerItemGroup(String name, class_1761 group) {
        return class_2378.method_10230(class_7923.field_44687, new class_2960(Chemistry.MOD_ID, name), group);
    }

    public static void registerModItems() {
        Chemistry.LOGGER.info("Registering items for " + Chemistry.MOD_ID);
        registerItemGroup("beakers", CONTAINERS);
    }
}
