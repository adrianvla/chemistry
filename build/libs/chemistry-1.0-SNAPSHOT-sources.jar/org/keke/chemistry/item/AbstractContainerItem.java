package org.keke.chemistry.item;

import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.utils.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * Base class for all chemistry container items (test tube, ampule, bottle).
 * Shares the NBT contents format with BeakerItem for interoperability.
 *
 * NBT format:
 *   contents: { "H2O": 1.0, "NaCl": 0.5, ... }
 *   temperatureK: 293.15
 *   containerType: "TEST_TUBE" | "AMPULE" | "BOTTLE"
 *   sealed: true/false (ampules only)
 */
public abstract class AbstractContainerItem extends class_1792 {

    protected final ContainerType containerType;

    protected AbstractContainerItem(class_1793 settings, ContainerType containerType) {
        super(settings);
        this.containerType = containerType;
    }

    public ContainerType getContainerType() {
        return containerType;
    }

    // ── Contents helpers (shared with BeakerItem format) ───────────────

    public static Map<String, Double> getContents(class_1799 stack) {
        Map<String, Double> map = new LinkedHashMap<>();
        class_2487 nbt = stack.method_7969();
        if (nbt == null) return map;

        if (nbt.method_10573("contents", class_2520.field_33260)) {
            class_2487 contentsNbt = nbt.method_10562("contents");
            for (String key : contentsNbt.method_10541()) {
                double val = contentsNbt.method_10574(key);
                if (val > 0.001) map.put(key, val);
            }
        }
        return map;
    }

    public static void setContents(class_1799 stack, Map<String, Double> contents) {
        class_2487 nbt = stack.method_7948();
        class_2487 contentsNbt = new class_2487();
        for (var entry : contents.entrySet()) {
            if (entry.getValue() > 0.001) {
                contentsNbt.method_10549(entry.getKey(), entry.getValue());
            }
        }
        nbt.method_10566("contents", contentsNbt);
    }

    public static void clearContents(class_1799 stack) {
        setContents(stack, Map.of());
    }

    public static boolean hasContents(class_1799 stack) {
        return !getContents(stack).isEmpty();
    }

    public static double getTemperatureK(class_1799 stack) {
        class_2487 nbt = stack.method_7969();
        return (nbt != null && nbt.method_10545("temperatureK"))
                ? nbt.method_10574("temperatureK") : 293.15;
    }

    public static void setTemperatureK(class_1799 stack, double tempK) {
        stack.method_7948().method_10549("temperatureK", tempK);
    }

    // ── Display name ───────────────────────────────────────────────────

    @Override
    public class_2561 method_7864(class_1799 stack) {
        Map<String, Double> contents = getContents(stack);
        String baseName = containerType.getDisplayName();

        if (contents.isEmpty()) {
            return class_2561.method_43470(baseName);
        }

        StringBuilder sb = new StringBuilder();
        sb.append(baseName).append(" (");
        boolean first = true;
        for (String formula : contents.keySet()) {
            if (!first) sb.append(", ");
            String iupac = IUPACNamer.getName(formula);
            sb.append(iupac.equals(formula) ? FormulaUtils.formatFormula(formula) : iupac);
            first = false;
        }
        sb.append(")");
        return class_2561.method_43470(sb.toString());
    }

    // ── Tooltip ────────────────────────────────────────────────────────

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 context) {
        Map<String, Double> contents = getContents(stack);

        tooltip.add(class_2561.method_43470(String.format("Capacity: %.0f mL", containerType.getDefaultCapacityMl()))
                .method_27692(class_124.field_1063));

        if (contents.isEmpty()) {
            tooltip.add(class_2561.method_43470("Empty").method_27692(class_124.field_1080));
        } else {
            tooltip.add(class_2561.method_43470("Contents:").method_27692(class_124.field_1075));
            double totalMassG = 0;
            double totalVolumeMl = 0;
            double tempK = getTemperatureK(stack);

            for (var entry : contents.entrySet()) {
                String formatted = FormulaUtils.formatFormula(entry.getKey());
                double moles = entry.getValue();
                double molarMass = Compound.computeMolarMass(entry.getKey());
                double massG = moles * molarMass;
                double density = CompoundPhysicalData.getDensity(entry.getKey(), tempK);
                if (density <= 0) density = 1.0;
                double volumeMl = massG / density;
                totalMassG += massG;
                totalVolumeMl += volumeMl;
                tooltip.add(class_2561.method_43470(String.format("  %s — %.2f mol, %.2f g",
                        formatted, moles, massG)).method_27692(class_124.field_1054));

                String iupacName = IUPACNamer.getName(entry.getKey());
                StateOfMatter state = CompoundPhysicalData.getStateAtTemperature(entry.getKey(), tempK);
                String stateTag = " [" + state.getDisplayName() + "]";
                if (!iupacName.equals(entry.getKey())) {
                    tooltip.add(class_2561.method_43470("    " + iupacName + stateTag).method_27692(class_124.field_1080));
                } else {
                    tooltip.add(class_2561.method_43470("    " + stateTag.trim()).method_27692(class_124.field_1080));
                }
            }
            tooltip.add(class_2561.method_43470(String.format("Total: %.2f g / %.2f mL",
                    totalMassG, totalVolumeMl)).method_27692(class_124.field_1065));

            double tempC = getTemperatureK(stack) - 273.15;
            class_124 tempColor = tempC > 50 ? class_124.field_1061
                    : tempC < 10 ? class_124.field_1078 : class_124.field_1080;
            tooltip.add(class_2561.method_43470(String.format("Temp: %.1f °C", tempC))
                    .method_27692(tempColor));
        }
    }

    // ── Drinking (only non-sealed containers) ──────────────────────────

    @Override
    public class_1839 method_7853(class_1799 stack) {
        if (!hasContents(stack)) return class_1839.field_8952;
        if (!canDrinkFrom(stack)) return class_1839.field_8952;
        return class_1839.field_8946;
    }

    @Override
    public int method_7881(class_1799 stack) {
        return (hasContents(stack) && canDrinkFrom(stack)) ? 32 : 0;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        if (hasContents(stack) && user.method_5715() && canDrinkFrom(stack)) {
            user.method_6019(hand);
            return class_1271.method_22428(stack);
        }
        return class_1271.method_22430(stack);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (!world.field_9236) {
            Map<String, Double> contents = getContents(stack);
            if (!contents.isEmpty()) {
                DrinkingEffects.applyEffects(user, contents);
                double tempK = getTemperatureK(stack);
                double totalMoles = contents.values().stream()
                        .mapToDouble(Double::doubleValue).sum();
                DrinkingEffects.applyTemperatureEffects(user, tempK, totalMoles);
                clearContents(stack);
                world.method_8396(null, user.method_24515(),
                        class_3417.field_20613, class_3419.field_15248,
                        1.0f, 1.0f);
            }
        }
        return stack;
    }

    /**
     * Whether the container can be drunk from in its current state.
     * Sealed ampules cannot be drunk from.
     */
    protected boolean canDrinkFrom(class_1799 stack) {
        return true;
    }
}
