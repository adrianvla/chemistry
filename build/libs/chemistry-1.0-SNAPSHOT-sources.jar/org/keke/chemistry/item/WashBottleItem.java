package org.keke.chemistry.item;

import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.util.*;
import org.keke.chemistry.entity.AbstractChemistryContainer;

/**
 * Wash Bottle — a squeezable bottle that dispenses distilled H₂O in small amounts.
 *
 * Holds a fixed reservoir of water. Right-click on a chemistry container (block entity)
 * to squirt a configurable amount of water into it.
 *
 * NBT:
 *   waterMl: remaining water in the bottle (starts at 500 mL)
 *
 * The wash bottle can be refilled by sneak+right-clicking a water source block.
 */
public class WashBottleItem extends class_1792 {

    private static final double MAX_WATER_ML = 500.0;
    private static final double SQUIRT_ML = 5.0;  // ~0.28 mol H2O per squirt
    private static final double WATER_DENSITY = 1.0; // g/mL
    private static final double WATER_MOLAR_MASS = 18.015; // g/mol

    public WashBottleItem(class_1793 settings) {
        super(settings);
    }

    // ── Water level ────────────────────────────────────────────────────

    public static double getWaterMl(class_1799 stack) {
        class_2487 nbt = stack.method_7969();
        if (nbt == null || !nbt.method_10545("waterMl")) return MAX_WATER_ML;
        return nbt.method_10574("waterMl");
    }

    public static void setWaterMl(class_1799 stack, double ml) {
        stack.method_7948().method_10549("waterMl", Math.max(0, Math.min(MAX_WATER_ML, ml)));
    }

    // ── Use on container blocks ────────────────────────────────────────

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_1657 player = context.method_8036();
        class_1799 stack = context.method_8041();

        if (world.field_9236) return class_1269.field_5812;

        double waterMl = getWaterMl(stack);
        if (waterMl < SQUIRT_ML) {
            if (player != null) {
                player.method_7353(class_2561.method_43470("Wash bottle is empty").method_27692(class_124.field_1061), true);
            }
            return class_1269.field_5814;
        }

        // Try to dispense water into a chemistry container
        var be = world.method_8321(context.method_8037());
        if (be instanceof AbstractChemistryContainer container) {
            // Calculate moles of water to add
            double massG = SQUIRT_ML * WATER_DENSITY;
            double molesH2O = massG / WATER_MOLAR_MASS;

            container.addChemical("H2O", molesH2O);
            setWaterMl(stack, waterMl - SQUIRT_ML);

            world.method_8396(null, context.method_8037(),
                    class_3417.field_14826, class_3419.field_15248,
                    0.5f, 1.5f);

            if (player != null) {
                player.method_7353(class_2561.method_43470(String.format("Dispensed %.1f mL H₂O (%.0f mL remaining)",
                        SQUIRT_ML, waterMl - SQUIRT_ML)).method_27692(class_124.field_1075), true);
            }

            return class_1269.field_5812;
        }

        // Sneak + right-click water-source block → refill
        if (player != null && player.method_5715()) {
            var blockState = world.method_8320(context.method_8037());
            if (blockState.method_26204() == net.minecraft.class_2246.field_10382) {
                setWaterMl(stack, MAX_WATER_ML);
                world.method_8396(null, context.method_8037(),
                        class_3417.field_14779, class_3419.field_15248,
                        1.0f, 1.0f);
                if (player != null) {
                    player.method_7353(class_2561.method_43470("Wash bottle refilled").method_27692(class_124.field_1060), true);
                }
                return class_1269.field_5812;
            }
        }

        return class_1269.field_5811;
    }

    @Override
    public class_2561 method_7864(class_1799 stack) {
        double waterMl = getWaterMl(stack);
        return class_2561.method_43470(String.format("Wash Bottle (%.0f mL)", waterMl));
    }
}
