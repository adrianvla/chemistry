package org.keke.chemistry.item;

import org.keke.chemistry.block.ModBlocks;
import org.keke.chemistry.block.TestTubeBlock;
import org.keke.chemistry.entity.TestTubeBlockEntity;
import org.keke.chemistry.utils.ContainerType;

import java.util.Map;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Test Tube — a small (25 mL) throwable container for small-scale reactions.
 *
 * Interactions:
 *   - Right-click surface: place as block
 *   - Sneak + right-click: drink
 *   - Throwable (handled via dispenser-style throw — see ThrownContainerEntity)
 */
public class TestTubeItem extends AbstractContainerItem {

    public TestTubeItem(class_1793 settings) {
        super(settings, ContainerType.TEST_TUBE);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037();
        class_1657 player = context.method_8036();
        class_1799 stack = context.method_8041();

        // Sneaking? Pass through to drink handler
        if (player != null && player.method_5715() && hasContents(stack)) {
            return class_1269.field_5811;
        }

        // Place test tube block
        class_2338 placePos = pos.method_10093(context.method_8038());
        if (world.method_8320(placePos).method_45474()) {
            if (!world.field_9236) {
                class_2680 state = ModBlocks.TEST_TUBE.method_9564()
                        .method_11657(TestTubeBlock.FACING, player != null
                                ? player.method_5735().method_10153()
                                : context.method_8042().method_10153());
                world.method_8501(placePos, state);
                world.method_8396(null, placePos, class_3417.field_14843,
                        class_3419.field_15245, 1.0f, 1.2f);

                class_2586 be = world.method_8321(placePos);
                if (be instanceof TestTubeBlockEntity entity) {
                    entity.setMaxCapacityMl(containerType.getDefaultCapacityMl());
                    Map<String, Double> contents = getContents(stack);
                    if (!contents.isEmpty()) {
                        entity.setContents(contents);
                    }
                    if (stack.method_7969() != null && stack.method_7969().method_10545("temperatureK")) {
                        entity.setTemperatureK(stack.method_7969().method_10574("temperatureK"));
                    }
                }

                if (player != null && !player.method_7337()) {
                    stack.method_7934(1);
                }
            }
            return class_1269.method_29236(world.field_9236);
        }

        return class_1269.field_5811;
    }
}
