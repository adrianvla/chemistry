package org.keke.chemistry.item;

import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_1838;
import net.minecraft.class_1839;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3914;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.block.BeakerBase;
import org.keke.chemistry.block.ModBlocks;
import org.keke.chemistry.entity.BeakerLiquidBlockEntity;
import org.keke.chemistry.screen.PouringScreenHandler;
import org.keke.chemistry.utils.Compound;
import org.keke.chemistry.utils.BeakerSize;
import org.keke.chemistry.utils.CompoundPhysicalData;
import org.keke.chemistry.utils.DrinkingEffects;
import org.keke.chemistry.utils.FormulaUtils;
import org.keke.chemistry.utils.IUPACNamer;
import org.keke.chemistry.utils.StateOfMatter;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

/**
 * BeakerItem — a placeable, drinkable item that stores multiple chemical contents in NBT.
 *
 * NBT format:
 *   contents: { "H2O": 1.0, "NaCl": 0.5, ... }
 *   temperatureK: 293.15
 *
 * Backward-compatible with old format: formula/moles top-level tags.
 *
 * Interactions:
 *   Right-click on placed beaker → pour contents
 *   Right-click on surface → place beaker
 *   Sneak + right-click (not on beaker) → drink contents
 */
public class BeakerItem extends class_1792 {

    public BeakerItem(class_1793 settings) {
        super(settings);
    }

    // ── Contents helpers ───────────────────────────────────────────────

    /**
     * Read the multi-reactant contents map from item NBT.
     * Handles backward compat with old single-formula format.
     */
    public static Map<String, Double> getContents(class_1799 stack) {
        Map<String, Double> map = new LinkedHashMap<>();
        class_2487 nbt = stack.method_7969();
        if (nbt == null) return map;

        if (nbt.method_10573("contents", class_2520.field_33260)) {
            class_2487 contentsNbt = nbt.method_10562("contents");
            for (String key : contentsNbt.method_10541()) {
                double val = contentsNbt.method_10574(key);
                if (val > 0.001) map.put(key, val);
            }
        } else if (nbt.method_10545("formula")) {
            String formula = nbt.method_10558("formula");
            double moles = nbt.method_10574("moles");
            if (!formula.isEmpty() && moles > 0.001) map.put(formula, moles);
        }
        return map;
    }

    /**
     * Write the contents map to item NBT.
     */
    public static void setContents(class_1799 stack, Map<String, Double> contents) {
        class_2487 nbt = stack.method_7948();
        class_2487 contentsNbt = new class_2487();
        for (var entry : contents.entrySet()) {
            if (entry.getValue() > 0.001) {
                contentsNbt.method_10549(entry.getKey(), entry.getValue());
            }
        }
        nbt.method_10566("contents", contentsNbt);
        // Remove legacy keys
        nbt.method_10551("formula");
        nbt.method_10551("moles");
    }

    /**
     * Clear all contents from the item.
     */
    public static void clearContents(class_1799 stack) {
        setContents(stack, Map.of());
    }

    public static boolean hasContents(class_1799 stack) {
        return !getContents(stack).isEmpty();
    }

    /**
     * Get the beaker size (capacity) stored in NBT, defaulting to MEDIUM (250 mL).
     */
    public static BeakerSize getBeakerSize(class_1799 stack) {
        class_2487 nbt = stack.method_7969();
        if (nbt != null && nbt.method_10545("maxCapacityMl")) {
            return BeakerSize.fromCapacity(nbt.method_10574("maxCapacityMl"));
        }
        return BeakerSize.MEDIUM;
    }

    /**
     * Set the beaker size by storing maxCapacityMl in NBT.
     */
    public static void setBeakerSize(class_1799 stack, BeakerSize size) {
        stack.method_7948().method_10549("maxCapacityMl", size.getCapacityMl());
    }

    /**
     * Get the temperature in Kelvin stored in item NBT (defaults to ambient 293.15 K).
     */
    public static double getTemperatureK(class_1799 stack) {
        class_2487 nbt = stack.method_7969();
        return (nbt != null && nbt.method_10545("temperatureK"))
                ? nbt.method_10574("temperatureK") : 293.15;
    }

    // ── Auto-naming ────────────────────────────────────────────────────

    @Override
    public class_2561 method_7864(class_1799 stack) {
        Map<String, Double> contents = getContents(stack);
        BeakerSize size = getBeakerSize(stack);
        String sizeLabel = (size == BeakerSize.MEDIUM) ? "Beaker" : size.getDisplayName();
        if (contents.isEmpty()) {
            return class_2561.method_43470(sizeLabel);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(sizeLabel).append(" (");
        boolean first = true;
        for (String formula : contents.keySet()) {
            if (!first) sb.append(", ");
            String iupac = IUPACNamer.getName(formula);
            sb.append(iupac.equals(formula) ? FormulaUtils.formatFormula(formula) : iupac);
            first = false;
        }
        sb.append(")");
        return class_2561.method_43470(sb.toString());
    }

    // ── Drinking ───────────────────────────────────────────────────────

    @Override
    public class_1839 method_7853(class_1799 stack) {
        return hasContents(stack) ? class_1839.field_8946 : class_1839.field_8952;
    }

    @Override
    public int method_7881(class_1799 stack) {
        return hasContents(stack) ? 32 : 0;
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 stack = user.method_5998(hand);
        if (hasContents(stack) && user.method_5715()) {
            user.method_6019(hand);
            return class_1271.method_22428(stack);
        }
        return class_1271.method_22430(stack);
    }

    @Override
    public class_1799 method_7861(class_1799 stack, class_1937 world, class_1309 user) {
        if (!world.field_9236) {
            Map<String, Double> contents = getContents(stack);
            if (!contents.isEmpty()) {
                DrinkingEffects.applyEffects(user, contents);

                // Apply temperature-based drinking effects
                double tempK = getTemperatureK(stack);
                double totalMoles = contents.values().stream()
                        .mapToDouble(Double::doubleValue).sum();
                DrinkingEffects.applyTemperatureEffects(user, tempK, totalMoles);

                clearContents(stack);
                world.method_8396(null, user.method_24515(),
                        class_3417.field_20613, class_3419.field_15248,
                        1.0f, 1.0f);
            }
        }
        return stack;
    }

    // ── Block interaction ──────────────────────────────────────────────

    @Override
    public class_1269 method_7884(class_1838 context) {
        class_1937 world = context.method_8045();
        class_2338 pos = context.method_8037();
        class_2680 targetState = world.method_8320(pos);
        class_1657 player = context.method_8036();
        class_1799 stack = context.method_8041();

        // If clicking on a placed beaker with a filled beaker, open pouring GUI
        if (targetState.method_26204() instanceof BeakerBase) {
            if (!world.field_9236 && player instanceof class_3222 serverPlayer) {
                class_2586 be = world.method_8321(pos);
                if (be instanceof BeakerLiquidBlockEntity) {
                    Map<String, Double> itemContents = getContents(stack);
                    if (!itemContents.isEmpty()) {
                        // Open the pouring screen
                        serverPlayer.method_17355(new net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory() {
                            @Override
                            public class_2561 method_5476() {
                                return class_2561.method_43470("Pour Beaker");
                            }

                            @Override
                            public class_1703 createMenu(int syncId,
                                    net.minecraft.class_1661 inventory,
                                    class_1657 p) {
                                return new PouringScreenHandler(syncId, inventory,
                                        class_3914.method_17392(world, pos), pos);
                            }

                            @Override
                            public void writeScreenOpeningData(class_3222 p, class_2540 buf) {
                                buf.method_10807(pos);
                            }
                        });
                    }
                }
            }
            return class_1269.method_29236(world.field_9236);
        }

        // If sneaking on non-beaker → pass through to use() for drinking
        if (player != null && player.method_5715() && hasContents(stack)) {
            return class_1269.field_5811;
        }

        // Place a new beaker block
        class_2338 placePos = pos.method_10093(context.method_8038());
        if (world.method_8320(placePos).method_45474()) {
            if (!world.field_9236) {
                class_2680 beakerState = ModBlocks.BEAKER_BASE.method_9564()
                        .method_11657(BeakerBase.FACING, player != null
                                ? player.method_5735().method_10153()
                                : context.method_8042().method_10153());
                world.method_8501(placePos, beakerState);
                world.method_8396(null, placePos, class_3417.field_14843,
                        class_3419.field_15245, 1.0f, 1.0f);

                // Transfer item contents, temperature, and capacity to placed block entity
                class_2586 be = world.method_8321(placePos);
                if (be instanceof BeakerLiquidBlockEntity beakerEntity) {
                    // Set capacity before contents so volume checking uses correct limit
                    BeakerSize size = getBeakerSize(stack);
                    beakerEntity.setMaxCapacityMl(size.getCapacityMl());

                    Map<String, Double> contents = getContents(stack);
                    if (!contents.isEmpty()) {
                        beakerEntity.setContents(contents);
                    }
                    class_2487 itemNbt = stack.method_7969();
                    if (itemNbt != null && itemNbt.method_10545("temperatureK")) {
                        beakerEntity.setTemperatureK(itemNbt.method_10574("temperatureK"));
                    }
                }

                if (player != null && !player.method_7337()) {
                    stack.method_7934(1);
                }
            }
            return class_1269.method_29236(world.field_9236);
        }

        return class_1269.field_5811;
    }

    // ── Tooltips ───────────────────────────────────────────────────────

    @Override
    public void method_7851(class_1799 stack, @Nullable class_1937 world, List<class_2561> tooltip, class_1836 context) {
        Map<String, Double> contents = getContents(stack);

        if (contents.isEmpty()) {
            tooltip.add(class_2561.method_43470("Empty").method_27692(class_124.field_1080));
        } else {
            tooltip.add(class_2561.method_43470("Contents:").method_27692(class_124.field_1075));
            double totalMassG = 0;
            double totalVolumeMl = 0;
            class_2487 itemNbt = stack.method_7969();
            double tempK = (itemNbt != null && itemNbt.method_10545("temperatureK"))
                    ? itemNbt.method_10574("temperatureK") : 293.15;
            for (var entry : contents.entrySet()) {
                String formatted = FormulaUtils.formatFormula(entry.getKey());
                double moles = entry.getValue();
                double molarMass = Compound.computeMolarMass(entry.getKey());
                double massG = moles * molarMass;
                double density = CompoundPhysicalData.getDensity(entry.getKey(), tempK);
                if (density <= 0) density = 1.0;
                double volumeMl = massG / density;
                totalMassG += massG;
                totalVolumeMl += volumeMl;
                tooltip.add(class_2561.method_43470(String.format("  %s — %.2f mol, %.2f g, %.2f mL",
                        formatted, moles, massG, volumeMl)).method_27692(class_124.field_1054));
                String iupacName = IUPACNamer.getName(entry.getKey());
                StateOfMatter state = CompoundPhysicalData.getStateAtTemperature(entry.getKey(), tempK);
                String stateTag = " [" + state.getDisplayName() + "]";
                if (!iupacName.equals(entry.getKey())) {
                    tooltip.add(class_2561.method_43470("    " + iupacName + stateTag).method_27692(class_124.field_1080));
                } else {
                    tooltip.add(class_2561.method_43470("    " + stateTag.trim()).method_27692(class_124.field_1080));
                }
            }
            double maxCapMl = (itemNbt != null && itemNbt.method_10545("maxCapacityMl"))
                    ? itemNbt.method_10574("maxCapacityMl") : 250.0;
            tooltip.add(class_2561.method_43470(String.format("Total: %.2f g / %.2f mL (%.0f mL beaker)",
                    totalMassG, totalVolumeMl, maxCapMl))
                    .method_27692(class_124.field_1065));

            class_2487 nbt = stack.method_7969();
            if (nbt != null && nbt.method_10545("temperatureK")) {
                double tempC = nbt.method_10574("temperatureK") - 273.15;
                class_124 tempColor = tempC > 50 ? class_124.field_1061
                        : tempC < 10 ? class_124.field_1078 : class_124.field_1080;
                tooltip.add(class_2561.method_43470(String.format("Temp: %.1f °C", tempC))
                        .method_27692(tempColor));
            }

            tooltip.add(class_2561.method_43470("Sneak + Use to drink").method_27692(class_124.field_1063));
        }
    }
}
