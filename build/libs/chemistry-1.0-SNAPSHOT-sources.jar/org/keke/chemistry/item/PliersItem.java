package org.keke.chemistry.item;

import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1838;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Pliers — a tool used to open sealed ampules.
 *
 * Right-click a sealed ampule in the off-hand (or vice versa) to break the seal.
 * The pliers have durability and lose 1 point per use.
 */
public class PliersItem extends class_1792 {

    public PliersItem(class_1793 settings) {
        super(settings);
    }

    @Override
    public class_1271<class_1799> method_7836(class_1937 world, class_1657 user, class_1268 hand) {
        class_1799 pliers = user.method_5998(hand);
        class_1268 otherHand = (hand == class_1268.field_5808) ? class_1268.field_5810 : class_1268.field_5808;
        class_1799 other = user.method_5998(otherHand);

        if (other.method_7909() instanceof AmpuleItem && AmpuleItem.isSealed(other)) {
            if (!world.field_9236) {
                AmpuleItem.setSealed(other, false);
                pliers.method_7956(1, user, (entity) ->
                        entity.method_20236(hand));
                world.method_8396(null, user.method_24515(),
                        class_3417.field_15081, class_3419.field_15248,
                        0.5f, 1.8f);
                user.method_7353(class_2561.method_43470("Ampule opened").method_27692(class_124.field_1060), true);
            }
            return class_1271.method_29237(pliers, world.field_9236);
        }

        return class_1271.method_22430(pliers);
    }

    @Override
    public class_1269 method_7884(class_1838 context) {
        // Pliers can also open ampule blocks in the world
        // (handled via AmpuleBlock.onUse detecting pliers)
        return class_1269.field_5811;
    }
}
