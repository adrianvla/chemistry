package org.keke.chemistry.screen;

import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_3914;
import org.keke.chemistry.block.ModBlocks;

/**
 * Screen handler for the Precise Extraction (Pipette) block.
 * Non-slot screen handler — GUI has text fields to specify which
 * compound and how many moles/grams to withdraw from the beaker above.
 */
public class PipetteScreenHandler extends class_1703 {

    private final class_3914 context;
    private final class_2338 blockPos;

    /** Client-side constructor — receives block pos from ExtendedScreenHandlerType. */
    public PipetteScreenHandler(int syncId, class_1661 playerInventory, class_2338 pos) {
        super(ModScreenHandlers.PIPETTE, syncId);
        this.context = class_3914.field_17304;
        this.blockPos = pos;
    }

    /** Server-side constructor. */
    public PipetteScreenHandler(int syncId, class_1661 playerInventory, class_3914 context, class_2338 pos) {
        super(ModScreenHandlers.PIPETTE, syncId);
        this.context = context;
        this.blockPos = pos;
    }

    public class_2338 getBlockPos() {
        return blockPos;
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037;
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return method_17695(context, player, ModBlocks.PIPETTE_BLOCK);
    }
}
