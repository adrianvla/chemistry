package org.keke.chemistry.screen;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerType;
import net.minecraft.class_2338;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3917;
import net.minecraft.class_7923;
import org.keke.chemistry.Chemistry;

/**
 * Registry for all screen handler types in the Chemistry mod.
 * Uses ExtendedScreenHandlerType to forward the block position to the client.
 */
public class ModScreenHandlers {

    public static final class_3917<CompositionScreenHandler> COMPOSITION =
            class_2378.method_10230(class_7923.field_41187,
                    new class_2960(Chemistry.MOD_ID, "composition"),
                    new ExtendedScreenHandlerType<>((syncId, inv, buf) -> {
                        var pos = buf.method_10811();
                        return new CompositionScreenHandler(syncId, inv, pos);
                    }));

    public static final class_3917<PipetteScreenHandler> PIPETTE =
            class_2378.method_10230(class_7923.field_41187,
                    new class_2960(Chemistry.MOD_ID, "pipette"),
                    new ExtendedScreenHandlerType<>((syncId, inv, buf) -> {
                        var pos = buf.method_10811();
                        return new PipetteScreenHandler(syncId, inv, pos);
                    }));

    public static final class_3917<PouringScreenHandler> POURING =
            class_2378.method_10230(class_7923.field_41187,
                    new class_2960(Chemistry.MOD_ID, "pouring"),
                    new ExtendedScreenHandlerType<>((syncId, inv, buf) -> {
                        var pos = buf.method_10811();
                        return new PouringScreenHandler(syncId, inv, pos);
                    }));

    public static void registerAll() {
        Chemistry.LOGGER.info("Registering screen handlers for " + Chemistry.MOD_ID);
    }
}
