package org.keke.chemistry.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_5676;
import io.netty.buffer.Unpooled;
import java.util.Map;
import org.keke.chemistry.network.ModNetworking;
import org.keke.chemistry.screen.CompositionScreenHandler;
import org.keke.chemistry.utils.Compound;
import org.keke.chemistry.utils.FormulaParser;

/**
 * Client-side GUI for the Chemical Composer block.
 * Contains a text field for formula input, amount input,
 * a moles/grams toggle, and an Add button.
 */
@Environment(EnvType.CLIENT)
public class CompositionScreen extends class_465<CompositionScreenHandler> {

    private class_342 formulaField;
    private class_342 amountField;
    private boolean useGrams = false;
    private String statusMessage = "";
    private int statusColor = 0xFFFFFF;

    public CompositionScreen(CompositionScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2792 = 200;
        this.field_2779 = 140;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int cx = (this.field_22789 - this.field_2792) / 2;
        int cy = (this.field_22790 - this.field_2779) / 2;

        // Formula input field
        formulaField = new class_342(this.field_22793, cx + 10, cy + 25, 180, 16, class_2561.method_43470("Formula"));
        formulaField.method_1880(128);
        formulaField.method_47404(class_2561.method_43470("e.g. H2SO4, (NH4)2[Ce(NO3)6]").method_27692(class_124.field_1063));
        this.method_37063(formulaField);

        // Amount input field
        amountField = new class_342(this.field_22793, cx + 10, cy + 55, 120, 16, class_2561.method_43470("Amount"));
        amountField.method_1880(16);
        amountField.method_47404(class_2561.method_43470("e.g. 1.0").method_27692(class_124.field_1063));
        this.method_37063(amountField);

        // Moles / Grams toggle
        class_5676<Boolean> unitToggle = class_5676.method_32607(
                class_2561.method_43470("g"), class_2561.method_43470("mol"))
                .method_32619(false)
                .method_32617(cx + 135, cy + 55, 55, 16, class_2561.method_43470("Unit"),
                        (button, value) -> useGrams = value);
        this.method_37063(unitToggle);

        // Add button
        class_4185 addButton = class_4185.method_46430(class_2561.method_43470("Add to Beaker"), button -> {
            onAddClicked();
        }).method_46434(cx + 10, cy + 85, 180, 20).method_46431();
        this.method_37063(addButton);

        method_48265(formulaField);
    }

    private void onAddClicked() {
        String formula = formulaField.method_1882().trim();
        String amountStr = amountField.method_1882().trim();

        if (formula.isEmpty()) {
            statusMessage = "Enter a formula";
            statusColor = 0xFF5555;
            return;
        }

        // Validate formula
        try {
            var parsed = FormulaParser.parse(formula);
            if (parsed.isEmpty()) {
                statusMessage = "Invalid formula";
                statusColor = 0xFF5555;
                return;
            }
        } catch (Exception e) {
            statusMessage = "Invalid formula: " + e.getMessage();
            statusColor = 0xFF5555;
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                statusMessage = "Amount must be positive";
                statusColor = 0xFF5555;
                return;
            }
        } catch (NumberFormatException e) {
            statusMessage = "Invalid number";
            statusColor = 0xFF5555;
            return;
        }

        // Send packet to server
        sendCompositionPacket(field_2797.getBlockPos(), formula, amount, useGrams);

        double molarMass = Compound.computeMolarMass(formula);
        double molesDisplay = useGrams ? amount / molarMass : amount;
        double gramsDisplay = useGrams ? amount : amount * molarMass;
        statusMessage = String.format("Sent: %.3f mol (%.2f g) of %s", molesDisplay, gramsDisplay, formula);
        statusColor = 0x55FF55;
    }

    private void sendCompositionPacket(class_2338 pos, String formula, double amount, boolean isGrams) {
        class_2540 buf = new class_2540(Unpooled.buffer());
        buf.method_10807(pos);
        buf.method_10814(formula);
        buf.writeDouble(amount);
        buf.writeBoolean(isGrams);
        ClientPlayNetworking.send(ModNetworking.COMPOSITION_ADD, buf);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int cx = (this.field_22789 - this.field_2792) / 2;
        int cy = (this.field_22790 - this.field_2779) / 2;

        // Dark background panel
        context.method_25294(cx, cy, cx + this.field_2792, cy + this.field_2779, 0xCC1A1A2E);
        // Border
        context.method_49601(cx, cy, this.field_2792, this.field_2779, 0xFF4A4A6A);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        // Title
        context.method_51439(this.field_22793, this.field_22785, 10, 6, 0x00FFAA, true);

        // Labels
        context.method_51439(this.field_22793, class_2561.method_43470("Formula:"), 10, 16, 0xCCCCCC, false);
        context.method_51439(this.field_22793, class_2561.method_43470("Amount:"), 10, 46, 0xCCCCCC, false);

        // Status message
        if (!statusMessage.isEmpty()) {
            context.method_51439(this.field_22793, class_2561.method_43470(statusMessage), 10, 112, statusColor, false);
        }

        // Show computed molar mass for current formula
        String formula = formulaField.method_1882().trim();
        if (!formula.isEmpty()) {
            try {
                var parsed = FormulaParser.parse(formula);
                if (!parsed.isEmpty()) {
                    double mm = Compound.computeMolarMass(formula);
                    context.method_51439(this.field_22793,
                            class_2561.method_43470(String.format("M = %.2f g/mol", mm)),
                            10, 126, 0x888888, false);
                }
            } catch (Exception ignored) {}
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        // Allow typing in text fields without closing the screen
        if (formulaField.method_25370() || amountField.method_25370()) {
            if (keyCode == 256) { // Escape
                this.method_25419();
                return true;
            }
            // Delegate to text fields for control keys (backspace, arrows, etc.)
            // but always return true to prevent super.keyPressed() from checking
            // the inventory keybind and closing the screen on 'e'
            formulaField.method_25404(keyCode, scanCode, modifiers);
            amountField.method_25404(keyCode, scanCode, modifiers);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
