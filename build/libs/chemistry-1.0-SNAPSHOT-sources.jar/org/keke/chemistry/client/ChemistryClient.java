package org.keke.chemistry.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.BlockEntityRendererRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.ColorProviderRegistry;
import net.minecraft.class_1921;
import net.minecraft.class_3929;
import org.keke.chemistry.block.ModBlocks;
import org.keke.chemistry.environement.BeakerLiquidBlockEntityRenderer;
import org.keke.chemistry.environement.ReactionStationBlockEntityRenderer;
import org.keke.chemistry.item.BeakerItem;
import org.keke.chemistry.item.ModItems;
import org.keke.chemistry.screen.ModScreenHandlers;
import org.keke.chemistry.utils.CalculateColor;

import java.util.Map;

import static org.keke.chemistry.entity.ModBlockEntities.BEAKER_LIQUID;
import static org.keke.chemistry.entity.ModBlockEntities.REACTION_STATION;

@Environment(EnvType.CLIENT)
public class ChemistryClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        // Render layers
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.BEAKER_BASE, class_1921.method_23583());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.REACTION_STATION, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.FILTER, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.DISTILLATION, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.EVAPORATION_DISH, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.BUNSEN_BURNER, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.COOLING_BLOCK, class_1921.method_23583());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.COMPOSITION_BLOCK, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.PIPETTE_BLOCK, class_1921.method_23581());
        BlockRenderLayerMap.INSTANCE.putBlock(ModBlocks.PETRI_DISH, class_1921.method_23583());

        // Block entity renderers
        BlockEntityRendererRegistry.register(BEAKER_LIQUID, BeakerLiquidBlockEntityRenderer::new);
        BlockEntityRendererRegistry.register(REACTION_STATION, ReactionStationBlockEntityRenderer::new);

        // Screen registrations
        class_3929.method_17542(ModScreenHandlers.COMPOSITION, CompositionScreen::new);
        class_3929.method_17542(ModScreenHandlers.PIPETTE, PipetteScreen::new);
        class_3929.method_17542(ModScreenHandlers.POURING, PouringScreen::new);

        // Color providers — uses new multi-reactant contents map
        ColorProviderRegistry.ITEM.register((stack, layer) -> {
            if (layer == 0) {
                Map<String, Double> contents = BeakerItem.getContents(stack);
                if (contents.isEmpty()) return 0xFFFFFF;
                return CalculateColor.calculateBlendedColor(contents);
            }
            return 0xFFFFFF;
        }, ModItems.BEAKER);

        ColorProviderRegistry.ITEM.register((stack, tintIndex) -> {
            return stack.method_7948().method_10550("cachedColor");
        }, ModItems.BEAKER_LIQUID_ITEM);
    }
}
