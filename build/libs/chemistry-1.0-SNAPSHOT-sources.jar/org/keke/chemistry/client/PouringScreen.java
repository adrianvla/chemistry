package org.keke.chemistry.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import io.netty.buffer.Unpooled;
import org.keke.chemistry.entity.BeakerLiquidBlockEntity;
import org.keke.chemistry.item.BeakerItem;
import org.keke.chemistry.network.ModNetworking;
import org.keke.chemistry.screen.PouringScreenHandler;
import org.keke.chemistry.utils.Compound;
import org.keke.chemistry.utils.IUPACNamer;

import java.util.*;
import java.util.Map.Entry;

/**
 * Client-side GUI for pouring chemicals between beakers.
 * Left panel shows the source beaker (held item) contents,
 * right panel shows the target beaker (placed block) contents and capacity.
 * The player can choose a compound and an amount to pour.
 */
@Environment(EnvType.CLIENT)
public class PouringScreen extends class_465<PouringScreenHandler> {

    private class_342 amountField;
    private String statusMessage = "";
    private int statusColor = 0xFFFFFF;

    /** Formulas available to pour from the source. */
    private List<String> sourceFormulas = new ArrayList<>();
    /** Currently selected formula index. */
    private int selectedIndex = 0;

    private final class_1661 playerInventory;

    public PouringScreen(PouringScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.playerInventory = inventory;
        this.field_2792 = 260;
        this.field_2779 = 180;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int cx = (this.field_22789 - this.field_2792) / 2;
        int cy = (this.field_22790 - this.field_2779) / 2;

        // Refresh source contents from held item
        refreshSourceContents();

        // Amount field
        amountField = new class_342(this.field_22793,
                cx + 10, cy + 130, 100, 16, class_2561.method_43470("Amount"));
        amountField.method_1880(16);
        amountField.method_47404(class_2561.method_43470("mol (0 = all)").method_27692(class_124.field_1063));
        this.method_37063(amountField);

        // Prev / Next compound buttons
        class_4185 prevBtn = class_4185.method_46430(class_2561.method_43470("<"), button -> {
            if (!sourceFormulas.isEmpty()) {
                selectedIndex = (selectedIndex - 1 + sourceFormulas.size()) % sourceFormulas.size();
            }
        }).method_46434(cx + 10, cy + 108, 20, 16).method_46431();
        this.method_37063(prevBtn);

        class_4185 nextBtn = class_4185.method_46430(class_2561.method_43470(">"), button -> {
            if (!sourceFormulas.isEmpty()) {
                selectedIndex = (selectedIndex + 1) % sourceFormulas.size();
            }
        }).method_46434(cx + 115, cy + 108, 20, 16).method_46431();
        this.method_37063(nextBtn);

        // Pour Selected button
        class_4185 pourBtn = class_4185.method_46430(class_2561.method_43470("Pour"), button -> {
            onPourClicked(false);
        }).method_46434(cx + 115, cy + 130, 50, 16).method_46431();
        this.method_37063(pourBtn);

        // Pour All button
        class_4185 pourAllBtn = class_4185.method_46430(class_2561.method_43470("Pour All"), button -> {
            onPourClicked(true);
        }).method_46434(cx + 170, cy + 130, 80, 16).method_46431();
        this.method_37063(pourAllBtn);

        method_48265(amountField);
    }

    private void refreshSourceContents() {
        sourceFormulas.clear();
        Map<String, Double> contents = BeakerItem.getContents(
                playerInventory.method_7391());
        sourceFormulas.addAll(contents.keySet());
        if (selectedIndex >= sourceFormulas.size()) {
            selectedIndex = 0;
        }
    }

    private void onPourClicked(boolean pourAll) {
        if (sourceFormulas.isEmpty()) {
            statusMessage = "Source beaker is empty";
            statusColor = 0xFF5555;
            return;
        }

        if (pourAll) {
            // Send pour-all packet
            sendPourPacket(field_2797.getBlockPos(), "", 0, true);
            statusMessage = "Pouring all contents...";
            statusColor = 0x55FF55;
            return;
        }

        String formula = sourceFormulas.get(selectedIndex);
        String amountStr = amountField.method_1882().trim();
        double amount = 0;  // 0 means all of this compound

        if (!amountStr.isEmpty()) {
            try {
                amount = Double.parseDouble(amountStr);
                if (amount < 0) {
                    statusMessage = "Amount must be ≥ 0";
                    statusColor = 0xFF5555;
                    return;
                }
            } catch (NumberFormatException e) {
                statusMessage = "Invalid number";
                statusColor = 0xFF5555;
                return;
            }
        }

        sendPourPacket(field_2797.getBlockPos(), formula, amount, false);

        if (amount <= 0) {
            statusMessage = String.format("Pouring all %s", formula);
        } else {
            statusMessage = String.format("Pouring %.3f mol of %s", amount, formula);
        }
        statusColor = 0x55FF55;
    }

    private void sendPourPacket(class_2338 pos, String formula, double amount, boolean pourAll) {
        class_2540 buf = new class_2540(Unpooled.buffer());
        buf.method_10807(pos);
        buf.method_10814(formula);
        buf.writeDouble(amount);
        buf.writeBoolean(pourAll);
        ClientPlayNetworking.send(ModNetworking.BEAKER_POUR, buf);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int cx = (this.field_22789 - this.field_2792) / 2;
        int cy = (this.field_22790 - this.field_2779) / 2;

        // Dark background panel
        context.method_25294(cx, cy, cx + field_2792, cy + field_2779, 0xCC1A1A2E);
        context.method_49601(cx, cy, field_2792, field_2779, 0xFF4A4A6A);

        // Divider between source and target panels
        int mid = cx + field_2792 / 2;
        context.method_25294(mid, cy + 20, mid + 1, cy + 100, 0xFF4A4A6A);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        // Title
        context.method_51439(field_22793, class_2561.method_43470("Pour Between Beakers"),
                10, 5, 0x00FFAA, true);

        // Source header
        context.method_51439(field_22793, class_2561.method_43470("Source (held)"),
                10, 18, 0xAAAAFF, false);

        // Target header
        context.method_51439(field_22793, class_2561.method_43470("Target (placed)"),
                field_2792 / 2 + 5, 18, 0xFFAAAA, false);

        // === Source contents ===
        refreshSourceContents();
        Map<String, Double> sourceContents = BeakerItem.getContents(
                playerInventory.method_7391());
        int y = 30;
        if (sourceContents.isEmpty()) {
            context.method_51439(field_22793, class_2561.method_43470("Empty").method_27692(class_124.field_1080),
                    10, y, 0x888888, false);
        } else {
            for (var entry : sourceContents.entrySet()) {
                String formula = entry.getKey();
                double moles = entry.getValue();
                int color = sourceFormulas.indexOf(formula) == selectedIndex
                        ? 0xFFFF55 : 0xCCCCCC;
                String line = String.format("%s: %.3f mol", formula, moles);
                context.method_51439(field_22793, class_2561.method_43470(line), 10, y, color, false);
                y += 10;
                if (y > 95) break;
            }
        }

        // === Target contents ===
        class_2338 targetPos = field_2797.getBlockPos();
        y = 30;
        int targetX = field_2792 / 2 + 5;

        if (field_22787 != null && field_22787.field_1687 != null) {
            class_2586 be = field_22787.field_1687.method_8321(targetPos);
            if (be instanceof BeakerLiquidBlockEntity beaker) {
                Map<String, Double> targetContents = beaker.getContents();
                if (targetContents.isEmpty()) {
                    context.method_51439(field_22793, class_2561.method_43470("Empty").method_27692(class_124.field_1080),
                            targetX, y, 0x888888, false);
                } else {
                    for (var entry : targetContents.entrySet()) {
                        String line = String.format("%s: %.3f mol",
                                entry.getKey(), entry.getValue());
                        context.method_51439(field_22793, class_2561.method_43470(line),
                                targetX, y, 0xCCCCCC, false);
                        y += 10;
                        if (y > 85) break;
                    }
                }
                // Capacity info
                double vol = beaker.getTotalVolumeMl();
                double cap = beaker.getMaxCapacityMl();
                context.method_51439(field_22793,
                        class_2561.method_43470(String.format("%.0f / %.0f mL", vol, cap)),
                        targetX, 92, vol > cap * 0.9 ? 0xFF5555 : 0x88FF88, false);
            }
        }

        // Selected compound display
        if (!sourceFormulas.isEmpty()) {
            String sel = sourceFormulas.get(selectedIndex);
            String iupac = IUPACNamer.getName(sel);
            String display = sel.equals(iupac) ? sel : sel + " (" + iupac + ")";
            context.method_51439(field_22793, class_2561.method_43470(display),
                    35, 110, 0xFFFF55, false);
        }

        // Status message
        if (!statusMessage.isEmpty()) {
            context.method_51439(field_22793, class_2561.method_43470(statusMessage),
                    10, 155, statusColor, false);
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (amountField.method_25370()) {
            if (keyCode == 256) {
                this.method_25419();
                return true;
            }
            amountField.method_25404(keyCode, scanCode, modifiers);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
