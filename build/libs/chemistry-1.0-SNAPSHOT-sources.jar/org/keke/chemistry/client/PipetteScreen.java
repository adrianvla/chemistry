package org.keke.chemistry.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_124;
import net.minecraft.class_1661;
import net.minecraft.class_2338;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_465;
import net.minecraft.class_5676;
import io.netty.buffer.Unpooled;
import org.keke.chemistry.network.ModNetworking;
import org.keke.chemistry.screen.PipetteScreenHandler;
import org.keke.chemistry.utils.Compound;

/**
 * Client-side GUI for the Precision Pipette block.
 * Contains a text field for specifying which compound to extract
 * and how much to remove (moles or grams).
 */
@Environment(EnvType.CLIENT)
public class PipetteScreen extends class_465<PipetteScreenHandler> {

    private class_342 formulaField;
    private class_342 amountField;
    private boolean useGrams = false;
    private String statusMessage = "";
    private int statusColor = 0xFFFFFF;

    public PipetteScreen(PipetteScreenHandler handler, class_1661 inventory, class_2561 title) {
        super(handler, inventory, title);
        this.field_2792 = 200;
        this.field_2779 = 140;
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        int cx = (this.field_22789 - this.field_2792) / 2;
        int cy = (this.field_22790 - this.field_2779) / 2;

        // Formula input
        formulaField = new class_342(this.field_22793, cx + 10, cy + 25, 180, 16, class_2561.method_43470("Formula"));
        formulaField.method_1880(128);
        formulaField.method_47404(class_2561.method_43470("Compound to extract").method_27692(class_124.field_1063));
        this.method_37063(formulaField);

        // Amount input
        amountField = new class_342(this.field_22793, cx + 10, cy + 55, 120, 16, class_2561.method_43470("Amount"));
        amountField.method_1880(16);
        amountField.method_47404(class_2561.method_43470("e.g. 0.25").method_27692(class_124.field_1063));
        this.method_37063(amountField);

        // Unit toggle
        class_5676<Boolean> unitToggle = class_5676.method_32607(
                class_2561.method_43470("g"), class_2561.method_43470("mol"))
                .method_32619(false)
                .method_32617(cx + 135, cy + 55, 55, 16, class_2561.method_43470("Unit"),
                        (button, value) -> useGrams = value);
        this.method_37063(unitToggle);

        // Extract button
        class_4185 extractButton = class_4185.method_46430(class_2561.method_43470("Extract from Beaker"), button -> {
            onExtractClicked();
        }).method_46434(cx + 10, cy + 85, 180, 20).method_46431();
        this.method_37063(extractButton);

        method_48265(formulaField);
    }

    private void onExtractClicked() {
        String formula = formulaField.method_1882().trim();
        String amountStr = amountField.method_1882().trim();

        if (formula.isEmpty()) {
            statusMessage = "Enter a formula to extract";
            statusColor = 0xFF5555;
            return;
        }

        double amount;
        try {
            amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                statusMessage = "Amount must be positive";
                statusColor = 0xFF5555;
                return;
            }
        } catch (NumberFormatException e) {
            statusMessage = "Invalid number";
            statusColor = 0xFF5555;
            return;
        }

        sendPipettePacket(field_2797.getBlockPos(), formula, amount, useGrams);

        double molarMass = Compound.computeMolarMass(formula);
        double molesDisplay = useGrams ? amount / molarMass : amount;
        statusMessage = String.format("Extracting %.3f mol of %s", molesDisplay, formula);
        statusColor = 0x55FF55;
    }

    private void sendPipettePacket(class_2338 pos, String formula, double amount, boolean isGrams) {
        class_2540 buf = new class_2540(Unpooled.buffer());
        buf.method_10807(pos);
        buf.method_10814(formula);
        buf.writeDouble(amount);
        buf.writeBoolean(isGrams);
        ClientPlayNetworking.send(ModNetworking.PIPETTE_EXTRACT, buf);
    }

    @Override
    protected void method_2389(class_332 context, float delta, int mouseX, int mouseY) {
        int cx = (this.field_22789 - this.field_2792) / 2;
        int cy = (this.field_22790 - this.field_2779) / 2;

        context.method_25294(cx, cy, cx + this.field_2792, cy + this.field_2779, 0xCC1A1A2E);
        context.method_49601(cx, cy, this.field_2792, this.field_2779, 0xFF4A4A6A);
    }

    @Override
    protected void method_2388(class_332 context, int mouseX, int mouseY) {
        context.method_51439(this.field_22793, this.field_22785, 10, 6, 0x00AAFF, true);

        context.method_51439(this.field_22793, class_2561.method_43470("Compound:"), 10, 16, 0xCCCCCC, false);
        context.method_51439(this.field_22793, class_2561.method_43470("Amount:"), 10, 46, 0xCCCCCC, false);

        if (!statusMessage.isEmpty()) {
            context.method_51439(this.field_22793, class_2561.method_43470(statusMessage), 10, 112, statusColor, false);
        }

        String formula = formulaField.method_1882().trim();
        if (!formula.isEmpty()) {
            try {
                double mm = Compound.computeMolarMass(formula);
                if (mm > 0) {
                    context.method_51439(this.field_22793,
                            class_2561.method_43470(String.format("M = %.2f g/mol", mm)),
                            10, 126, 0x888888, false);
                }
            } catch (Exception ignored) {}
        }
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (formulaField.method_25370() || amountField.method_25370()) {
            if (keyCode == 256) {
                this.method_25419();
                return true;
            }
            // Delegate to text fields for control keys (backspace, arrows, etc.)
            // but always return true to prevent super.keyPressed() from checking
            // the inventory keybind and closing the screen on 'e'
            formulaField.method_25404(keyCode, scanCode, modifiers);
            amountField.method_25404(keyCode, scanCode, modifiers);
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }
}
