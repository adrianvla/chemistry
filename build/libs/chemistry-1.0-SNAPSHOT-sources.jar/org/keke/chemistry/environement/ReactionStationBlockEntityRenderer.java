package org.keke.chemistry.environement;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_827;
import org.keke.chemistry.entity.ReactionStationBlockEntity;

@Environment(EnvType.CLIENT)
public class ReactionStationBlockEntityRenderer implements class_827<ReactionStationBlockEntity> {

    public ReactionStationBlockEntityRenderer(class_5614.class_5615 ctx) {}

    @Override
    public void render(ReactionStationBlockEntity blockEntity, float tickDelta, class_4587 matrices,
                       class_4597 vertexConsumers, int light, int overlay) {
        // Particle effects are handled server-side via spawnParticles
        // Visual rendering of reaction contents could be added here
    }
}
