package org.keke.chemistry.environement;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_811;
import net.minecraft.class_827;
import org.keke.chemistry.entity.BeakerLiquidBlockEntity;
import org.keke.chemistry.item.ModItems;

@Environment(EnvType.CLIENT)
public class BeakerLiquidBlockEntityRenderer implements class_827<BeakerLiquidBlockEntity> {
    private final class_1799 stack = new class_1799(ModItems.BEAKER_LIQUID_ITEM, 1);

    public BeakerLiquidBlockEntityRenderer(class_5614.class_5615 ctx) {}

    @Override
    public void render(BeakerLiquidBlockEntity blockEntity, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, int overlay) {
        if (blockEntity.isEmpty()) return;

        int color = blockEntity.getCachedColor();
        stack.method_7948().method_10569("cachedColor", color);

        matrices.method_22903();
        matrices.method_22904(0.5, 0.4375, 0.5);
        class_310.method_1551().method_1480().method_23178(stack, class_811.field_4318, light, overlay, matrices, vertexConsumers, blockEntity.method_10997(), 0);
        matrices.method_22909();
    }
}