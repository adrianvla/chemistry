package org.keke.chemistry.network;

import java.util.Map;
import java.util.Map.Entry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2960;
import org.keke.chemistry.Chemistry;
import org.keke.chemistry.block.CompositionBlock;
import org.keke.chemistry.block.PipetteBlock;
import org.keke.chemistry.entity.AbstractChemistryContainer;
import org.keke.chemistry.item.BeakerItem;
import org.keke.chemistry.utils.Compound;
import org.keke.chemistry.utils.FormulaParser;

/**
 * Server-side network handler registration for composition and pipette actions.
 */
public class ModNetworking {

    public static final class_2960 COMPOSITION_ADD = new class_2960(Chemistry.MOD_ID, "composition_add");
    public static final class_2960 PIPETTE_EXTRACT = new class_2960(Chemistry.MOD_ID, "pipette_extract");
    public static final class_2960 BEAKER_POUR = new class_2960(Chemistry.MOD_ID, "beaker_pour");

    public static void registerServerReceivers() {
        // Composition block: add chemical to beaker above
        ServerPlayNetworking.registerGlobalReceiver(COMPOSITION_ADD, (server, player, handler, buf, responseSender) -> {
            class_2338 blockPos = buf.method_10811();
            String formula = buf.method_10800(256);
            double amount = buf.readDouble();
            boolean isGrams = buf.readBoolean();

            server.execute(() -> {
                if (!player.method_7337()) return;
                if (player.method_37908() == null) return;

                // Validate the block is a composition block
                if (!(player.method_37908().method_8320(blockPos).method_26204() instanceof CompositionBlock)) return;

                // Validate formula is parseable
                try {
                    var parsed = FormulaParser.parse(formula);
                    if (parsed.isEmpty()) return;
                } catch (Exception e) {
                    return;
                }

                // Find container above
                AbstractChemistryContainer container = CompositionBlock.findContainerAbove(player.method_37908(), blockPos);
                if (container == null) {
                    player.method_7353(net.minecraft.class_2561.method_43470("No container found above the composer."), true);
                    return;
                }

                // Convert grams to moles if needed
                double moles = amount;
                if (isGrams) {
                    double molarMass = Compound.computeMolarMass(formula);
                    if (molarMass <= 0) return;
                    moles = amount / molarMass;
                }

                if (moles <= 0) return;

                // Add to container
                double added = container.addChemical(formula, moles);
                if (added > 0) {
                    player.method_7353(net.minecraft.class_2561.method_43470(
                            String.format("Added %.3f mol of %s", added, formula)), true);
                } else {
                    player.method_7353(net.minecraft.class_2561.method_43470("Container is full."), true);
                }
            });
        });

        // Pipette block: extract chemical from beaker above
        ServerPlayNetworking.registerGlobalReceiver(PIPETTE_EXTRACT, (server, player, handler, buf, responseSender) -> {
            class_2338 blockPos = buf.method_10811();
            String formula = buf.method_10800(256);
            double amount = buf.readDouble();
            boolean isGrams = buf.readBoolean();

            server.execute(() -> {
                if (!player.method_7337()) return;
                if (player.method_37908() == null) return;

                // Validate the block is a pipette block
                if (!(player.method_37908().method_8320(blockPos).method_26204() instanceof PipetteBlock)) return;

                // Find container above
                AbstractChemistryContainer container = PipetteBlock.findContainerAbove(player.method_37908(), blockPos);
                if (container == null) {
                    player.method_7353(net.minecraft.class_2561.method_43470("No container found above the pipette."), true);
                    return;
                }

                var contents = container.getContents();
                if (!contents.containsKey(formula)) {
                    player.method_7353(net.minecraft.class_2561.method_43470(
                            formula + " not found in container."), true);
                    return;
                }

                double currentMoles = contents.get(formula);

                // Convert grams to moles if needed
                double molesToRemove = amount;
                if (isGrams) {
                    double molarMass = Compound.computeMolarMass(formula);
                    if (molarMass <= 0) return;
                    molesToRemove = amount / molarMass;
                }

                if (molesToRemove <= 0) return;

                double actualRemoved = Math.min(molesToRemove, currentMoles);
                container.removeChemical(formula, actualRemoved);

                player.method_7353(net.minecraft.class_2561.method_43470(
                        String.format("Removed %.3f mol of %s", actualRemoved, formula)), true);
            });
        });

        // Beaker pouring: transfer chemicals from held beaker item to placed beaker
        ServerPlayNetworking.registerGlobalReceiver(BEAKER_POUR, (server, player, handler, buf, responseSender) -> {
            class_2338 blockPos = buf.method_10811();
            String formula = buf.method_10800(256);
            double amount = buf.readDouble();
            boolean pourAll = buf.readBoolean();

            server.execute(() -> {
                if (player.method_37908() == null) return;

                // Validate target is a chemistry container
                var be = player.method_37908().method_8321(blockPos);
                if (!(be instanceof AbstractChemistryContainer target)) return;

                // Get source contents from held item
                var heldStack = player.method_6047();
                if (!(heldStack.method_7909() instanceof BeakerItem)) return;

                var sourceContents = BeakerItem.getContents(heldStack);
                if (sourceContents.isEmpty()) {
                    player.method_7353(net.minecraft.class_2561.method_43470("Source beaker is empty."), true);
                    return;
                }

                if (pourAll) {
                    // Pour all compounds from source to target — conserve matter and energy
                    double targetMolesBefore = target.getTotalMoles();
                    double targetTempK = target.getTemperatureK();
                    double sourceTempK = BeakerItem.getTemperatureK(heldStack);

                    boolean anyPoured = false;
                    double totalPouredMoles = 0;
                    java.util.Map<String, Double> remaining = new java.util.LinkedHashMap<>(sourceContents);
                    for (var entry : sourceContents.entrySet()) {
                        double actualAdded = target.addChemical(entry.getKey(), entry.getValue());
                        if (actualAdded > 0) {
                            totalPouredMoles += actualAdded;
                            double leftInSource = entry.getValue() - actualAdded;
                            if (leftInSource <= 0.001) {
                                remaining.remove(entry.getKey());
                            } else {
                                remaining.put(entry.getKey(), leftInSource);
                            }
                            anyPoured = true;
                        }
                    }
                    if (anyPoured) {
                        // Energy conservation: mix temperatures proportionally
                        if (totalPouredMoles > 0 && (targetMolesBefore + totalPouredMoles) > 0.001) {
                            double mixedT = (targetMolesBefore * targetTempK + totalPouredMoles * sourceTempK)
                                    / (targetMolesBefore + totalPouredMoles);
                            target.setTemperatureK(mixedT);
                        }
                        BeakerItem.setContents(heldStack, remaining);
                        player.method_7353(net.minecraft.class_2561.method_43470("Poured contents into beaker."), true);
                    } else {
                        player.method_7353(net.minecraft.class_2561.method_43470("Target beaker is full."), true);
                    }
                } else {
                    // Pour specific compound
                    if (!sourceContents.containsKey(formula)) {
                        player.method_7353(net.minecraft.class_2561.method_43470(
                                formula + " not found in source beaker."), true);
                        return;
                    }

                    double available = sourceContents.get(formula);
                    double toPour = (amount <= 0) ? available : Math.min(amount, available);

                    double targetMolesBefore = target.getTotalMoles();
                    double targetTempK = target.getTemperatureK();
                    double sourceTempK = BeakerItem.getTemperatureK(heldStack);

                    double actualPoured = target.addChemical(formula, toPour);
                    if (actualPoured > 0) {
                        // Energy conservation: mix temperatures proportionally
                        if ((targetMolesBefore + actualPoured) > 0.001) {
                            double mixedT = (targetMolesBefore * targetTempK + actualPoured * sourceTempK)
                                    / (targetMolesBefore + actualPoured);
                            target.setTemperatureK(mixedT);
                        }
                        // Only remove actual poured amount from source — conserve matter
                        double leftover = available - actualPoured;
                        java.util.Map<String, Double> updated = new java.util.LinkedHashMap<>(sourceContents);
                        if (leftover <= 0.001) {
                            updated.remove(formula);
                        } else {
                            updated.put(formula, leftover);
                        }
                        BeakerItem.setContents(heldStack, updated);
                        player.method_7353(net.minecraft.class_2561.method_43470(
                                String.format("Poured %.3f mol of %s", actualPoured, formula)), true);
                    } else {
                        player.method_7353(net.minecraft.class_2561.method_43470("Target beaker is full."), true);
                    }
                }
            });
        });
    }
}
