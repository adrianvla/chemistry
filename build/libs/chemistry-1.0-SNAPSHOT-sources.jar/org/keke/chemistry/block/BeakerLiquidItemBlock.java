package org.keke.chemistry.block;

import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

public class BeakerLiquidItemBlock extends class_2248 {
    public static final class_2753 FACING = class_2741.field_12481;
    public BeakerLiquidItemBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        // With inheriting from BlockWithEntity this defaults to INVISIBLE, so we need to change that!
        return class_2464.field_11458;
    }
    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return class_2248.method_9541(6, 2, 6, 10, 6, 10);
    }
    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING,rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}
