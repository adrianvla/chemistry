package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3726;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.entity.ModBlockEntities;
import org.keke.chemistry.entity.SedimentationBlockEntity;

/**
 * Sedimentation machine — when a chemistry container (beaker, petri dish, etc.)
 * is placed on top, solid compounds inside settle to the bottom at an accelerated
 * rate (0.0167/tick → fully settled in ~3 seconds).
 *
 * Has an ACTIVE boolean property indicating whether it is currently processing
 * a container above it.
 */
public class SedimentationBlock extends class_2237 {

    public static final class_2746 ACTIVE = class_2746.method_11825("active");

    private static final class_265 SHAPE = class_2248.method_9541(1, 0, 1, 15, 8, 15);

    public SedimentationBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9564().method_11657(ACTIVE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ACTIVE);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new SedimentationBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (world.field_9236) return null;
        return method_31618(type, ModBlockEntities.SEDIMENTATION,
                (class_1937 w, class_2338 p, class_2680 s, SedimentationBlockEntity e) ->
                        SedimentationBlockEntity.tick(w, p, s, e));
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 world, class_2338 pos) {
        return true;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (state.method_11654(ACTIVE) && random.method_43048(3) == 0) {
            // Slow downward particles mimicking settling
            double x = pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * 0.4;
            double y = pos.method_10264() + 1.2;
            double z = pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * 0.4;
            world.method_8406(class_2398.field_18306, x, y, z, 0.0, -0.02, 0.0);
        }
    }
}
