package org.keke.chemistry.block;

import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.keke.chemistry.Chemistry;

public class ModBlocks {
    public static final class_2248 BEAKER_BASE = registerBlock("beaker_base",
            new BeakerBase(FabricBlockSettings.method_9630(class_2246.field_10033).method_9632(0.5f).method_22488()));
    public static final class_2248 BEAKER_LIQUID_ITEM_BLOCK = registerBlock("beaker_liquid_item_block",
            new BeakerLiquidItemBlock(FabricBlockSettings.method_9630(class_2246.field_10033).method_9632(0.5f).method_22488()));
    public static final class_2248 REACTION_STATION = registerBlock("reaction_station",
            new ReactionStationBlock(FabricBlockSettings.method_9630(class_2246.field_10085).method_9632(2.0f).method_22488()));
    public static final class_2248 FILTER = registerBlock("filter",
            new FilterBlock(FabricBlockSettings.method_9630(class_2246.field_10033).method_9632(0.5f).method_22488()));
    public static final class_2248 DISTILLATION = registerBlock("distillation",
            new DistillationBlock(FabricBlockSettings.method_9630(class_2246.field_10033).method_9632(1.0f).method_22488()));
    public static final class_2248 EVAPORATION_DISH = registerBlock("evaporation_dish",
            new EvaporationDishBlock(FabricBlockSettings.method_9630(class_2246.field_10415).method_9632(0.5f).method_22488()));
    public static final class_2248 BUNSEN_BURNER = registerBlock("bunsen_burner",
            new BunsenBurnerBlock(FabricBlockSettings.method_9630(class_2246.field_10085).method_9632(1.0f).method_22488().method_9631(state -> state.method_11654(BunsenBurnerBlock.LIT) ? 12 : 0)));
    public static final class_2248 COOLING_BLOCK = registerBlock("cooling_block",
            new CoolingBlock(FabricBlockSettings.method_9630(class_2246.field_10225).method_9632(0.5f).method_22488().method_9628(0.98f)));
    public static final class_2248 COMPOSITION_BLOCK = registerBlock("composition_block",
            new CompositionBlock(FabricBlockSettings.method_9630(class_2246.field_10085).method_9632(3.0f).method_22488()));
    public static final class_2248 PIPETTE_BLOCK = registerBlock("pipette_block",
            new PipetteBlock(FabricBlockSettings.method_9630(class_2246.field_10085).method_9632(3.0f).method_22488()));
    public static final class_2248 PETRI_DISH = registerBlock("petri_dish",
            new PetriDishBlock(FabricBlockSettings.method_9630(class_2246.field_10033).method_9632(0.3f).method_22488()));
    public static final class_2248 CHEMISTRY_CAULDRON = registerBlock("chemistry_cauldron",
            new ChemistryCauldronBlock(FabricBlockSettings.method_9630(class_2246.field_10593)));
    public static final class_2248 SEDIMENTATION_BLOCK = registerBlock("sedimentation_block",
            new SedimentationBlock(FabricBlockSettings.method_9630(class_2246.field_10085).method_9632(2.0f).method_22488()));
    public static final class_2248 VIBRATING_BLOCK = registerBlock("vibrating_block",
            new VibratingBlock(FabricBlockSettings.method_9630(class_2246.field_10085).method_9632(2.0f).method_22488()));

    private static class_2248 registerBlock(String name, class_2248 block) {
        return class_2378.method_10230(class_7923.field_41175, new class_2960(Chemistry.MOD_ID, name), block);
    }
}
