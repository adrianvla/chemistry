package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.entity.GasCollectorBlockEntity;
import org.keke.chemistry.entity.ModBlockEntities;
import org.keke.chemistry.item.ModItems;

import java.util.stream.Stream;

/**
 * Gas Collector — captures gases produced by the container below it.
 * Place above a beaker, test tube, or other chemistry container.
 * Collected gases are stored and can be extracted as items.
 * Capacity: 500 mL (gas volume at STP).
 */
public class GasCollectorBlock extends class_2237 implements class_2343 {

    public static final class_2753 FACING = class_2741.field_12481;

    private static final class_265 SHAPE = Stream.of(
            class_2248.method_9541(2, 0, 2, 14, 2, 14),    // funnel bottom
            class_2248.method_9541(3, 2, 3, 13, 10, 13),   // collection chamber
            class_2248.method_9541(4, 10, 4, 12, 14, 12)   // top cap
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();

    public GasCollectorBlock(class_2251 settings) {
        super(settings);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new GasCollectorBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.GAS_COLLECTOR,
                (class_1937 w, class_2338 p, class_2680 s, GasCollectorBlockEntity entity) ->
                        GasCollectorBlockEntity.tick(w, p, s, entity));
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof GasCollectorBlockEntity collector) {
                class_1799 heldItem = player.method_5998(hand);
                if (player.method_5715() && heldItem.method_7960()) {
                    class_1799 drop = new class_1799(ModItems.GAS_COLLECTOR_ITEM);
                    if (!collector.isEmpty()) {
                        class_2487 entityNbt = collector.getContentsNbt();
                        drop.method_7948().method_10543(entityNbt);
                    }
                    world.method_8650(pos, false);
                    player.method_6122(hand, drop);
                    world.method_8396(null, pos, class_3417.field_14819,
                            class_3419.field_15245, 0.5f, 1.5f);
                    return class_1269.field_5812;
                }
            }
        }
        return class_1269.field_5811;
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos,
                                class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof GasCollectorBlockEntity collector) {
                class_1799 drop = new class_1799(ModItems.GAS_COLLECTOR_ITEM);
                if (!collector.isEmpty()) {
                    class_2487 entityNbt = collector.getContentsNbt();
                    drop.method_7948().method_10543(entityNbt);
                }
                method_9577(world, pos, drop);
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world,
                                      class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING,
                ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}
