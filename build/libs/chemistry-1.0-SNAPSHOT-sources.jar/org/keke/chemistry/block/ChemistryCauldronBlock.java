package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.entity.ChemistryCauldronBlockEntity;
import org.keke.chemistry.entity.ModBlockEntities;
import org.keke.chemistry.item.BeakerItem;

import java.util.Map;
import java.util.Map.Entry;

/**
 * Chemistry Cauldron — a large chemistry container that replaces a vanilla
 * cauldron when chemicals are poured in. Uses the vanilla cauldron shape.
 *
 * Interactions:
 *   - Right-click with filled beaker: pour beaker contents into cauldron
 *   - Right-click with empty beaker: scoop contents into beaker
 *   - Shift + right-click with empty hand: no pickup (it's a cauldron)
 *
 * Reverts to vanilla cauldron when emptied (handled in tick).
 */
public class ChemistryCauldronBlock extends class_2237 {

    /** Cauldron shape matching vanilla (Block.createCuboidShape(2, 4, 2, 14, 16, 14)). */
    private static final class_265 SHAPE = class_2248.method_9541(2, 4, 2, 14, 16, 14);

    public ChemistryCauldronBlock(class_2251 settings) {
        super(settings);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ChemistryCauldronBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.CHEMISTRY_CAULDRON,
                (class_1937 w, class_2338 p, class_2680 s, ChemistryCauldronBlockEntity c) ->
                        ChemistryCauldronBlockEntity.tick(w, p, s, c));
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_1799 heldItem = player.method_5998(hand);
            class_2586 be = world.method_8321(pos);

            if (be instanceof ChemistryCauldronBlockEntity cauldron) {
                // Right-click with filled beaker: pour into cauldron
                if (heldItem.method_7909() instanceof BeakerItem && BeakerItem.hasContents(heldItem)) {
                    Map<String, Double> beakerContents = BeakerItem.getContents(heldItem);
                    double cauldronMolesBefore = cauldron.getTotalMoles();
                    double cauldronTempK = cauldron.getTemperatureK();
                    double sourceTempK = BeakerItem.getTemperatureK(heldItem);

                    boolean poured = false;
                    double totalPouredMoles = 0;
                    Map<String, Double> remaining = new java.util.LinkedHashMap<>(beakerContents);
                    for (var entry : beakerContents.entrySet()) {
                        double actualAdded = cauldron.addChemical(entry.getKey(), entry.getValue());
                        if (actualAdded > 0) {
                            totalPouredMoles += actualAdded;
                            double leftInSource = entry.getValue() - actualAdded;
                            if (leftInSource <= 0.001) {
                                remaining.remove(entry.getKey());
                            } else {
                                remaining.put(entry.getKey(), leftInSource);
                            }
                            poured = true;
                        }
                    }
                    if (poured) {
                        // Energy conservation: mix temperatures
                        if (totalPouredMoles > 0 && (cauldronMolesBefore + totalPouredMoles) > 0.001) {
                            double mixedT = (cauldronMolesBefore * cauldronTempK + totalPouredMoles * sourceTempK)
                                    / (cauldronMolesBefore + totalPouredMoles);
                            cauldron.setTemperatureK(mixedT);
                        }
                        if (remaining.isEmpty()) {
                            BeakerItem.clearContents(heldItem);
                        } else {
                            BeakerItem.setContents(heldItem, remaining);
                        }
                        world.method_8396(null, pos, class_3417.field_14834,
                                class_3419.field_15245, 1.0f, 0.9f);
                    }
                    return class_1269.field_5812;
                }

                // Right-click with empty beaker: scoop from cauldron
                if (heldItem.method_7909() instanceof BeakerItem
                        && !BeakerItem.hasContents(heldItem)
                        && !cauldron.isEmpty()) {
                    // Transfer contents into the beaker (limited by beaker capacity)
                    class_2487 cauldronNbt = cauldron.getContentsNbt();
                    heldItem.method_7948().method_10543(cauldronNbt);
                    cauldron.clearContents();
                    world.method_8396(null, pos, class_3417.field_15126,
                            class_3419.field_15245, 1.0f, 1.1f);
                    return class_1269.field_5812;
                }
            }
        }
        return class_1269.field_5811;
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos,
                                class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            // Don't drop anything — contents are lost (cauldron is too heavy to pick up)
            // But do drop items if the cauldron itself is broken
            class_2586 be = world.method_8321(pos);
            if (be instanceof ChemistryCauldronBlockEntity cauldron) {
                if (!cauldron.isEmpty()) {
                    // Spill: damage nearby entities with spilled chemicals
                    cauldron.clearContents();
                }
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world,
                                      class_2338 pos, class_3726 context) {
        return SHAPE;
    }
}
