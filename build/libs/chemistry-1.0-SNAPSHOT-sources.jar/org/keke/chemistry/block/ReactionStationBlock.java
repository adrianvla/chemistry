package org.keke.chemistry.block;

import java.util.Map.Entry;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.entity.ModBlockEntities;
import org.keke.chemistry.entity.ReactionStationBlockEntity;
import org.keke.chemistry.item.BeakerItem;
import org.keke.chemistry.item.ModItems;

public class ReactionStationBlock extends class_2237 implements class_2343 {
    public static final class_2753 FACING = class_2741.field_12481;
    private static final class_265 SHAPE = class_2248.method_9541(0, 0, 0, 16, 12, 16);

    public ReactionStationBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new ReactionStationBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.REACTION_STATION,
                (class_1937 w, class_2338 p, class_2680 s, ReactionStationBlockEntity be) -> ReactionStationBlockEntity.tick(w, p, s, be));
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof ReactionStationBlockEntity station) {
                class_1799 heldItem = player.method_5998(hand);

                if (heldItem.method_7909() instanceof BeakerItem) {
                    java.util.Map<String, Double> contents = BeakerItem.getContents(heldItem);

                    if (!contents.isEmpty()) {
                        // Add the first formula from the beaker
                        var entry = contents.entrySet().iterator().next();
                        if (station.addInput(entry.getKey(), entry.getValue())) {
                            BeakerItem.clearContents(heldItem);
                            world.method_8396(null, pos, class_3417.field_14834, class_3419.field_15245, 1.0f, 1.0f);
                            player.method_7353(class_2561.method_43470("Added " + entry.getKey() + " to reaction station"), true);

                            // Try to start reaction if both slots filled
                            station.tryStartReaction();
                            return class_1269.field_5812;
                        } else {
                            player.method_7353(class_2561.method_43470("Reaction station is full"), true);
                        }
                    }
                } else if (heldItem.method_7960() && player.method_5715()) {
                    // Collect output
                    String outputFormula = station.getOutputFormula();
                    double outputMoles = station.getOutputMoles();
                    if (!outputFormula.isEmpty() && outputMoles > 0) {
                        class_1799 beaker = ModItems.createFilledBeaker(outputFormula, outputMoles);
                        player.method_6122(hand, beaker);
                        station.clearOutput();
                        world.method_8396(null, pos, class_3417.field_15126, class_3419.field_15245, 1.0f, 1.0f);
                        return class_1269.field_5812;
                    }
                } else if (heldItem.method_7960()) {
                    // Show status
                    station.reportStatus(player);
                }
            }
        }
        return class_1269.method_29236(world.field_9236);
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}
