package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.entity.BeakerLiquidBlockEntity;
import org.keke.chemistry.entity.ModBlockEntities;
import org.keke.chemistry.item.BeakerItem;
import org.keke.chemistry.item.ModItems;

import java.util.stream.Stream;

public class BeakerBase extends class_2237 implements class_2343 {
    public static final class_2753 FACING = class_2741.field_12481;

    public BeakerBase(class_2251 settings) {
        super(settings);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new BeakerLiquidBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.BEAKER_LIQUID, (class_1937 world1, class_2338 pos, class_2680 state1, BeakerLiquidBlockEntity be) -> BeakerLiquidBlockEntity.tick(world1, pos, state1, be));
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof BeakerLiquidBlockEntity beakerEntity) {
                class_1799 heldItem = player.method_5998(hand);

                // Shift + empty hand: pick up the beaker
                if (player.method_5715() && heldItem.method_7960()) {
                    class_1799 beakerStack = new class_1799(ModItems.BEAKER);
                    if (!beakerEntity.isEmpty()) {
                        class_2487 entityNbt = beakerEntity.getContentsNbt();
                        beakerStack.method_7948().method_10543(entityNbt);
                    } else {
                        // Preserve beaker size even when empty
                        beakerStack.method_7948().method_10549("maxCapacityMl", beakerEntity.getMaxCapacityMl());
                    }
                    // Preserve beaker material
                    BeakerItem.setBeakerMaterial(beakerStack, beakerEntity.getBeakerMaterial());
                    world.method_8650(pos, false);
                    player.method_6122(hand, beakerStack);
                    world.method_8396(null, pos, class_3417.field_15081, class_3419.field_15245, 0.5f, 1.2f);
                    return class_1269.field_5812;
                }
            }
        }
        return class_1269.field_5811;
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos, class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof BeakerLiquidBlockEntity beakerEntity) {
                class_1799 drop = new class_1799(ModItems.BEAKER);
                if (!beakerEntity.isEmpty()) {
                    class_2487 entityNbt = beakerEntity.getContentsNbt();
                    drop.method_7948().method_10543(entityNbt);
                } else {
                    // Preserve beaker size even when empty
                    drop.method_7948().method_10549("maxCapacityMl", beakerEntity.getMaxCapacityMl());
                }
                // Preserve beaker material
                BeakerItem.setBeakerMaterial(drop, beakerEntity.getBeakerMaterial());
                method_9577(world, pos, drop);
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }
    private static final class_265 SHAPE_N = Stream.of(
            class_2248.method_9541(5, 1, 6, 6, 7, 10),
            class_2248.method_9541(6, 1, 5, 10, 6, 6),
            class_2248.method_9541(10, 1, 6, 11, 7, 10),
            class_2248.method_9541(6, 1, 10, 10, 7, 11),
            class_2248.method_9541(6, 0, 6, 10, 1, 10),
            class_2248.method_9541(8.5, 6, 5, 10, 7, 6),
            class_2248.method_9541(6, 6, 5, 7.5, 7, 6),
            class_2248.method_9541(7.5, 6, 4, 8.5, 7, 5)
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();

    private static final class_265 SHAPE_E = Stream.of(
            class_2248.method_9541(6, 1, 5, 10, 7, 6),
            class_2248.method_9541(10, 1, 6, 11, 6, 10),
            class_2248.method_9541(6, 1, 10, 10, 7, 11),
            class_2248.method_9541(5, 1, 6, 6, 7, 10),
            class_2248.method_9541(6, 0, 6, 10, 1, 10),
            class_2248.method_9541(10, 6, 8.5, 11, 7, 10),
            class_2248.method_9541(10, 6, 6, 11, 7, 7.5),
            class_2248.method_9541(11, 6, 7.5, 12, 7, 8.5)
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();

    private static final class_265 SHAPE_S = Stream.of(
            class_2248.method_9541(10, 1, 6, 11, 7, 10),
            class_2248.method_9541(6, 1, 10, 10, 6, 11),
            class_2248.method_9541(5, 1, 6, 6, 7, 10),
            class_2248.method_9541(6, 1, 5, 10, 7, 6),
            class_2248.method_9541(6, 0, 6, 10, 1, 10),
            class_2248.method_9541(6, 6, 10, 7.5, 7, 11),
            class_2248.method_9541(8.5, 6, 10, 10, 7, 11),
            class_2248.method_9541(7.5, 6, 11, 8.5, 7, 12)
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();


    private static final class_265 SHAPE_W = Stream.of(
            class_2248.method_9541(6, 1, 10, 10, 7, 11),
            class_2248.method_9541(5, 1, 6, 6, 6, 10),
            class_2248.method_9541(6, 1, 5, 10, 7, 6),
            class_2248.method_9541(10, 1, 6, 11, 7, 10),
            class_2248.method_9541(6, 0, 6, 10, 1, 10),
            class_2248.method_9541(5, 6, 6, 6, 7, 7.5),
            class_2248.method_9541(5, 6, 8.5, 6, 7, 10),
            class_2248.method_9541(4, 6, 7.5, 5, 7, 8.5)
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        switch (state.method_11654(FACING)){
            case field_11043:
                return SHAPE_N;
            case field_11034:
                return SHAPE_E;
            case field_11035:
                return SHAPE_S;
            case field_11039:
                return SHAPE_W;
            default:
                return SHAPE_N;
        }
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING,ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING,rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }


    //    public static final Block BEAKER_BLOCK  = registerBlock("beaker_block",new Block(FabricBlockSettings.create().strength(0.5f)));
}
