package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2464;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2746;
import net.minecraft.class_3726;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.entity.ModBlockEntities;
import org.keke.chemistry.entity.VibratingBlockEntity;

/**
 * Vibrating machine — when a chemistry container is placed on top, it resets
 * sedimentation progress back to 0.0, re-mixing settled solid compounds.
 *
 * Rate: 0.025 per tick → fully re-mixed in ~2 seconds (40 ticks).
 */
public class VibratingBlock extends class_2237 {

    public static final class_2746 ACTIVE = class_2746.method_11825("active");

    private static final class_265 SHAPE = class_2248.method_9541(1, 0, 1, 15, 8, 15);

    public VibratingBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9564().method_11657(ACTIVE, false));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(ACTIVE);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new VibratingBlockEntity(pos, state);
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        if (world.field_9236) return null;
        return method_31618(type, ModBlockEntities.VIBRATING,
                (class_1937 w, class_2338 p, class_2680 s, VibratingBlockEntity e) ->
                        VibratingBlockEntity.tick(w, p, s, e));
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 world, class_2338 pos) {
        return true;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (state.method_11654(ACTIVE)) {
            // Vibrating particles rising upward
            double x = pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * 0.6;
            double y = pos.method_10264() + 0.6;
            double z = pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * 0.6;
            world.method_8406(class_2398.field_11204, x, y, z,
                    (random.method_43058() - 0.5) * 0.01,
                    0.03,
                    (random.method_43058() - 0.5) * 0.01);
        }
    }
}
