package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2415;
import net.minecraft.class_247;
import net.minecraft.class_2470;
import net.minecraft.class_2561;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.util.*;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.entity.AbstractChemistryContainer;
import org.keke.chemistry.item.AbstractContainerItem;
import org.keke.chemistry.item.BeakerItem;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.stream.Stream;

/**
 * Mortar & Pestle — grinds solid compounds into powder form.
 *
 * Right-click with a container holding solid compounds to grind them.
 * This converts chunks of solid reagent into finer powder form
 * (represented by doubling the effective surface area / reaction rate).
 *
 * Gameplay: solids that have been ground react faster in containers.
 * Implementation: adds "ground_" prefix to NBT contents for affected solids.
 */
public class MortarPestleBlock extends class_2248 {

    public static final class_2753 FACING = class_2741.field_12481;

    private static final class_265 SHAPE = Stream.of(
            class_2248.method_9541(3, 0, 3, 13, 4, 13),   // mortar bowl
            class_2248.method_9541(6, 4, 6, 10, 8, 10)    // pestle
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();

    public MortarPestleBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player, class_1268 hand, class_3965 hit) {
        if (world.field_9236) return class_1269.field_5812;

        class_1799 heldItem = player.method_5998(hand);

        // Accept beakers and container items
        Map<String, Double> contents = null;
        if (heldItem.method_7909() instanceof BeakerItem) {
            contents = BeakerItem.getContents(heldItem);
        } else if (heldItem.method_7909() instanceof AbstractContainerItem) {
            contents = AbstractContainerItem.getContents(heldItem);
        }

        if (contents != null && !contents.isEmpty()) {
            Map<String, Double> ground = new LinkedHashMap<>();
            boolean anyGround = false;
            for (var entry : contents.entrySet()) {
                String formula = entry.getKey();
                double moles = entry.getValue();
                // Only grind non-ground solids (no gas/liquid formulas)
                if (!formula.startsWith("ground_") && isSolidCompound(formula)) {
                    ground.put("ground_" + formula, moles);
                    anyGround = true;
                } else {
                    ground.put(formula, moles);
                }
            }

            if (anyGround) {
                if (heldItem.method_7909() instanceof BeakerItem) {
                    BeakerItem.setContents(heldItem, ground);
                } else if (heldItem.method_7909() instanceof AbstractContainerItem) {
                    AbstractContainerItem.setContents(heldItem, ground);
                }
                world.method_8396(null, pos, class_3417.field_16865,
                        class_3419.field_15245, 0.8f, 1.2f);
                player.method_7353(class_2561.method_43470("Ground to powder").method_27692(class_124.field_1060), true);
                return class_1269.field_5812;
            } else {
                player.method_7353(class_2561.method_43470("Nothing to grind").method_27692(class_124.field_1080), true);
            }
        }

        return class_1269.field_5811;
    }

    /**
     * Check whether a formula represents a compound that's solid at room temperature.
     * Uses elemental + structural analysis rather than hardcoded lists.
     */
    private boolean isSolidCompound(String formula) {
        // Most salts, metals, and oxides are solid
        // Gases/liquids at RT: H2O, HCl, H2SO4, etc. are excluded
        org.keke.chemistry.utils.StateOfMatter som =
                org.keke.chemistry.utils.CompoundPhysicalData.getStateAtTemperature(formula, 293.15);
        return som == org.keke.chemistry.utils.StateOfMatter.SOLID;
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world,
                                      class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING,
                ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}
