package org.keke.chemistry.block;

import net.fabricmc.fabric.api.screenhandler.v1.ExtendedScreenHandlerFactory;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3914;
import net.minecraft.class_3965;
import org.keke.chemistry.entity.BeakerLiquidBlockEntity;
import org.keke.chemistry.screen.PipetteScreenHandler;

import java.util.stream.Stream;

/**
 * Precise extraction block (Pipette). Allows removing exact amounts of
 * specific chemicals from a beaker placed on top.
 *
 * Accessible in creative mode. Craftable with netherite ingots.
 */
public class PipetteBlock extends class_2248 {

    private static final class_265 SHAPE = Stream.of(
            class_2248.method_9541(0, 0, 0, 16, 2, 16),    // base plate
            class_2248.method_9541(3, 2, 3, 13, 8, 13),    // body
            class_2248.method_9541(6, 8, 6, 10, 14, 10)    // pipette tube
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();

    public PipetteBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            if (!player.method_7337()) {
                player.method_7353(class_2561.method_43470("This device requires creative mode."), true);
                return class_1269.field_5814;
            }

            player.method_17355(new ExtendedScreenHandlerFactory() {
                @Override
                public class_2561 method_5476() {
                    return class_2561.method_43470("Precision Pipette");
                }

                @Override
                public class_1703 createMenu(int syncId, class_1661 inventory, class_1657 player) {
                    return new PipetteScreenHandler(syncId, inventory,
                            class_3914.method_17392(world, pos), pos);
                }

                @Override
                public void writeScreenOpeningData(class_3222 player1, class_2540 buf) {
                    buf.method_10807(pos);
                }
            });
        }
        return class_1269.method_29236(world.field_9236);
    }

    /**
     * Find a BeakerLiquidBlockEntity directly above this block.
     */
    public static BeakerLiquidBlockEntity findBeakerAbove(class_1937 world, class_2338 pos) {
        class_2338 above = pos.method_10084();
        class_2586 be = world.method_8321(above);
        if (be instanceof BeakerLiquidBlockEntity beaker) {
            return beaker;
        }
        return null;
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }
}
