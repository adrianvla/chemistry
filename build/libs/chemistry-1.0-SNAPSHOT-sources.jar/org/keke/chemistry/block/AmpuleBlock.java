package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2237;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_247;
import net.minecraft.class_2470;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_259;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5558;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.entity.AmpuleBlockEntity;
import org.keke.chemistry.entity.ModBlockEntities;
import org.keke.chemistry.item.AmpuleItem;
import org.keke.chemistry.item.ModItems;
import org.keke.chemistry.item.PliersItem;

import java.util.stream.Stream;

/**
 * Ampule — a small sealed glass container placed as a block.
 * Holds 10 mL. Can be opened with Pliers.
 * Drops as item when shift+clicked with empty hand.
 */
public class AmpuleBlock extends class_2237 implements class_2343 {

    public static final class_2753 FACING = class_2741.field_12481;

    private static final class_265 SHAPE = Stream.of(
            class_2248.method_9541(6, 0, 6, 10, 1, 10),    // base
            class_2248.method_9541(6.5, 1, 6.5, 9.5, 8, 9.5),  // body
            class_2248.method_9541(7, 8, 7, 9, 10, 9)      // neck
    ).reduce((v1, v2) -> class_259.method_1072(v1, v2, class_247.field_1366)).get();

    public AmpuleBlock(class_2251 settings) {
        super(settings);
    }

    @Nullable
    @Override
    public class_2586 method_10123(class_2338 pos, class_2680 state) {
        return new AmpuleBlockEntity(pos, state);
    }

    @Override
    public class_2464 method_9604(class_2680 state) {
        return class_2464.field_11458;
    }

    @Nullable
    @Override
    public <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type) {
        return method_31618(type, ModBlockEntities.AMPULE,
                (class_1937 w, class_2338 p, class_2680 s, AmpuleBlockEntity entity) ->
                        AmpuleBlockEntity.tick(w, p, s, entity));
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos,
                              class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof AmpuleBlockEntity ampule) {
                class_1799 heldItem = player.method_5998(hand);

                // Open sealed ampule with pliers
                if (heldItem.method_7909() instanceof PliersItem && ampule.isSealed()) {
                    ampule.setSealed(false);
                    heldItem.method_7956(1, player, (entity) ->
                            entity.method_20236(hand));
                    world.method_8396(null, pos, class_3417.field_15081,
                            class_3419.field_15245, 0.5f, 1.8f);
                    return class_1269.field_5812;
                }

                // Shift + empty hand: pick up
                if (player.method_5715() && heldItem.method_7960()) {
                    class_1799 drop = new class_1799(ModItems.AMPULE);
                    if (!ampule.isEmpty()) {
                        class_2487 entityNbt = ampule.getContentsNbt();
                        drop.method_7948().method_10543(entityNbt);
                    }
                    AmpuleItem.setSealed(drop, ampule.isSealed());
                    world.method_8650(pos, false);
                    player.method_6122(hand, drop);
                    world.method_8396(null, pos, class_3417.field_15081,
                            class_3419.field_15245, 0.3f, 1.6f);
                    return class_1269.field_5812;
                }
            }
        }
        return class_1269.field_5811;
    }

    @Override
    public void method_9536(class_2680 state, class_1937 world, class_2338 pos,
                                class_2680 newState, boolean moved) {
        if (!state.method_27852(newState.method_26204())) {
            class_2586 be = world.method_8321(pos);
            if (be instanceof AmpuleBlockEntity ampule) {
                class_1799 drop = new class_1799(ModItems.AMPULE);
                if (!ampule.isEmpty()) {
                    class_2487 entityNbt = ampule.getContentsNbt();
                    drop.method_7948().method_10543(entityNbt);
                }
                AmpuleItem.setSealed(drop, ampule.isSealed());
                method_9577(world, pos, drop);
            }
        }
        super.method_9536(state, world, pos, newState, moved);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world,
                                      class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING,
                ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}
