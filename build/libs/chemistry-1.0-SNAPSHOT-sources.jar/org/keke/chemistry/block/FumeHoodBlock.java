package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_1295;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2753;
import net.minecraft.class_3726;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * Fume Hood — absorbs and neutralizes gas clouds in a radius around it.
 *
 * Passive block — no block entity needed. Each tick, scans for
 * AreaEffectCloudEntity instances within its radius and removes them.
 * This protects players working with volatile/toxic reactions.
 *
 * Absorption radius: 5 blocks.
 */
public class FumeHoodBlock extends class_2248 {

    public static final class_2753 FACING = class_2741.field_12481;
    private static final int ABSORPTION_RADIUS = 5;

    private static final class_265 SHAPE = class_2248.method_9541(0, 0, 0, 16, 16, 16);

    public FumeHoodBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public void method_9612(class_2680 state, class_1937 world, class_2338 pos,
                               class_2248 sourceBlock, class_2338 sourcePos, boolean notify) {
        super.method_9612(state, world, pos, sourceBlock, sourcePos, notify);
        absorbNearbyClouds(world, pos);
    }

    /**
     * Called via random tick to periodically absorb gas clouds.
     */
    @Override
    public boolean method_9542(class_2680 state) {
        return true;
    }

    @Override
    public void method_9514(class_2680 state, net.minecraft.class_3218 world,
                           class_2338 pos, net.minecraft.class_5819 random) {
        absorbNearbyClouds(world, pos);
    }

    private void absorbNearbyClouds(class_1937 world, class_2338 pos) {
        if (world.field_9236) return;

        class_238 absorptionBox = new class_238(pos).method_1014(ABSORPTION_RADIUS);
        List<class_1295> clouds = world.method_8390(
                class_1295.class, absorptionBox, cloud -> true);

        for (class_1295 cloud : clouds) {
            // Reduce cloud radius rapidly
            float newRadius = cloud.method_5599() - 0.5f;
            if (newRadius <= 0.2f) {
                cloud.method_31472();
            } else {
                cloud.method_5603(newRadius);
            }
        }
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world,
                                      class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING,
                ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING);
    }
}
