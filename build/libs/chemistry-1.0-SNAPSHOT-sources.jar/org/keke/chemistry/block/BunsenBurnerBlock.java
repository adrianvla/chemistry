package org.keke.chemistry.block;

import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2415;
import net.minecraft.class_2470;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_2746;
import net.minecraft.class_2753;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

/**
 * Bunsen burner — a heat source block. Togglable via right-click.
 * When lit, blocks above receive heated condition for reactions.
 */
public class BunsenBurnerBlock extends class_2248 {
    public static final class_2753 FACING = class_2741.field_12481;
    public static final class_2746 LIT = class_2741.field_12548;
    private static final class_265 SHAPE = class_2248.method_9541(5, 0, 5, 11, 12, 11);

    public BunsenBurnerBlock(class_2251 settings) {
        super(settings);
        method_9590(method_9564().method_11657(LIT, false));
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public class_1269 method_9534(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_1268 hand, class_3965 hit) {
        if (!world.field_9236) {
            boolean isLit = state.method_11654(LIT);
            world.method_8501(pos, state.method_11657(LIT, !isLit));
            if (!isLit) {
                world.method_8396(null, pos, class_3417.field_15145, class_3419.field_15245, 1.0f, 1.0f);
            } else {
                world.method_8396(null, pos, class_3417.field_15102, class_3419.field_15245, 1.0f, 1.0f);
            }

            // Update temperature of reaction stations and distillation blocks above
            class_2338 above = pos.method_10084();
            if (world.method_8321(above) instanceof org.keke.chemistry.entity.ReactionStationBlockEntity station) {
                station.setTemperature(!isLit ? 100 : 20);
                station.tryStartReaction();
            }
            // Chemistry containers above will detect the lit state during their tick
        }
        return class_1269.method_29236(world.field_9236);
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        if (state.method_11654(LIT)) {
            double x = pos.method_10263() + 0.5;
            double y = pos.method_10264() + 0.8;
            double z = pos.method_10260() + 0.5;
            world.method_8406(class_2398.field_11240, x, y, z, 0.0, 0.02, 0.0);
            world.method_8406(class_2398.field_11251, x, y + 0.1, z, 0.0, 0.02, 0.0);
        }
    }

    @Nullable
    @Override
    public class_2680 method_9605(class_1750 ctx) {
        return this.method_9564().method_11657(FACING, ctx.method_8042().method_10153());
    }

    @Override
    public class_2680 method_9598(class_2680 state, class_2470 rotation) {
        return state.method_11657(FACING, rotation.method_10503(state.method_11654(FACING)));
    }

    @Override
    public class_2680 method_9569(class_2680 state, class_2415 mirror) {
        return state.method_26186(mirror.method_10345(state.method_11654(FACING)));
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder) {
        builder.method_11667(FACING, LIT);
    }
}
