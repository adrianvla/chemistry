package org.keke.chemistry.block;

import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_3726;
import net.minecraft.class_5819;

/**
 * Ice-bath cooling block. When placed under a beaker, increases the
 * beaker's effective heat capacity (10×) and cooling rate,
 * preventing thermal-shock cracking from exothermic reactions.
 *
 * No block entity needed — the beaker entity detects this block below it.
 */
public class CoolingBlock extends class_2248 {

    private static final class_265 SHAPE = class_2248.method_9541(1, 0, 1, 15, 6, 15);

    public CoolingBlock(class_2251 settings) {
        super(settings);
    }

    @Override
    public class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context) {
        return SHAPE;
    }

    @Override
    public boolean method_9579(class_2680 state, class_1922 world, class_2338 pos) {
        return true;
    }

    @Override
    public void method_9496(class_2680 state, class_1937 world, class_2338 pos, class_5819 random) {
        // Occasionally spawn snowflake-like particles
        if (random.method_43048(5) == 0) {
            double x = pos.method_10263() + 0.5 + (random.method_43058() - 0.5) * 0.6;
            double y = pos.method_10264() + 0.4;
            double z = pos.method_10260() + 0.5 + (random.method_43058() - 0.5) * 0.6;
            world.method_8406(class_2398.field_28013, x, y, z, 0.0, 0.02, 0.0);
        }
    }
}
