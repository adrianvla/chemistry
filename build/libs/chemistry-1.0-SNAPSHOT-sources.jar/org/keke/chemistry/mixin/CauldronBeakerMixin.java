package org.keke.chemistry.mixin;

import org.keke.chemistry.block.ModBlocks;
import org.keke.chemistry.entity.ChemistryCauldronBlockEntity;
import org.keke.chemistry.item.BeakerItem;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2275;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3965;

/**
 * Mixin on AbstractCauldronBlock to intercept right-click with a beaker item.
 * When a player right-clicks a vanilla cauldron with a filled beaker,
 * the cauldron is replaced with a Chemistry Cauldron block and the beaker
 * contents are transferred.
 */
@Mixin(class_2275.class)
public class CauldronBeakerMixin {

    @Inject(method = "onUse", at = @At("HEAD"), cancellable = true)
    private void chemistry$onBeakerUse(class_2680 state, class_1937 world, class_2338 pos,
                                       class_1657 player, class_1268 hand, class_3965 hit,
                                       CallbackInfoReturnable<class_1269> cir) {
        class_1799 heldItem = player.method_5998(hand);

        // Only intercept if player is holding a filled beaker
        if (!(heldItem.method_7909() instanceof BeakerItem) || !BeakerItem.hasContents(heldItem)) {
            return;
        }

        if (!world.field_9236) {
            // Replace vanilla cauldron with chemistry cauldron
            world.method_8501(pos, ModBlocks.CHEMISTRY_CAULDRON.method_9564());

            // Get the new block entity and pour contents in
            var be = world.method_8321(pos);
            if (be instanceof ChemistryCauldronBlockEntity cauldron) {
                Map<String, Double> beakerContents = BeakerItem.getContents(heldItem);
                double cauldronMolesBefore = cauldron.getTotalMoles();
                double cauldronTempK = cauldron.getTemperatureK();
                double sourceTempK = BeakerItem.getTemperatureK(heldItem);

                double totalPouredMoles = 0;
                Map<String, Double> remaining = new java.util.LinkedHashMap<>(beakerContents);
                for (var entry : beakerContents.entrySet()) {
                    double actualAdded = cauldron.addChemical(entry.getKey(), entry.getValue());
                    if (actualAdded > 0) {
                        totalPouredMoles += actualAdded;
                        double leftInSource = entry.getValue() - actualAdded;
                        if (leftInSource <= 0.001) {
                            remaining.remove(entry.getKey());
                        } else {
                            remaining.put(entry.getKey(), leftInSource);
                        }
                    }
                }

                // Energy conservation: mix temperatures
                if (totalPouredMoles > 0 && (cauldronMolesBefore + totalPouredMoles) > 0.001) {
                    double mixedT = (cauldronMolesBefore * cauldronTempK + totalPouredMoles * sourceTempK)
                            / (cauldronMolesBefore + totalPouredMoles);
                    cauldron.setTemperatureK(mixedT);
                }

                if (remaining.isEmpty()) {
                    BeakerItem.clearContents(heldItem);
                } else {
                    BeakerItem.setContents(heldItem, remaining);
                }
                world.method_8396(null, pos, class_3417.field_14834,
                        class_3419.field_15245, 1.0f, 0.9f);
            }
        }

        cir.setReturnValue(class_1269.method_29236(world.field_9236));
    }
}
