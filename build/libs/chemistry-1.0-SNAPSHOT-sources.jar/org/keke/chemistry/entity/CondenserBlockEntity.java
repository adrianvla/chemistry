package org.keke.chemistry.entity;

import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.CompoundPhysicalData;
import org.keke.chemistry.utils.StateOfMatter;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Condenser — cools gases from adjacent containers into liquids.
 *
 * Tick behavior:
 *   - Checks containers below for gas-phase compounds
 *   - Captures gas, cools it below boiling point → stored as liquid condensate
 *   - Produces drip particles
 *   - Capacity: 250 mL of condensate
 */
public class CondenserBlockEntity extends AbstractChemistryContainer {

    private static final double CONDENSER_CAPACITY_ML = 250.0;
    private static final double EFFECTIVE_MASS_G = 50.0;
    /** Condenser always operates near ambient temperature. */
    private static final double CONDENSER_TEMP_K = 293.15;

    public CondenserBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CONDENSER, pos, state);
        this.maxCapacityMl = CONDENSER_CAPACITY_ML;
        this.temperatureK = CONDENSER_TEMP_K;
    }

    @Override
    protected double getEffectiveMassG() {
        return EFFECTIVE_MASS_G;
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        // Condensers do not process reactions
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        return false;
    }

    @Override
    protected double getMaxSafeTemperature() {
        return 573.15;
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, CondenserBlockEntity condenser) {
        if (world.field_9236) return;

        // Keep temperature at ambient
        condenser.temperatureK = CONDENSER_TEMP_K;

        // Every 10 ticks, check below for gases to condense
        if (world.method_8510() % 10 != 0) return;

        class_2338 belowPos = pos.method_10074();
        class_2586 belowEntity = world.method_8321(belowPos);

        if (belowEntity instanceof AbstractChemistryContainer containerBelow) {
            Map<String, Double> belowContents = containerBelow.getContents();
            Map<String, Double> toCondense = new LinkedHashMap<>();

            for (var entry : belowContents.entrySet()) {
                String formula = entry.getKey();
                double moles = entry.getValue();

                // Check if compound is gas at container's temperature
                StateOfMatter somBelow = CompoundPhysicalData.getStateAtTemperature(
                        formula, containerBelow.getTemperatureK());
                if (somBelow != StateOfMatter.GAS) continue;

                // Check if it would be liquid at condenser temperature
                StateOfMatter somCondensed = CompoundPhysicalData.getStateAtTemperature(
                        formula, CONDENSER_TEMP_K);
                if (somCondensed == StateOfMatter.LIQUID || somCondensed == StateOfMatter.SOLID) {
                    // Transfer and condense
                    double transferMoles = Math.min(moles, 0.1); // gradual condensation
                    toCondense.put(formula, transferMoles);
                }
            }

            if (!toCondense.isEmpty()) {
                for (var entry : toCondense.entrySet()) {
                    containerBelow.removeChemical(entry.getKey(), entry.getValue());
                    condenser.addChemical(entry.getKey(), entry.getValue());
                }

                if (world instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11232,
                            pos.method_10263() + 0.5, pos.method_10264() + 0.1, pos.method_10260() + 0.5,
                            2, 0.1, 0.0, 0.1, 0.0);
                }
                world.method_8396(null, pos, class_3417.field_14946,
                        class_3419.field_15245, 0.1f, 2.0f);
            }
        }
    }
}
