package org.keke.chemistry.entity;

import java.util.Map.Entry;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.keke.chemistry.block.VibratingBlock;
import org.keke.chemistry.utils.StateOfMatter;

/**
 * Block entity for the vibrating machine.
 * Each tick, checks for a chemistry container above it. If found,
 * decreases sedimentation progress of solid compounds towards 0.0,
 * re-mixing them.
 *
 * Rate: 0.025 per tick → fully re-mixed in ~2 seconds (40 ticks).
 */
public class VibratingBlockEntity extends class_2586 {

    /** Vibrating/remixing rate (0.025/tick → ~2s). */
    private static final double VIBRATING_RATE = 0.025;

    public VibratingBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.VIBRATING, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, VibratingBlockEntity self) {
        if (world.field_9236) return;

        class_2338 above = pos.method_10084();
        class_2586 beAbove = world.method_8321(above);

        boolean active = false;

        if (beAbove instanceof AbstractChemistryContainer container) {
            // Check if there are any settled solid compounds
            boolean hasSettled = false;
            for (var entry : container.getContents().entrySet()) {
                if (container.getCompoundState(entry.getKey()) == StateOfMatter.SOLID) {
                    if (container.getSedimentationProgress(entry.getKey()) > 0.0) {
                        hasSettled = true;
                        break;
                    }
                }
            }

            if (hasSettled) {
                container.decreaseSedimentation(VIBRATING_RATE);
                active = true;
            }
        }

        // Update ACTIVE state if changed
        if (state.method_11654(VibratingBlock.ACTIVE) != active) {
            world.method_8501(pos, state.method_11657(VibratingBlock.ACTIVE, active));
        }
    }
}
