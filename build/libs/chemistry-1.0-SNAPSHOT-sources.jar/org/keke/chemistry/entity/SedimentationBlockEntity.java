package org.keke.chemistry.entity;

import java.util.Map.Entry;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import org.keke.chemistry.block.SedimentationBlock;

/**
 * Block entity for the sedimentation machine.
 * Each tick, checks for a chemistry container (BeakerLiquidBlockEntity, etc.)
 * above it. If found, accelerates sedimentation of solid compounds towards 1.0.
 *
 * Rate: 0.0167 per tick → fully settled in ~3 seconds (60 ticks).
 */
public class SedimentationBlockEntity extends class_2586 {

    /** Sedimentation rate for the machine (0.0167/tick → ~3s). */
    private static final double SEDIMENTATION_RATE = 0.0167;

    public SedimentationBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.SEDIMENTATION, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, SedimentationBlockEntity self) {
        if (world.field_9236) return;

        class_2338 above = pos.method_10084();
        class_2586 beAbove = world.method_8321(above);

        boolean active = false;

        if (beAbove instanceof AbstractChemistryContainer container) {
            // Check if there are any solid compounds that aren't fully settled
            boolean hasSolids = false;
            for (var entry : container.getContents().entrySet()) {
                if (container.getCompoundState(entry.getKey()) == org.keke.chemistry.utils.StateOfMatter.SOLID) {
                    if (container.getSedimentationProgress(entry.getKey()) < 1.0) {
                        hasSolids = true;
                        break;
                    }
                }
            }

            if (hasSolids) {
                container.accelerateSedimentation(SEDIMENTATION_RATE);
                active = true;
            }
        }

        // Update ACTIVE state if changed
        if (state.method_11654(SedimentationBlock.ACTIVE) != active) {
            world.method_8501(pos, state.method_11657(SedimentationBlock.ACTIVE, active));
        }
    }
}
