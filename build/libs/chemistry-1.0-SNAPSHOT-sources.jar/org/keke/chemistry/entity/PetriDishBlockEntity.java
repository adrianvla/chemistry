package org.keke.chemistry.entity;

import org.keke.chemistry.reaction.ReactionEffect;
import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.GasCloudHelper;

import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Petri Dish — a shallow, open container used for
 * evaporation, crystallization, and small-volume reactions.
 *
 * Key differences from BeakerLiquidBlockEntity:
 *   - Small capacity: 50 mL (fixed)
 *   - Heat-resistant: no thermal overload / cracking
 *   - Faster evaporation: liquids evaporate at a higher rate
 *   - No cooling block interaction
 *   - Newton cooling constant is higher (open, shallow dish)
 */
public class PetriDishBlockEntity extends AbstractChemistryContainer {

    /** Petri dish capacity in mL. */
    private static final double PETRI_CAPACITY_ML = 50.0;

    /** Newton cooling constant — higher because dish is shallow and open. */
    private static final double COOLING_K = 0.05;

    /** Effective mass for heat calculations (much less solution). */
    private static final double EFFECTIVE_MASS_G = 50.0;

    public PetriDishBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.PETRI_DISH, pos, state);
        this.maxCapacityMl = PETRI_CAPACITY_ML;
    }

    // ── Hooks ──────────────────────────────────────────────────────────

    @Override
    protected double getEffectiveMassG() {
        return EFFECTIVE_MASS_G;
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        if (field_11863 == null || field_11863.field_9236) return;

        field_11863.method_8396(null, field_11867, class_3417.field_14978,
                class_3419.field_15245, 0.4f, 1.2f);

        if (field_11863 instanceof class_3218 serverWorld) {
            if (result.getEffects().contains(ReactionEffect.GAS_EVOLUTION)) {
                serverWorld.method_14199(class_2398.field_11241,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.3, field_11867.method_10260() + 0.5,
                        4, 0.1, 0.05, 0.1, 0.02);
            }
            if (result.getEffects().contains(ReactionEffect.PRECIPITATE)) {
                serverWorld.method_14199(class_2398.field_23956,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.2, field_11867.method_10260() + 0.5,
                        3, 0.1, 0.05, 0.1, 0.0);
            }
        }
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        // Petri dishes are heat-resistant (borosilicate glass or ceramic)
        // Just cap the temperature instead of cracking
        temperatureK = Math.min(temperatureK, getMaxSafeTemperature());
        return false;
    }

    /** Petri dishes tolerate higher temperatures. */
    @Override
    protected double getMaxSafeTemperature() {
        return 773.15; // 500 °C
    }

    @Override
    protected double getThermalShockThreshold() {
        return 200.0; // more resistant to thermal shock
    }

    // ── Tick ────────────────────────────────────────────────────────────

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, PetriDishBlockEntity dish) {
        if (world.field_9236) return;
        if (dish.isEmpty()) return;

        // Heating from bunsen burner below
        dish.tickHeatingFromBelow();

        // Newton's law of cooling (faster for shallow dish)
        if (Math.abs(dish.temperatureK - AMBIENT_TEMP_K) > 0.01) {
            dish.temperatureK -= COOLING_K * (dish.temperatureK - AMBIENT_TEMP_K);
            dish.method_5431();
            dish.syncToClient();
        }

        // Gas escape
        Map<String, Double> gases = dish.removeGases();
        if (!gases.isEmpty()) {
            GasCloudHelper.spawnGasClouds(world, pos, gases);
        }

        // Natural sedimentation
        dish.tickSedimentation();

        // Steam from hot liquids
        if (dish.temperatureK > 373.15 && world instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11204,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.3, pos.method_10260() + 0.5,
                    1, 0.15, 0.05, 0.15, 0.01);
        }

        // Overflow check (thermal expansion)
        dish.checkAndHandleOverflow();
    }
}
