package org.keke.chemistry.entity;

import net.fabricmc.fabric.api.object.builder.v1.block.entity.FabricBlockEntityTypeBuilder;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import org.keke.chemistry.Chemistry;
import org.keke.chemistry.block.ModBlocks;

public class ModBlockEntities {
    public static class_2591<BeakerLiquidBlockEntity> BEAKER_LIQUID;
    public static class_2591<ReactionStationBlockEntity> REACTION_STATION;
    public static class_2591<FilterBlockEntity> FILTER;
    public static class_2591<DistillationBlockEntity> DISTILLATION;
    public static class_2591<EvaporationDishBlockEntity> EVAPORATION_DISH;
    public static class_2591<PetriDishBlockEntity> PETRI_DISH;
    public static class_2591<ChemistryCauldronBlockEntity> CHEMISTRY_CAULDRON;
    public static class_2591<SedimentationBlockEntity> SEDIMENTATION;
    public static class_2591<VibratingBlockEntity> VIBRATING;

    public static void registerAllBlockEntities() {
        BEAKER_LIQUID = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "beaker_liquid"),
                FabricBlockEntityTypeBuilder.create(BeakerLiquidBlockEntity::new, ModBlocks.BEAKER_BASE).build(null)
        );
        REACTION_STATION = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "reaction_station"),
                FabricBlockEntityTypeBuilder.create(ReactionStationBlockEntity::new, ModBlocks.REACTION_STATION).build(null)
        );
        FILTER = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "filter"),
                FabricBlockEntityTypeBuilder.create(FilterBlockEntity::new, ModBlocks.FILTER).build(null)
        );
        DISTILLATION = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "distillation"),
                FabricBlockEntityTypeBuilder.create(DistillationBlockEntity::new, ModBlocks.DISTILLATION).build(null)
        );
        EVAPORATION_DISH = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "evaporation_dish"),
                FabricBlockEntityTypeBuilder.create(EvaporationDishBlockEntity::new, ModBlocks.EVAPORATION_DISH).build(null)
        );
        PETRI_DISH = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "petri_dish"),
                FabricBlockEntityTypeBuilder.create(PetriDishBlockEntity::new, ModBlocks.PETRI_DISH).build(null)
        );
        CHEMISTRY_CAULDRON = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "chemistry_cauldron"),
                FabricBlockEntityTypeBuilder.create(ChemistryCauldronBlockEntity::new, ModBlocks.CHEMISTRY_CAULDRON).build(null)
        );
        SEDIMENTATION = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "sedimentation"),
                FabricBlockEntityTypeBuilder.create(SedimentationBlockEntity::new, ModBlocks.SEDIMENTATION_BLOCK).build(null)
        );
        VIBRATING = class_2378.method_10230(
                class_7923.field_41181,
                new class_2960(Chemistry.MOD_ID, "vibrating"),
                FabricBlockEntityTypeBuilder.create(VibratingBlockEntity::new, ModBlocks.VIBRATING_BLOCK).build(null)
        );
    }
}
