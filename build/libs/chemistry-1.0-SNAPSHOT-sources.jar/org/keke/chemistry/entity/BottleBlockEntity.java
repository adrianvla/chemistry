package org.keke.chemistry.entity;

import org.keke.chemistry.reaction.ReactionEffect;
import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.GasCloudHelper;

import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Bottle — a medium-capacity container.
 *
 * Key properties:
 *   - Medium capacity: 100 mL
 *   - Standard glass durability
 *   - Open-top: gases escape normally
 */
public class BottleBlockEntity extends AbstractChemistryContainer {

    private static final double BOTTLE_CAPACITY_ML = 100.0;
    private static final double COOLING_K = 0.025;
    private static final double EFFECTIVE_MASS_G = 100.0;

    public BottleBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.BOTTLE, pos, state);
        this.maxCapacityMl = BOTTLE_CAPACITY_ML;
    }

    @Override
    protected double getEffectiveMassG() {
        return EFFECTIVE_MASS_G;
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        if (field_11863 == null || field_11863.field_9236) return;

        field_11863.method_8396(null, field_11867, class_3417.field_14978,
                class_3419.field_15245, 0.4f, 1.0f);

        if (field_11863 instanceof class_3218 serverWorld) {
            if (result.getEffects().contains(ReactionEffect.GAS_EVOLUTION)) {
                serverWorld.method_14199(class_2398.field_11241,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.7, field_11867.method_10260() + 0.5,
                        4, 0.08, 0.1, 0.08, 0.02);
            }
        }
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        if (field_11863 == null || field_11863.field_9236) return false;

        field_11863.method_8396(null, field_11867, class_3417.field_15081,
                class_3419.field_15245, 1.0f, 1.0f);
        if (field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11205,
                    field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.5, field_11867.method_10260() + 0.5,
                    12, 0.3, 0.3, 0.3, 0.1);
        }

        Map<String, Double> spilled = Map.copyOf(contents);
        contents.clear();
        onOverflow(spilled);
        field_11863.method_22352(field_11867, false);
        return true;
    }

    @Override
    protected double getMaxSafeTemperature() {
        return 523.15; // 250 °C
    }

    @Override
    protected double getThermalShockThreshold() {
        return 80.0;
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, BottleBlockEntity bottle) {
        if (world.field_9236) return;
        if (bottle.isEmpty()) return;

        bottle.tickHeatingFromBelow();

        if (Math.abs(bottle.temperatureK - AMBIENT_TEMP_K) > 0.01) {
            bottle.temperatureK -= COOLING_K * (bottle.temperatureK - AMBIENT_TEMP_K);
            bottle.method_5431();
            bottle.syncToClient();
        }

        Map<String, Double> gases = bottle.removeGases();
        if (!gases.isEmpty()) {
            GasCloudHelper.spawnGasClouds(world, pos, gases);
        }

        bottle.tickSedimentation();
        bottle.checkAndHandleOverflow();
    }
}
