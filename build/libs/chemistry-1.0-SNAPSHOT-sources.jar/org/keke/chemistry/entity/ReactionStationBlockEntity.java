package org.keke.chemistry.entity;

import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.reaction.*;
import org.keke.chemistry.utils.FormulaUtils;

import java.util.*;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;

public class ReactionStationBlockEntity extends class_2586 {
    private String input1Formula = "";
    private double input1Moles = 0.0;
    private String input2Formula = "";
    private double input2Moles = 0.0;
    private String outputFormula = "";
    private double outputMoles = 0.0;
    private String leftoverFormula = "";
    private double leftoverMoles = 0.0;

    private boolean reacting = false;
    private int progress = 0;
    private int reactionTime = 60; // ticks (3 seconds)
    private int temperature = 20; // ambient

    public ReactionStationBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.REACTION_STATION, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, ReactionStationBlockEntity be) {
        if (!be.reacting) return;

        be.progress++;

        // Spawn particles during reaction
        if (world instanceof class_3218 serverWorld) {
            if (be.progress % 5 == 0) {
                serverWorld.method_14199(class_2398.field_11241,
                        pos.method_10263() + 0.5, pos.method_10264() + 1.0, pos.method_10260() + 0.5,
                        2, 0.2, 0.1, 0.2, 0.01);
            }
        }

        if (be.progress >= be.reactionTime) {
            be.completeReaction();
        }
    }

    public boolean addInput(String formula, double moles) {
        if (reacting) return false;

        if (input1Formula.isEmpty()) {
            input1Formula = formula;
            input1Moles = moles;
            method_5431();
            return true;
        } else if (input2Formula.isEmpty()) {
            input2Formula = formula;
            input2Moles = moles;
            method_5431();
            return true;
        }
        return false;
    }

    public void tryStartReaction() {
        if (reacting) return;
        if (input1Formula.isEmpty() || input2Formula.isEmpty()) return;

        Reaction reaction = ReactionRegistry.findReaction(input1Formula, input2Formula);
        if (reaction != null) {
            // Check conditions
            if (reaction.getConditions().requiresHeat() && temperature < reaction.getConditions().getMinTemp()) {
                return; // needs heat
            }
            reacting = true;
            progress = 0;
            method_5431();
        }
    }

    private void completeReaction() {
        Reaction reaction = ReactionRegistry.findReaction(input1Formula, input2Formula);
        if (reaction == null) {
            reacting = false;
            return;
        }

        Map<String, Double> inputMoles = new LinkedHashMap<>();
        inputMoles.put(input1Formula, input1Moles);
        inputMoles.put(input2Formula, input2Moles);

        ReactionResult result = ReactionProcessor.process(reaction, inputMoles, temperature);

        if (result.isSuccess()) {
            // Take first product as main output
            Map.Entry<String, Double> firstProduct = result.getProducts().entrySet().iterator().next();
            outputFormula = firstProduct.getKey();
            outputMoles = firstProduct.getValue();

            // Take first leftover if any
            if (!result.getLeftovers().isEmpty()) {
                Map.Entry<String, Double> firstLeftover = result.getLeftovers().entrySet().iterator().next();
                leftoverFormula = firstLeftover.getKey();
                leftoverMoles = firstLeftover.getValue();
            }

            // Spawn effect particles
            if (field_11863 instanceof class_3218 serverWorld) {
                if (result.getEffects().contains(ReactionEffect.GAS_EVOLUTION)) {
                    serverWorld.method_14199(class_2398.field_17431,
                            field_11867.method_10263() + 0.5, field_11867.method_10264() + 1.2, field_11867.method_10260() + 0.5,
                            10, 0.2, 0.3, 0.2, 0.02);
                }
                if (result.getEffects().contains(ReactionEffect.EXOTHERMIC)) {
                    serverWorld.method_14199(class_2398.field_11240,
                            field_11867.method_10263() + 0.5, field_11867.method_10264() + 1.0, field_11867.method_10260() + 0.5,
                            5, 0.2, 0.1, 0.2, 0.01);
                }
            }
        }

        input1Formula = "";
        input1Moles = 0.0;
        input2Formula = "";
        input2Moles = 0.0;
        reacting = false;
        progress = 0;
        method_5431();
        if (field_11863 != null) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    public void reportStatus(class_1657 player) {
        if (reacting) {
            int percent = (progress * 100) / reactionTime;
            player.method_7353(class_2561.method_43470("Reaction in progress: " + percent + "%").method_27692(class_124.field_1054), true);
        } else if (!outputFormula.isEmpty()) {
            player.method_7353(class_2561.method_43470("Output: " + FormulaUtils.formatFormula(outputFormula) +
                    String.format(" (%.2f mol)", outputMoles)).method_27692(class_124.field_1060), true);
        } else if (!input1Formula.isEmpty() && input2Formula.isEmpty()) {
            player.method_7353(class_2561.method_43470("Input 1: " + FormulaUtils.formatFormula(input1Formula) +
                    " — add second reactant").method_27692(class_124.field_1075), true);
        } else if (!input1Formula.isEmpty()) {
            player.method_7353(class_2561.method_43470("Ready — waiting for reaction start").method_27692(class_124.field_1075), true);
        } else {
            player.method_7353(class_2561.method_43470("Empty — add reactants with beakers").method_27692(class_124.field_1080), true);
        }
    }

    public String getOutputFormula() { return outputFormula; }
    public double getOutputMoles() { return outputMoles; }
    public boolean isReacting() { return reacting; }
    public int getProgress() { return progress; }
    public int getReactionTime() { return reactionTime; }

    public void clearOutput() {
        outputFormula = "";
        outputMoles = 0.0;
        leftoverFormula = "";
        leftoverMoles = 0.0;
        method_5431();
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    public int getTemperature() { return temperature; }

    @Override
    public void method_11007(class_2487 nbt) {
        nbt.method_10582("input1Formula", input1Formula);
        nbt.method_10549("input1Moles", input1Moles);
        nbt.method_10582("input2Formula", input2Formula);
        nbt.method_10549("input2Moles", input2Moles);
        nbt.method_10582("outputFormula", outputFormula);
        nbt.method_10549("outputMoles", outputMoles);
        nbt.method_10582("leftoverFormula", leftoverFormula);
        nbt.method_10549("leftoverMoles", leftoverMoles);
        nbt.method_10556("reacting", reacting);
        nbt.method_10569("progress", progress);
        nbt.method_10569("temperature", temperature);
        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        input1Formula = nbt.method_10558("input1Formula");
        input1Moles = nbt.method_10574("input1Moles");
        input2Formula = nbt.method_10558("input2Formula");
        input2Moles = nbt.method_10574("input2Moles");
        outputFormula = nbt.method_10558("outputFormula");
        outputMoles = nbt.method_10574("outputMoles");
        leftoverFormula = nbt.method_10558("leftoverFormula");
        leftoverMoles = nbt.method_10574("leftoverMoles");
        reacting = nbt.method_10577("reacting");
        progress = nbt.method_10550("progress");
        temperature = nbt.method_10550("temperature");
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}
