package org.keke.chemistry.entity;

import org.keke.chemistry.reaction.ReactionEffect;
import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.GasCloudHelper;

import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Ampule — a small sealed glass container.
 *
 * Key properties:
 *   - Very small capacity: 10 mL
 *   - Can be sealed (no gas escape, no reactions when sealed)
 *   - Fragile: cracks at low thermal overload
 *   - When sealed, acts as inert storage
 */
public class AmpuleBlockEntity extends AbstractChemistryContainer {

    private static final double AMPULE_CAPACITY_ML = 10.0;
    private static final double COOLING_K = 0.02;
    private static final double EFFECTIVE_MASS_G = 10.0;

    private boolean sealed = true;

    public AmpuleBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.AMPULE, pos, state);
        this.maxCapacityMl = AMPULE_CAPACITY_ML;
    }

    public boolean isSealed() { return sealed; }

    public void setSealed(boolean sealed) {
        this.sealed = sealed;
        method_5431();
        syncToClient();
    }

    @Override
    protected double getEffectiveMassG() {
        return EFFECTIVE_MASS_G;
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        if (field_11863 == null || field_11863.field_9236) return;
        field_11863.method_8396(null, field_11867, class_3417.field_14978,
                class_3419.field_15245, 0.2f, 1.6f);
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        if (field_11863 == null || field_11863.field_9236) return false;

        // Sealed ampule under pressure can pop
        field_11863.method_8396(null, field_11867, class_3417.field_15081,
                class_3419.field_15245, 1.2f, 1.8f);
        if (field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11205,
                    field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.5, field_11867.method_10260() + 0.5,
                    15, 0.2, 0.3, 0.2, 0.15);
        }

        Map<String, Double> spilled = Map.copyOf(contents);
        contents.clear();
        onOverflow(spilled);
        field_11863.method_22352(field_11867, false);
        return true;
    }

    @Override
    protected double getMaxSafeTemperature() {
        return 423.15; // 150 °C if sealed (pressure build-up)
    }

    @Override
    protected double getThermalShockThreshold() {
        return 40.0; // very fragile
    }

    // ── NBT ────────────────────────────────────────────────────────────

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        this.sealed = nbt.method_10577("sealed");
    }

    @Override
    public void method_11007(class_2487 nbt) {
        super.method_11007(nbt);
        nbt.method_10556("sealed", sealed);
    }

    // ── Tick ────────────────────────────────────────────────────────────

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, AmpuleBlockEntity ampule) {
        if (world.field_9236) return;
        if (ampule.isEmpty()) return;

        // Sealed ampules do not process reactions or lose gases
        if (ampule.sealed) return;

        ampule.tickHeatingFromBelow();

        if (Math.abs(ampule.temperatureK - AMBIENT_TEMP_K) > 0.01) {
            ampule.temperatureK -= COOLING_K * (ampule.temperatureK - AMBIENT_TEMP_K);
            ampule.method_5431();
            ampule.syncToClient();
        }

        Map<String, Double> gases = ampule.removeGases();
        if (!gases.isEmpty()) {
            GasCloudHelper.spawnGasClouds(world, pos, gases);
        }

        ampule.tickSedimentation();
        ampule.checkAndHandleOverflow();
    }
}
