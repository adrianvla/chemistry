package org.keke.chemistry.entity;

import org.keke.chemistry.item.AbstractContainerItem;
import org.keke.chemistry.item.BeakerItem;
import org.keke.chemistry.item.ModItems;
import org.keke.chemistry.utils.CompoundPhysicalData;
import org.keke.chemistry.utils.DrinkingEffects;
import org.keke.chemistry.utils.ExplosiveCompounds;
import org.keke.chemistry.utils.GasCloudHelper;
import org.keke.chemistry.utils.MaterialInteraction;
import org.keke.chemistry.utils.ModDamageSources;
import org.keke.chemistry.utils.StateOfMatter;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_1282;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_2392;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2520;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3857;
import net.minecraft.class_3966;

/**
 * Thrown chemistry container entity.
 * 
 * Extends ThrownItemEntity — when it hits a block or entity, the container
 * shatters and its contents interact with the environment:
 *
 *   - Explosive compounds detonate (radius based on ExplosiveCompounds algorithm)
 *   - Corrosive/toxic compounds apply splash effects via DrinkingEffects
 *   - Material interactions via MaterialInteraction (fire, corrosion, freezing)
 *   - Gas clouds spawned via GasCloudHelper
 *   - Glass shatter particles and sound
 *
 * NBT carried from the item stack includes the full contents map and temperature.
 */
public class ThrownContainerEntity extends class_3857 {

    public ThrownContainerEntity(class_1299<? extends class_3857> entityType, class_1937 world) {
        super(entityType, world);
    }

    public ThrownContainerEntity(class_1937 world, class_1309 owner) {
        super(ModEntityTypes.THROWN_CONTAINER, owner, world);
    }

    @Override
    protected class_1792 method_16942() {
        return ModItems.BEAKER;
    }

    // ── Contents from item stack ───────────────────────────────────────

    private Map<String, Double> getContents() {
        class_1799 stack = this.method_7495();
        if (stack.method_7909() instanceof BeakerItem) {
            return BeakerItem.getContents(stack);
        } else if (stack.method_7909() instanceof AbstractContainerItem) {
            return AbstractContainerItem.getContents(stack);
        }

        // Fallback: read directly from NBT
        Map<String, Double> map = new LinkedHashMap<>();
        class_2487 nbt = stack.method_7969();
        if (nbt != null && nbt.method_10573("contents", class_2520.field_33260)) {
            class_2487 contentsNbt = nbt.method_10562("contents");
            for (String key : contentsNbt.method_10541()) {
                double val = contentsNbt.method_10574(key);
                if (val > 0.001) map.put(key, val);
            }
        }
        return map;
    }

    private double getTemperatureK() {
        class_1799 stack = this.method_7495();
        class_2487 nbt = stack.method_7969();
        if (nbt != null && nbt.method_10545("temperatureK")) {
            return nbt.method_10574("temperatureK");
        }
        return 293.15;
    }

    // ── Impact handling ────────────────────────────────────────────────

    @Override
    protected void method_7488(class_239 hitResult) {
        super.method_7488(hitResult);

        if (this.method_37908().field_9236) return;

        Map<String, Double> contents = getContents();
        double tempK = getTemperatureK();
        class_2338 impactPos = class_2338.method_49638(hitResult.method_17784());

        // Glass break effect
        spawnBreakParticles();
        this.method_37908().method_8396(null, impactPos,
                class_3417.field_15081, class_3419.field_15245,
                1.0f, 1.2f);

        if (!contents.isEmpty()) {
            // 1. Check for explosive detonation
            handleExplosion(impactPos, contents);

            // 2. Apply splash damage to nearby entities
            handleSplashDamage(impactPos, contents, tempK);

            // 3. Material interactions (fire, corrosion, freezing)
            MaterialInteraction.applySplashEffects(
                    this.method_37908(), impactPos, contents, tempK, 3);

            // 4. Gas cloud generation
            Map<String, Double> gases = new LinkedHashMap<>();
            for (var entry : contents.entrySet()) {
                StateOfMatter som = CompoundPhysicalData.getStateAtTemperature(
                        entry.getKey(), tempK);
                if (som == StateOfMatter.GAS) {
                    gases.put(entry.getKey(), entry.getValue());
                }
            }
            if (!gases.isEmpty()) {
                GasCloudHelper.spawnGasClouds(this.method_37908(), impactPos, gases);
            }
        }

        this.method_31472();
    }

    @Override
    protected void method_7454(class_3966 entityHitResult) {
        // Direct hit damage: 1.0 base + chemical effects applied in onCollision
        if (entityHitResult.method_17782() instanceof class_1309 target) {
            class_1282 source = ModDamageSources.labAccident(this.method_37908());
            target.method_5643(source, 1.0f);
        }
    }

    // ── Explosion handling ─────────────────────────────────────────────

    private void handleExplosion(class_2338 pos, Map<String, Double> contents) {
        double explosionPower = ExplosiveCompounds.calculateTotalExplosionPower(contents);

        // Also check thermite
        if (MaterialInteraction.isThermiteMixture(contents)) {
            double thermitePowerKJ = MaterialInteraction.getThermitePower(contents);
            // Thermite: incendiary rather than explosive
            // Creates intense fire but less blast
            double thermiteBlast = Math.min(6.0, thermitePowerKJ / 200.0);
            explosionPower = Math.max(explosionPower, thermiteBlast);
        }

        if (explosionPower > 0.5) {
            // Create explosion with appropriate power
            this.method_37908().method_8537(
                    this.method_24921(),
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                    (float) explosionPower,
                    explosionPower > 3.0, // causes fire for powerful explosions
                    class_1937.class_7867.field_40891
            );
        }
    }

    // ── Splash damage ──────────────────────────────────────────────────

    private void handleSplashDamage(class_2338 pos, Map<String, Double> contents, double tempK) {
        class_1937 world = this.method_37908();
        class_238 splashBox = new class_238(pos).method_1014(3.0);
        List<class_1309> entities = world.method_8390(
                class_1309.class, splashBox, e -> true);

        for (class_1309 entity : entities) {
            double distance = entity.method_5649(
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5);
            double distanceFactor = Math.max(0.1, 1.0 - Math.sqrt(distance) / 4.0);

            // Scale contents by distance
            Map<String, Double> scaledContents = new LinkedHashMap<>();
            for (var entry : contents.entrySet()) {
                scaledContents.put(entry.getKey(), entry.getValue() * distanceFactor);
            }

            // Apply chemical effects
            DrinkingEffects.applyEffects(entity, scaledContents);
            DrinkingEffects.applyTemperatureEffects(entity, tempK,
                    scaledContents.values().stream().mapToDouble(Double::doubleValue).sum());
        }
    }

    // ── Particles ──────────────────────────────────────────────────────

    private void spawnBreakParticles() {
        if (this.method_37908() instanceof class_3218 serverWorld) {
            class_1799 stack = this.method_7495();
            serverWorld.method_14199(
                    new class_2392(class_2398.field_11218, stack),
                    this.method_23317(), this.method_23318(), this.method_23321(),
                    8, 0.2, 0.2, 0.2, 0.05);
        }
    }
}
