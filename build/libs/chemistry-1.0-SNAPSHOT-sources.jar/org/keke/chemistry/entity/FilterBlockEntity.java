package org.keke.chemistry.entity;

import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.utils.FormulaUtils;

/**
 * Filter block entity — handles filtration of solutions.
 * For simplicity, passes the solution through directly (no precipitate separation logic
 * unless a precipitation reaction has occurred).
 */
public class FilterBlockEntity extends class_2586 {
    private String inputFormula = "";
    private double inputMoles = 0.0;
    private String filtrateFormula = "";
    private double filtrateMoles = 0.0;
    private String residueFormula = "";
    private double residueMoles = 0.0;
    private boolean processing = false;
    private int progress = 0;
    private static final int FILTER_TIME = 40; // 2 seconds

    public FilterBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.FILTER, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, FilterBlockEntity be) {
        if (!be.processing) return;

        be.progress++;
        if (be.progress >= FILTER_TIME) {
            be.completeFiltering();
        }
    }

    public void setInput(String formula, double moles) {
        this.inputFormula = formula;
        this.inputMoles = moles;
        this.processing = true;
        this.progress = 0;
        method_5431();
    }

    private void completeFiltering() {
        // Simple filtration: pass liquid through
        filtrateFormula = inputFormula;
        filtrateMoles = inputMoles;
        inputFormula = "";
        inputMoles = 0.0;
        processing = false;
        progress = 0;
        method_5431();
        if (field_11863 != null) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    public boolean isEmpty() { return inputFormula.isEmpty() && filtrateFormula.isEmpty(); }
    public String getFiltrateFormula() { return filtrateFormula; }
    public double getFiltrateMoles() { return filtrateMoles; }

    public void clearFiltrate() {
        filtrateFormula = "";
        filtrateMoles = 0.0;
        method_5431();
    }

    public void reportStatus(class_1657 player) {
        if (processing) {
            int percent = (progress * 100) / FILTER_TIME;
            player.method_7353(class_2561.method_43470("Filtering: " + percent + "%").method_27692(class_124.field_1054), true);
        } else if (!filtrateFormula.isEmpty()) {
            player.method_7353(class_2561.method_43470("Filtrate: " + FormulaUtils.formatFormula(filtrateFormula) +
                    String.format(" (%.2f mol)", filtrateMoles)).method_27692(class_124.field_1060), true);
        } else {
            player.method_7353(class_2561.method_43470("Empty — pour solution to filter").method_27692(class_124.field_1080), true);
        }
    }

    @Override
    public void method_11007(class_2487 nbt) {
        nbt.method_10582("inputFormula", inputFormula);
        nbt.method_10549("inputMoles", inputMoles);
        nbt.method_10582("filtrateFormula", filtrateFormula);
        nbt.method_10549("filtrateMoles", filtrateMoles);
        nbt.method_10582("residueFormula", residueFormula);
        nbt.method_10549("residueMoles", residueMoles);
        nbt.method_10556("processing", processing);
        nbt.method_10569("progress", progress);
        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        inputFormula = nbt.method_10558("inputFormula");
        inputMoles = nbt.method_10574("inputMoles");
        filtrateFormula = nbt.method_10558("filtrateFormula");
        filtrateMoles = nbt.method_10574("filtrateMoles");
        residueFormula = nbt.method_10558("residueFormula");
        residueMoles = nbt.method_10574("residueMoles");
        processing = nbt.method_10577("processing");
        progress = nbt.method_10550("progress");
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}
