package org.keke.chemistry.entity;

import org.keke.chemistry.reaction.ReactionEffect;
import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.GasCloudHelper;

import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Chemistry Cauldron — a large, sturdy container for
 * bulk chemical reactions. Replaces a vanilla cauldron when chemicals are added.
 *
 * Properties:
 *   - Large capacity: 4000 mL (4 liters)
 *   - Very heat-resistant: withstands up to 1273 K (1000 °C)
 *   - Slow cooling rate (large thermal mass)
 *   - Reverts to vanilla cauldron when emptied
 */
public class ChemistryCauldronBlockEntity extends AbstractChemistryContainer {

    /** Cauldron capacity in mL. */
    private static final double CAULDRON_CAPACITY_ML = 4000.0;

    /** Newton cooling constant — slow because of iron mass. */
    private static final double COOLING_K = 0.005;

    /** Effective mass for heat calculations (iron + liquid). */
    private static final double EFFECTIVE_MASS_G = 1000.0;

    public ChemistryCauldronBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CHEMISTRY_CAULDRON, pos, state);
        this.maxCapacityMl = CAULDRON_CAPACITY_ML;
    }

    // ── Hooks ──────────────────────────────────────────────────────────

    @Override
    protected double getEffectiveMassG() {
        return EFFECTIVE_MASS_G;
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        if (field_11863 == null || field_11863.field_9236) return;

        field_11863.method_8396(null, field_11867, class_3417.field_14978,
                class_3419.field_15245, 0.8f, 0.8f);

        if (field_11863 instanceof class_3218 serverWorld) {
            if (result.getEffects().contains(ReactionEffect.GAS_EVOLUTION)) {
                serverWorld.method_14199(class_2398.field_11241,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.8, field_11867.method_10260() + 0.5,
                        12, 0.25, 0.15, 0.25, 0.02);
            }
            if (result.getEffects().contains(ReactionEffect.EXOTHERMIC)) {
                serverWorld.method_14199(class_2398.field_11240,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.9, field_11867.method_10260() + 0.5,
                        5, 0.2, 0.05, 0.2, 0.01);
            }
            if (result.getEffects().contains(ReactionEffect.PRECIPITATE)) {
                serverWorld.method_14199(class_2398.field_23956,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.6, field_11867.method_10260() + 0.5,
                        8, 0.2, 0.15, 0.2, 0.0);
            }
        }
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        // Iron cauldron doesn't crack, but may release a burst of steam/sparks
        if (field_11863 != null && !field_11863.field_9236 && field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11239,
                    field_11867.method_10263() + 0.5, field_11867.method_10264() + 1.0, field_11867.method_10260() + 0.5,
                    8, 0.3, 0.2, 0.3, 0.05);
            field_11863.method_8396(null, field_11867, class_3417.field_19198,
                    class_3419.field_15245, 1.0f, 0.5f);
        }
        // Cap temperature but don't destroy
        temperatureK = Math.min(temperatureK, getMaxSafeTemperature());
        return false;
    }

    @Override
    protected double getMaxSafeTemperature() {
        return 1273.15; // 1000 °C — iron melting point is ~1538 °C
    }

    @Override
    protected double getThermalShockThreshold() {
        return 300.0; // iron is very resistant
    }

    // ── Tick ────────────────────────────────────────────────────────────

    public static void tick(class_1937 world, class_2338 pos, class_2680 state,
                            ChemistryCauldronBlockEntity cauldron) {
        if (world.field_9236) return;

        // If empty, revert to vanilla cauldron
        if (cauldron.isEmpty()) {
            world.method_8544(pos);
            world.method_8501(pos, class_2246.field_10593.method_9564());
            return;
        }

        // Heating from bunsen burner below
        cauldron.tickHeatingFromBelow();

        // Newton cooling
        if (Math.abs(cauldron.temperatureK - AMBIENT_TEMP_K) > 0.01) {
            cauldron.temperatureK -= COOLING_K * (cauldron.temperatureK - AMBIENT_TEMP_K);
            cauldron.method_5431();
            cauldron.syncToClient();
        }

        // Steam from hot contents
        if (cauldron.temperatureK > 373.15 && world instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11204,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.9, pos.method_10260() + 0.5,
                    2, 0.2, 0.1, 0.2, 0.01);
        }

        // Gas escape
        Map<String, Double> gases = cauldron.removeGases();
        if (!gases.isEmpty()) {
            GasCloudHelper.spawnGasClouds(world, pos, gases);
        }

        // Natural sedimentation
        cauldron.tickSedimentation();

        // Overflow check
        cauldron.checkAndHandleOverflow();
    }
}
