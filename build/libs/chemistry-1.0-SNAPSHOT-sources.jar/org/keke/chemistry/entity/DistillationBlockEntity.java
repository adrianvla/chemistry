package org.keke.chemistry.entity;

import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.block.BunsenBurnerBlock;
import org.keke.chemistry.utils.FormulaUtils;

/**
 * Distillation block entity. Requires heat source below.
 * Processes input solution over time.
 */
public class DistillationBlockEntity extends class_2586 {
    private String inputFormula = "";
    private double inputMoles = 0.0;
    private String outputFormula = "";
    private double outputMoles = 0.0;
    private boolean processing = false;
    private int progress = 0;
    private static final int DISTILL_TIME = 100; // 5 seconds

    public DistillationBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.DISTILLATION, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, DistillationBlockEntity be) {
        if (!be.processing) return;

        // Check for heat source below
        class_2680 below = world.method_8320(pos.method_10074());
        if (!(below.method_26204() instanceof BunsenBurnerBlock) || !below.method_11654(BunsenBurnerBlock.LIT)) {
            return; // needs heat
        }

        be.progress++;
        if (be.progress >= DISTILL_TIME) {
            be.completeDistillation();
        }
    }

    public void setInput(String formula, double moles) {
        this.inputFormula = formula;
        this.inputMoles = moles;
        this.processing = true;
        this.progress = 0;
        method_5431();
    }

    private void completeDistillation() {
        // Simple distillation: output is the same as input (purified)
        outputFormula = inputFormula;
        outputMoles = inputMoles;
        inputFormula = "";
        inputMoles = 0.0;
        processing = false;
        progress = 0;
        method_5431();
        if (field_11863 != null) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    public boolean isEmpty() { return inputFormula.isEmpty() && outputFormula.isEmpty(); }
    public String getOutputFormula() { return outputFormula; }
    public double getOutputMoles() { return outputMoles; }

    public void clearOutput() {
        outputFormula = "";
        outputMoles = 0.0;
        method_5431();
    }

    public void reportStatus(class_1657 player) {
        if (processing) {
            // Check heat
            if (field_11863 != null) {
                class_2680 below = field_11863.method_8320(field_11867.method_10074());
                if (!(below.method_26204() instanceof BunsenBurnerBlock) || !below.method_11654(BunsenBurnerBlock.LIT)) {
                    player.method_7353(class_2561.method_43470("Needs heat source below!").method_27692(class_124.field_1061), true);
                    return;
                }
            }
            int percent = (progress * 100) / DISTILL_TIME;
            player.method_7353(class_2561.method_43470("Distilling: " + percent + "%").method_27692(class_124.field_1054), true);
        } else if (!outputFormula.isEmpty()) {
            player.method_7353(class_2561.method_43470("Output: " + FormulaUtils.formatFormula(outputFormula) +
                    String.format(" (%.2f mol)", outputMoles)).method_27692(class_124.field_1060), true);
        } else {
            player.method_7353(class_2561.method_43470("Empty — add solution to distill").method_27692(class_124.field_1080), true);
        }
    }

    @Override
    public void method_11007(class_2487 nbt) {
        nbt.method_10582("inputFormula", inputFormula);
        nbt.method_10549("inputMoles", inputMoles);
        nbt.method_10582("outputFormula", outputFormula);
        nbt.method_10549("outputMoles", outputMoles);
        nbt.method_10556("processing", processing);
        nbt.method_10569("progress", progress);
        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        inputFormula = nbt.method_10558("inputFormula");
        inputMoles = nbt.method_10574("inputMoles");
        outputFormula = nbt.method_10558("outputFormula");
        outputMoles = nbt.method_10574("outputMoles");
        processing = nbt.method_10577("processing");
        progress = nbt.method_10550("progress");
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}
