package org.keke.chemistry.entity;

import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.CompoundPhysicalData;
import org.keke.chemistry.utils.StateOfMatter;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Gas Collector — captures gases from the container below.
 *
 * Tick behavior:
 *   - Checks the block entity directly below (pos.down())
 *   - If it's an AbstractChemistryContainer, intercepts gas escape
 *   - Stores captured gases in its own contents map
 *   - Capacity: 500 mL (measured in moles at STP via ideal gas law)
 *
 * The gas collector overrides removeGases() of the container below
 * by periodically checking and transferring gas compounds.
 */
public class GasCollectorBlockEntity extends AbstractChemistryContainer {

    private static final double GAS_COLLECTOR_CAPACITY_ML = 500.0;
    private static final double EFFECTIVE_MASS_G = 50.0;

    /** Moles of gas at STP per mL (ideal gas: 1 mol = 22400 mL at STP). */
    private static final double MOLES_PER_ML_STP = 1.0 / 22400.0;

    public GasCollectorBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.GAS_COLLECTOR, pos, state);
        this.maxCapacityMl = GAS_COLLECTOR_CAPACITY_ML;
    }

    @Override
    protected double getEffectiveMassG() {
        return EFFECTIVE_MASS_G;
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        // Gas collector doesn't process reactions, just stores gases
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        // Glass gas collector can crack
        return false;
    }

    @Override
    protected double getMaxSafeTemperature() {
        return 573.15; // 300 °C
    }

    /**
     * Calculate remaining gas capacity in moles.
     */
    public double getRemainingCapacityMoles() {
        double maxMoles = GAS_COLLECTOR_CAPACITY_ML * MOLES_PER_ML_STP;
        double currentMoles = getTotalMoles();
        return Math.max(0, maxMoles - currentMoles);
    }

    // ── Tick ────────────────────────────────────────────────────────────

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, GasCollectorBlockEntity collector) {
        if (world.field_9236) return;

        // Every 10 ticks, check the container below for gas compounds
        if (world.method_8510() % 10 != 0) return;

        class_2338 belowPos = pos.method_10074();
        class_2586 belowEntity = world.method_8321(belowPos);

        if (belowEntity instanceof AbstractChemistryContainer containerBelow) {
            Map<String, Double> belowContents = containerBelow.getContents();
            Map<String, Double> gasesToCapture = new LinkedHashMap<>();

            // Identify gas-phase compounds in the container below
            for (var entry : belowContents.entrySet()) {
                String formula = entry.getKey();
                double moles = entry.getValue();

                StateOfMatter som = CompoundPhysicalData.getStateAtTemperature(
                        formula, containerBelow.getTemperatureK());
                if (som == StateOfMatter.GAS) {
                    // Transfer up to remaining capacity
                    double remaining = collector.getRemainingCapacityMoles();
                    if (remaining <= 0) break;

                    double transferMoles = Math.min(moles, remaining);
                    gasesToCapture.put(formula, transferMoles);
                }
            }

            // Transfer gases
            if (!gasesToCapture.isEmpty()) {
                for (var entry : gasesToCapture.entrySet()) {
                    containerBelow.removeChemical(entry.getKey(), entry.getValue());
                    collector.addChemical(entry.getKey(), entry.getValue());
                }

                if (world instanceof class_3218 serverWorld) {
                    serverWorld.method_14199(class_2398.field_11204,
                            pos.method_10263() + 0.5, pos.method_10264() + 0.2, pos.method_10260() + 0.5,
                            2, 0.1, 0.05, 0.1, 0.0);
                }
                world.method_8396(null, pos, class_3417.field_15065,
                        class_3419.field_15245, 0.2f, 1.5f);
            }
        }
    }
}
