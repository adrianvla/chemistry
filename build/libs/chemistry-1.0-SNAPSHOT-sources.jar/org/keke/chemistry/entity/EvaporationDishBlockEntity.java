package org.keke.chemistry.entity;

import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import org.jetbrains.annotations.Nullable;
import org.keke.chemistry.utils.FormulaUtils;

/**
 * Evaporation dish block entity. Slowly evaporates solvent over time,
 * leaving residue behind.
 */
public class EvaporationDishBlockEntity extends class_2586 {
    private String inputFormula = "";
    private double inputMoles = 0.0;
    private String residueFormula = "";
    private double residueMoles = 0.0;
    private boolean processing = false;
    private int progress = 0;
    private static final int EVAPORATION_TIME = 200; // 10 seconds

    public EvaporationDishBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.EVAPORATION_DISH, pos, state);
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, EvaporationDishBlockEntity be) {
        if (!be.processing) return;

        be.progress++;

        // Spawn evaporation particles
        if (world instanceof class_3218 serverWorld && be.progress % 10 == 0) {
            serverWorld.method_14199(class_2398.field_11204,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                    1, 0.3, 0.1, 0.3, 0.01);
        }

        if (be.progress >= EVAPORATION_TIME) {
            be.completeEvaporation();
        }
    }

    public void setInput(String formula, double moles) {
        this.inputFormula = formula;
        this.inputMoles = moles;
        this.processing = true;
        this.progress = 0;
        method_5431();
    }

    private void completeEvaporation() {
        // After evaporation, the dissolved solid remains (same formula for simplicity)
        residueFormula = inputFormula;
        residueMoles = inputMoles;
        inputFormula = "";
        inputMoles = 0.0;
        processing = false;
        progress = 0;
        method_5431();
        if (field_11863 != null) {
            field_11863.method_8413(field_11867, method_11010(), method_11010(), 3);
        }
    }

    public boolean isEmpty() { return inputFormula.isEmpty() && residueFormula.isEmpty(); }
    public String getResidueFormula() { return residueFormula; }
    public double getResidueMoles() { return residueMoles; }

    public void clearResidue() {
        residueFormula = "";
        residueMoles = 0.0;
        method_5431();
    }

    public void reportStatus(class_1657 player) {
        if (processing) {
            int percent = (progress * 100) / EVAPORATION_TIME;
            player.method_7353(class_2561.method_43470("Evaporating: " + percent + "%").method_27692(class_124.field_1054), true);
        } else if (!residueFormula.isEmpty()) {
            player.method_7353(class_2561.method_43470("Residue: " + FormulaUtils.formatFormula(residueFormula) +
                    String.format(" (%.2f mol)", residueMoles)).method_27692(class_124.field_1060), true);
        } else {
            player.method_7353(class_2561.method_43470("Empty — pour solution to evaporate").method_27692(class_124.field_1080), true);
        }
    }

    @Override
    public void method_11007(class_2487 nbt) {
        nbt.method_10582("inputFormula", inputFormula);
        nbt.method_10549("inputMoles", inputMoles);
        nbt.method_10582("residueFormula", residueFormula);
        nbt.method_10549("residueMoles", residueMoles);
        nbt.method_10556("processing", processing);
        nbt.method_10569("progress", progress);
        super.method_11007(nbt);
    }

    @Override
    public void method_11014(class_2487 nbt) {
        super.method_11014(nbt);
        inputFormula = nbt.method_10558("inputFormula");
        inputMoles = nbt.method_10574("inputMoles");
        residueFormula = nbt.method_10558("residueFormula");
        residueMoles = nbt.method_10574("residueMoles");
        processing = nbt.method_10577("processing");
        progress = nbt.method_10550("progress");
    }

    @Nullable
    @Override
    public class_2596<class_2602> method_38235() {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887() {
        return method_38244();
    }
}
