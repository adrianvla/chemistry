package org.keke.chemistry.entity;

import org.keke.chemistry.reaction.ReactionEffect;
import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.GasCloudHelper;

import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Test Tube — a narrow container for small-volume reactions.
 *
 * Key properties:
 *   - Small capacity: 25 mL
 *   - Fragile: cracks at lower temperatures than beakers
 *   - Fast heating: narrow profile means rapid temperature changes
 *   - Does not interact with cooling blocks
 */
public class TestTubeBlockEntity extends AbstractChemistryContainer {

    private static final double TEST_TUBE_CAPACITY_ML = 25.0;
    private static final double COOLING_K = 0.03;
    private static final double EFFECTIVE_MASS_G = 25.0;

    public TestTubeBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.TEST_TUBE, pos, state);
        this.maxCapacityMl = TEST_TUBE_CAPACITY_ML;
    }

    @Override
    protected double getEffectiveMassG() {
        return EFFECTIVE_MASS_G;
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        if (field_11863 == null || field_11863.field_9236) return;

        field_11863.method_8396(null, field_11867, class_3417.field_14978,
                class_3419.field_15245, 0.3f, 1.4f);

        if (field_11863 instanceof class_3218 serverWorld) {
            if (result.getEffects().contains(ReactionEffect.GAS_EVOLUTION)) {
                serverWorld.method_14199(class_2398.field_11241,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.8, field_11867.method_10260() + 0.5,
                        3, 0.05, 0.1, 0.05, 0.02);
            }
            if (result.getEffects().contains(ReactionEffect.EXOTHERMIC)) {
                serverWorld.method_14199(class_2398.field_11251,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.8, field_11867.method_10260() + 0.5,
                        2, 0.05, 0.1, 0.05, 0.01);
            }
        }
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        if (field_11863 == null || field_11863.field_9236) return false;

        // Test tubes crack more easily — lower threshold
        field_11863.method_8396(null, field_11867, class_3417.field_15081,
                class_3419.field_15245, 1.0f, 1.5f);
        if (field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11205,
                    field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.5, field_11867.method_10260() + 0.5,
                    10, 0.2, 0.3, 0.2, 0.1);
        }

        // Spill contents and break
        Map<String, Double> spilled = Map.copyOf(contents);
        contents.clear();
        onOverflow(spilled);
        field_11863.method_22352(field_11867, false);
        return true;
    }

    @Override
    protected double getMaxSafeTemperature() {
        return 473.15; // 200 °C — lower than beakers
    }

    @Override
    protected double getThermalShockThreshold() {
        return 60.0; // fragile
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, TestTubeBlockEntity tube) {
        if (world.field_9236) return;
        if (tube.isEmpty()) return;

        tube.tickHeatingFromBelow();

        if (Math.abs(tube.temperatureK - AMBIENT_TEMP_K) > 0.01) {
            tube.temperatureK -= COOLING_K * (tube.temperatureK - AMBIENT_TEMP_K);
            tube.method_5431();
            tube.syncToClient();
        }

        Map<String, Double> gases = tube.removeGases();
        if (!gases.isEmpty()) {
            GasCloudHelper.spawnGasClouds(world, pos, gases);
        }

        tube.tickSedimentation();
        tube.checkAndHandleOverflow();
    }
}
