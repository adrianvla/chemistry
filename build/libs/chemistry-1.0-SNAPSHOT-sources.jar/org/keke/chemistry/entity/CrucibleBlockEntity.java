package org.keke.chemistry.entity;

import org.keke.chemistry.reaction.ReactionEffect;
import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.GasCloudHelper;

import java.util.Map;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for the Crucible — a high-temperature container.
 *
 * Key properties:
 *   - Capacity: 200 mL
 *   - Extreme heat resistance: up to 1473 K (1200 °C)
 *   - Suitable for thermite reactions, metal smelting
 *   - Slower cooling rate (thick ceramic walls)
 */
public class CrucibleBlockEntity extends AbstractChemistryContainer {

    private static final double CRUCIBLE_CAPACITY_ML = 200.0;
    private static final double COOLING_K = 0.01; // slow cooling — thick ceramic
    private static final double EFFECTIVE_MASS_G = 200.0;

    public CrucibleBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.CRUCIBLE, pos, state);
        this.maxCapacityMl = CRUCIBLE_CAPACITY_ML;
    }

    @Override
    protected double getEffectiveMassG() {
        return EFFECTIVE_MASS_G;
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        if (field_11863 == null || field_11863.field_9236) return;

        if (field_11863 instanceof class_3218 serverWorld) {
            if (result.getEffects().contains(ReactionEffect.INCENDIARY)) {
                serverWorld.method_14199(class_2398.field_11240,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.6, field_11867.method_10260() + 0.5,
                        15, 0.15, 0.3, 0.15, 0.05);
                serverWorld.method_14199(class_2398.field_11239,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.5, field_11867.method_10260() + 0.5,
                        5, 0.1, 0.1, 0.1, 0.01);
                field_11863.method_8396(null, field_11867, class_3417.field_15013,
                        class_3419.field_15245, 1.0f, 0.8f);
            }
            if (result.getEffects().contains(ReactionEffect.EXOTHERMIC)) {
                serverWorld.method_14199(class_2398.field_11251,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.7, field_11867.method_10260() + 0.5,
                        4, 0.1, 0.15, 0.1, 0.01);
            }
            if (result.getEffects().contains(ReactionEffect.GAS_EVOLUTION)) {
                serverWorld.method_14199(class_2398.field_11241,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.6, field_11867.method_10260() + 0.5,
                        3, 0.1, 0.1, 0.1, 0.02);
            }
        }
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        // Crucibles are extremely heat-resistant — almost never crack
        // Just cap temperature at max safe level
        temperatureK = Math.min(temperatureK, getMaxSafeTemperature());
        return false;
    }

    @Override
    protected double getMaxSafeTemperature() {
        return 1473.15; // 1200 °C — handles thermite
    }

    @Override
    protected double getThermalShockThreshold() {
        return 500.0; // extremely resistant
    }

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, CrucibleBlockEntity crucible) {
        if (world.field_9236) return;
        if (crucible.isEmpty()) return;

        crucible.tickHeatingFromBelow();

        // Slow Newton cooling
        if (Math.abs(crucible.temperatureK - AMBIENT_TEMP_K) > 0.01) {
            crucible.temperatureK -= COOLING_K * (crucible.temperatureK - AMBIENT_TEMP_K);
            crucible.method_5431();
            crucible.syncToClient();
        }

        Map<String, Double> gases = crucible.removeGases();
        if (!gases.isEmpty()) {
            GasCloudHelper.spawnGasClouds(world, pos, gases);
        }

        // Glowing particles when very hot
        if (crucible.temperatureK > 873.15 && world instanceof class_3218 serverWorld) { // > 600°C
            serverWorld.method_14199(class_2398.field_11240,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.5, pos.method_10260() + 0.5,
                    1, 0.1, 0.05, 0.1, 0.0);
        }

        crucible.tickSedimentation();
        crucible.checkAndHandleOverflow();
    }
}
