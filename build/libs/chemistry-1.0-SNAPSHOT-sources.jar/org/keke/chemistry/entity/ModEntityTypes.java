package org.keke.chemistry.entity;

import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_4048;
import net.minecraft.class_7923;
import org.keke.chemistry.Chemistry;

/**
 * Registry for custom entity types (projectiles, etc.).
 */
public class ModEntityTypes {

    public static final class_1299<ThrownContainerEntity> THROWN_CONTAINER = class_2378.method_10230(
            class_7923.field_41177,
            new class_2960(Chemistry.MOD_ID, "thrown_container"),
            FabricEntityTypeBuilder.<ThrownContainerEntity>create(class_1311.field_17715, ThrownContainerEntity::new)
                    .dimensions(class_4048.method_18385(0.25f, 0.25f))
                    .trackRangeBlocks(64)
                    .trackedUpdateRate(10)
                    .build()
    );

    public static void registerAll() {
        Chemistry.LOGGER.info("Registering entity types for " + Chemistry.MOD_ID);
    }
}
