package org.keke.chemistry.entity;

import org.keke.chemistry.block.CoolingBlock;
import org.keke.chemistry.reaction.ReactionEffect;
import org.keke.chemistry.reaction.ReactionResult;
import org.keke.chemistry.utils.DrinkingEffects;
import org.keke.chemistry.utils.GasCloudHelper;
import org.keke.chemistry.utils.BeakerMaterial;

import java.util.List;
import java.util.Map;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1309;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2398;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3417;
import net.minecraft.class_3419;

/**
 * Block entity for placed beakers. Extends the shared chemistry container
 * with beaker-specific behavior: Newton's-law cooling, steam particles,
 * thermal-shock cracking, and reaction visual/sound effects.
 *
 * Temperature model:
 *   - Default ambient: 293.15 K (20 °C)
 *   - Newton cooling: dT/dt = -k × (T - T_ambient)
 *   - k = 0.01 (normal), k = 0.1 (on cooling block)
 *   - Beaker cracks if T > 573 K (300 °C) or single-step ΔT > 100 K
 */
public class BeakerLiquidBlockEntity extends AbstractChemistryContainer {

    /** Default mass of solution in grams for heat calculations. */
    private static final double SOLUTION_MASS_G = 250.0;

    /** Newton cooling constant without cooling block. */
    private static final double COOLING_K_NORMAL = 0.01;

    /** Newton cooling constant with cooling block underneath. */
    private static final double COOLING_K_COOLED = 0.1;

    /** How often (in ticks) to apply proximity temperature damage. */
    private static final int DAMAGE_INTERVAL_TICKS = 20;

    /** Temperature threshold for hot contact damage (100 °C). */
    private static final double HOT_DAMAGE_THRESHOLD_K = 373.15;

    /** Temperature threshold for cold contact damage (−20 °C). */
    private static final double COLD_DAMAGE_THRESHOLD_K = 253.15;

    /** Effective solution mass for cooling block adjustment. */
    private double effectiveMassG = SOLUTION_MASS_G;

    /** Tick counter for temperature damage interval. */
    private int damageTick = 0;

    /** Material of this beaker (GLASS or METAL). */
    private BeakerMaterial beakerMaterial = BeakerMaterial.GLASS;

    public BeakerLiquidBlockEntity(class_2338 pos, class_2680 state) {
        super(ModBlockEntities.BEAKER_LIQUID, pos, state);
    }

    public BeakerMaterial getBeakerMaterial() {
        return beakerMaterial;
    }

    public void setBeakerMaterial(BeakerMaterial material) {
        this.beakerMaterial = material;
        method_5431();
    }

    // ── Hooks ──────────────────────────────────────────────────────────

    @Override
    protected double getEffectiveMassG() {
        return effectiveMassG;
    }

    @Override
    protected double getMaxSafeTemperature() {
        return beakerMaterial.getMaxSafeTempK();
    }

    @Override
    protected void onReactionEffects(ReactionResult result) {
        if (field_11863 == null || field_11863.field_9236) return;

        field_11863.method_8396(null, field_11867, class_3417.field_14978,
                class_3419.field_15245, 0.6f, 1.0f + (float)(Math.random() * 0.4 - 0.2));

        if (field_11863 instanceof class_3218 serverWorld) {
            if (result.getEffects().contains(ReactionEffect.GAS_EVOLUTION)) {
                serverWorld.method_14199(class_2398.field_11241,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.5, field_11867.method_10260() + 0.5,
                        8, 0.15, 0.15, 0.15, 0.02);
            }
            if (result.getEffects().contains(ReactionEffect.EXOTHERMIC)) {
                serverWorld.method_14199(class_2398.field_11240,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.6, field_11867.method_10260() + 0.5,
                        3, 0.1, 0.05, 0.1, 0.01);
            }
            if (result.getEffects().contains(ReactionEffect.PRECIPITATE)) {
                serverWorld.method_14199(class_2398.field_23956,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.4, field_11867.method_10260() + 0.5,
                        5, 0.15, 0.1, 0.15, 0.0);
            }
        }
    }

    @Override
    protected boolean onThermalOverload(double currentTempK, double deltaT) {
        if (beakerMaterial == BeakerMaterial.METAL) {
            // Metal beakers resist thermal shock — cap temperature at max
            this.temperatureK = beakerMaterial.getMaxSafeTempK();
            method_5431();
            return false; // don't destroy
        }
        crackBeaker();
        return true;
    }

    @Override
    protected void onOverflow(Map<String, Double> spilled) {
        if (field_11863 == null || field_11863.field_9236) return;

        // Play spill sound
        field_11863.method_8396(null, field_11867, class_3417.field_14737,
                class_3419.field_15245, 0.7f, 1.2f);

        // Spawn drip particles around the beaker
        if (field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11232,
                    field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.4, field_11867.method_10260() + 0.5,
                    10, 0.3, 0.1, 0.3, 0.01);
        }

        // Apply contact damage to nearby entities from spilled chemicals
        class_238 spillBox = new class_238(field_11867).method_1014(1.0);
        List<class_1309> entities = field_11863.method_8390(
                class_1309.class, spillBox, e -> true);

        for (class_1309 entity : entities) {
            // Classify worst spilled chemical and apply effects
            DrinkingEffects.HazardType worst = DrinkingEffects.HazardType.SAFE;
            for (String formula : spilled.keySet()) {
                DrinkingEffects.HazardType h = DrinkingEffects.classifyHazard(formula);
                if (h.ordinal() > worst.ordinal()) worst = h;
            }

            switch (worst) {
                case CORROSIVE_ACID, CORROSIVE_BASE -> {
                    entity.method_5643(entity.method_48923().method_48831(), 2.0f);
                    entity.method_6092(new class_1293(
                            class_1294.field_5916, 60, 0));
                }
                case TOXIC_METAL, OXIDIZER -> {
                    entity.method_5643(entity.method_48923().method_48831(), 1.5f);
                }
                case TOXIC_GAS -> {
                    entity.method_5643(entity.method_48923().method_48831(), 1.0f);
                    entity.method_6092(new class_1293(
                            class_1294.field_5899, 40, 0));
                }
                default -> { /* safe or mild — no contact damage */ }
            }
        }
    }

    // ── Tick ────────────────────────────────────────────────────────────

    public static void tick(class_1937 world, class_2338 pos, class_2680 state, BeakerLiquidBlockEntity be) {
        if (world.field_9236) return;
        if (be.isEmpty()) return;

        // Heating from bunsen burner below
        be.tickHeatingFromBelow();

        // Newton's law of cooling each tick
        boolean onCoolingBlock = world.method_8320(pos.method_10074()).method_26204() instanceof CoolingBlock;
        double k = onCoolingBlock ? COOLING_K_COOLED : COOLING_K_NORMAL;
        be.effectiveMassG = onCoolingBlock ? SOLUTION_MASS_G * 10.0 : SOLUTION_MASS_G;

        if (Math.abs(be.temperatureK - AMBIENT_TEMP_K) > 0.01) {
            be.temperatureK -= k * (be.temperatureK - AMBIENT_TEMP_K);
            be.method_5431();
            be.syncToClient();
        }

        // Spawn steam particles if hot
        if (be.temperatureK > 373.15 && world instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11204,
                    pos.method_10263() + 0.5, pos.method_10264() + 0.6, pos.method_10260() + 0.5,
                    1, 0.1, 0.1, 0.1, 0.01);
        }

        // Check for thermal-expansion overflow
        be.checkAndHandleOverflow();

        // Remove gaseous compounds (they escape from an open beaker)
        Map<String, Double> gases = be.removeGases();
        if (!gases.isEmpty()) {
            // Spawn lingering gas cloud with appropriate effects
            GasCloudHelper.spawnGasClouds(world, pos, gases);
        }

        // Natural sedimentation of solid compounds
        be.tickSedimentation();

        // Temperature proximity damage (every DAMAGE_INTERVAL_TICKS)
        be.damageTick++;
        if (be.damageTick >= DAMAGE_INTERVAL_TICKS) {
            be.damageTick = 0;
            applyProximityTemperatureDamage(world, pos, be);
        }
    }

    /**
     * Apply damage/effects to living entities near a hot or cold beaker.
     * Hot beakers (>100 °C) cause fire damage; cold beakers (<−20 °C) cause
     * slowness and frost damage. Damage scales with temperature extremity.
     */
    private static void applyProximityTemperatureDamage(class_1937 world, class_2338 pos, BeakerLiquidBlockEntity be) {
        double temp = be.temperatureK;
        if (temp <= HOT_DAMAGE_THRESHOLD_K && temp >= COLD_DAMAGE_THRESHOLD_K) return;

        // Search for entities within 1.5 blocks of the beaker
        class_238 damageBox = new class_238(pos).method_1014(0.5);
        List<class_1309> entities = world.method_8390(
                class_1309.class, damageBox, e -> true);

        if (entities.isEmpty()) return;

        if (temp > HOT_DAMAGE_THRESHOLD_K) {
            // Hot damage: scales from 1 at 100°C to 6 at 600°C
            float damage = Math.min(6.0f, 1.0f + (float) ((temp - HOT_DAMAGE_THRESHOLD_K) / 100.0));
            for (class_1309 entity : entities) {
                entity.method_5643(entity.method_48923().method_48820(), damage);
                entity.method_5639(1); // brief ignition
            }
        } else {
            // Cold damage: scales from 1 at −20°C to 4 at −200°C
            float damage = Math.min(4.0f, 1.0f + (float) ((COLD_DAMAGE_THRESHOLD_K - temp) / 80.0));
            int slowDuration = 40 + (int) ((COLD_DAMAGE_THRESHOLD_K - temp) / 5.0);
            int slowAmplifier = Math.min(3, (int) ((COLD_DAMAGE_THRESHOLD_K - temp) / 60.0));
            for (class_1309 entity : entities) {
                entity.method_5643(entity.method_48923().method_48836(), damage);
                entity.method_6092(new class_1293(
                        class_1294.field_5909, slowDuration, slowAmplifier));
                entity.method_32317(Math.max(entity.method_32312(), 80));
            }
        }
    }

    // ── Beaker-specific ────────────────────────────────────────────────

    @Override
    public void method_11007(net.minecraft.class_2487 nbt) {
        super.method_11007(nbt);
        nbt.method_10582("beakerMaterial", beakerMaterial.name());
    }

    @Override
    public void method_11014(net.minecraft.class_2487 nbt) {
        super.method_11014(nbt);
        if (nbt.method_10545("beakerMaterial")) {
            beakerMaterial = BeakerMaterial.fromName(nbt.method_10558("beakerMaterial"));
        }
    }

    /**
     * Beaker cracks from thermal stress — destroys the block and contents.
     */
    private void crackBeaker() {
        if (field_11863 == null || field_11863.field_9236) return;

        field_11863.method_8396(null, field_11867, class_3417.field_15081,
                class_3419.field_15245, 1.5f, 0.8f);

        if (field_11863 instanceof class_3218 serverWorld) {
            serverWorld.method_14199(class_2398.field_11205,
                    field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.5, field_11867.method_10260() + 0.5,
                    20, 0.3, 0.3, 0.3, 0.1);
            if (temperatureK > 373.15) {
                serverWorld.method_14199(class_2398.field_11204,
                        field_11867.method_10263() + 0.5, field_11867.method_10264() + 0.6, field_11867.method_10260() + 0.5,
                        10, 0.2, 0.2, 0.2, 0.05);
            }
        }

        contents.clear();
        temperatureK = AMBIENT_TEMP_K;

        // Remove the block without dropping the beaker item (it's broken)
        field_11863.method_8650(field_11867, false);
    }
}
